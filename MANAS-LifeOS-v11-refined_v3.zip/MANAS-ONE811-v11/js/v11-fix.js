/* v11-fix — feedback patch: music off, mobile companion motion */
(function(){
  // 1. Music disabled (commented out, not deleted): stop and neuter the synth engine.
  try{ if(window.NX&&NX.music){ if(NX.music.stop) NX.music.stop(); NX.music.start=function(){}; NX.music.chime=function(){}; NX.music.on=false; } }catch(e){}
  var h=document.getElementById('mhud'); if(h) h.remove();
  new MutationObserver(function(){var m=document.getElementById('mhud'); if(m) m.remove();}).observe(document.body,{childList:true});

  // 2. Companion moves on mobile: follows scroll, drifts toward touches, reacts to taps, hides from inputs.
  var mob=matchMedia('(max-width:768px)');
  function droid(){ return document.querySelector('#droid,.droid,[id*="droid"],[class*="droid"]'); }
  var tx=0,ty=0,t0=0,raf=0;
  function apply(){ var d=droid(); if(!d) return; d.classList.add('nx-alive');
    var bob=Math.sin(Date.now()/700)*6; d.style.translate=tx+'px '+(ty+bob)+'px'; }
  function loop(){ if(mob.matches){ apply(); } raf=requestAnimationFrame(loop); }
  addEventListener('scroll',function(){ if(!mob.matches) return;
    var y=scrollY, dy=Math.max(-120,Math.min(0,-(y-t0)*0.15)); t0=y; ty=ty*0.6+dy; },{passive:true});
  addEventListener('touchstart',function(e){ if(!mob.matches) return; var d=droid(); if(!d||!e.touches[0]) return;
    if(d.contains(e.target)){ d.classList.remove('nx-tap'); void d.offsetWidth; d.classList.add('nx-tap'); return; }
    var r=d.getBoundingClientRect(), p=e.touches[0];
    tx=Math.max(-(innerWidth-r.width-24),Math.min(0,tx+(p.clientX-(r.left+r.width/2))*0.35));
    ty=Math.max(-(innerHeight*0.5),Math.min(0,ty+(p.clientY-(r.top+r.height/2))*0.25)); },{passive:true});
  document.addEventListener('focusin',function(e){ var d=droid(); if(d&&/INPUT|TEXTAREA|SELECT/.test(e.target.tagName)) d.classList.add('nx-shy'); });
  document.addEventListener('focusout',function(){ var d=droid(); if(d) d.classList.remove('nx-shy'); });
  setInterval(function(){ if(mob.matches){ tx*=0.85; ty*=0.9; } },1500);
  loop();
})();
/* Radial wheel + card fan layout (computed so it fits any number of pages and any screen) */
(function(){
  function lay(){ var nav=document.getElementById('wnav'); if(!nav) return; var s=document.body.dataset.wnav;
    var items=[].slice.call(nav.querySelectorAll('.wn-i')); if(!items.length) return;
    if(s==='radial'){ var placed=0, ring=0;
      while(placed<items.length){ var r=92+ring*60, cap=Math.max(3,Math.floor((Math.PI/2*r)/56)), cnt=Math.min(cap,items.length-placed);
        for(var j=0;j<cnt;j++){ var a=Math.PI+(Math.PI/2)*(cnt===1?.5:j/(cnt-1)); var el=items[placed+j];
          el.style.setProperty('--x',(Math.cos(a)*r).toFixed(1)+'px'); el.style.setProperty('--y',(Math.sin(a)*r).toFixed(1)+'px'); el.style.setProperty('--r','0deg'); }
        placed+=cnt; ring++; } }
    else if(s==='fan'){ var gap=Math.min(52,(innerHeight*0.72)/items.length);
      items.forEach(function(el,k){ el.style.setProperty('--x',(-k*3)+'px'); el.style.setProperty('--y',(-(k+1)*gap-10)+'px'); el.style.setProperty('--r',(-k*1.2)+'deg'); }); }
  }
  function hook(){ var nav=document.getElementById('wnav'); if(!nav) return setTimeout(hook,400);
    new MutationObserver(lay).observe(nav,{childList:true}); new MutationObserver(lay).observe(document.body,{attributes:true,attributeFilter:['data-wnav']}); lay(); }
  addEventListener('resize',lay,{passive:true}); hook();
})();
/* ===================== v11-fix part 3: smart quick-add, voice, AI suggestions, music player, unique companions ===================== */
(function(){
  var esc=function(s){return NX.esc?NX.esc(s):String(s||'');};
  var pad=function(n){return String(n).padStart(2,'0');};
  var ymd=function(d){return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate());};
  var addDays=function(n){var d=new Date();d.setDate(d.getDate()+n);return ymd(d);};
  var MON=['jan','feb','mar','apr','may','jun','jul','aug','sep','oct','nov','dec'];
  var mods=function(){return NX.modules||[];};
  var modFor=function(t){return mods().find(function(m){return m.type===t;});};
  var TYPES=[['task','Task','◇'],['note','Note','≡'],['event','Event','▦'],['transaction','Money','₹'],['goal','Goal','◎'],['workout','Workout','⚡'],['memory','Memory','✧'],['learning','Learn','⌘'],['person','Person','♡'],['media','Media','▤']];
  var avail=function(){return TYPES.filter(function(t){return modFor(t[0]);});};

  /* ---------- Natural-language parser (fully local, offline) ---------- */
  function parse(line){
    var s=' '+line+' ', low=s.toLowerCase(), cut=[], o={raw:line,tags:[],pri:null,date:null,time:null,amount:null,url:null,type:'task'};
    var take=function(re){var m=s.match(re); if(m) cut.push(m[0]); return m;};
    o.tags=(line.match(/#[\w-]+/g)||[]).map(function(x){return x.slice(1);}); cut=cut.concat(line.match(/#[\w-]+/g)||[]);
    var u=take(/https?:\/\/\S+/); if(u) o.url=u[0];
    if(/!!|\burgent\b|\basap\b|\bhigh priority\b|\bimportant\b/.test(low)){o.pri='high'; take(/!!+|\burgent\b|\basap\b|\bhigh priority\b/i);} else if(/\blow priority\b|\bsomeday\b|\bwhenever\b/.test(low)){o.pri='low'; take(/\blow priority\b|\bsomeday\b|\bwhenever\b/i);}
    var m;
    if((m=take(/\b(on\s+)?day after tomorrow\b/i))) o.date=addDays(2);
    else if((m=take(/\b(by\s+|on\s+)?(tomorrow|tmrw|tmr)\b/i))) o.date=addDays(1);
    else if((m=take(/\b(by\s+)?(today|tonight)\b/i))){ o.date=addDays(0); if(/tonight/i.test(m[0])) o.time='20:00'; }
    else if((m=take(/\bin\s+(\d+)\s+(day|week)s?\b/i))) o.date=addDays(+m[1]*(/week/i.test(m[2])?7:1));
    else if((m=take(/\b(on\s+|next\s+|this\s+)?(sun|mon|tue|tues|wed|thu|thur|thurs|fri|sat)(day|nesday|sday|urday)?\b/i))){ var wd=['sun','mon','tue','wed','thu','fri','sat'].indexOf(m[2].toLowerCase().slice(0,3)); var diff=(wd-new Date().getDay()+7)%7||7; o.date=addDays(diff); }
    else if((m=take(/\b(on\s+)?(\d{1,2})(?:st|nd|rd|th)?\s+(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\b/i))){ var d=new Date(); d.setMonth(MON.indexOf(m[3].toLowerCase()),+m[2]); if(ymd(d)<addDays(0)) d.setFullYear(d.getFullYear()+1); o.date=ymd(d); }
    else if((m=take(/\b(on\s+)?(\d{1,2})[\/.-](\d{1,2})\b/))){ var d2=new Date(); d2.setMonth(+m[3]-1,+m[2]); o.date=ymd(d2); }
    if((m=take(/\b(?:at|@|by)\s*(\d{1,2})(?::(\d{2}))?\s*(am|pm)?\b/i))||(m=take(/\b(\d{1,2})(?::(\d{2}))?\s*(am|pm)\b/i))){ var h=+m[1], mi=+(m[2]||0), ap=(m[3]||'').toLowerCase(); if(ap==='pm'&&h<12) h+=12; if(ap==='am'&&h===12) h=0; if(!ap&&h<8) h+=12; if(h<24) o.time=pad(h)+':'+pad(mi); }
    else if((m=take(/\b(in the\s+)?(morning|evening|afternoon|night)\b/i))) o.time={morning:'09:00',afternoon:'14:00',evening:'18:00',night:'21:00'}[m[2].toLowerCase()];
    if((m=s.match(/(?:₹|rs\.?|inr|\$)\s*(\d+(?:\.\d+)?)/i)||s.match(/\b(\d+(?:\.\d+)?)\s*(?:₹|rs|rupees|inr|bucks)\b/i)||s.match(/\b(?:spent|paid|cost|costs|received|earned|got)\s+(\d+(?:\.\d+)?)/i))){ o.amount=+m[1]; cut.push(m[0].replace(/^(spent|paid|cost|costs|received|earned|got)\s+/i,'')); }
    var T=[['note',/^\s*(note|idea|thought)\s*[:\-]|\bnote to self\b/i],['transaction',/\b(spent|paid|bought|cost|salary|received|earned|expense|income)\b|₹|\brs\.?\s*\d/i],['workout',/\b(workout|gym|ran|run|jog|pushups?|squats?|yoga|cardio|\d+\s*km)\b/i],['event',/\b(meeting|meet|appointment|party|wedding|birthday|interview|dinner with|lunch with|call with)\b/i],['goal',/^\s*goal\s*[:\-]|\bi want to\b|\bmy goal\b/i],['memory',/^\s*(memory|remember when)\b/i],['learning',/\b(learn|course|study|tutorial|lesson)\b/i],['media',/\b(watch|movie|series|anime|read book|book:)\b/i]];
    for(var i=0;i<T.length;i++){ if(T[i][1].test(line)&&modFor(T[i][0])){o.type=T[i][0];break;} }
    var t=line; cut.forEach(function(c){ if(c) t=t.replace(c.trim(),' '); });
    t=t.replace(/^\s*(note|idea|thought|goal|memory|task|todo|event)\s*[:\-]\s*/i,'').replace(/^\s*(remind me to|i need to|i have to|add (a )?task( to)?|please)\s+/i,'').replace(/\s+(on|at|by|for)\s*$/i,'').replace(/\s{2,}/g,' ').trim();
    o.title=(t.charAt(0).toUpperCase()+t.slice(1)).slice(0,140)||line.slice(0,140);
    return o;
  }
  NX.nlParse=parse;

  /* ---------- Build a record using each module's own field definitions ---------- */
  function build(o,photos){
    var m=modFor(o.type)||modFor('task'); if(!m) return null;
    var F=(m.fields||[]).map(function(f){return Array.isArray(f)?{k:f[0],l:String(f[1]||''),kind:String(f[2]||''),opt:f[3]}:{k:f.key||f.k,l:String(f.label||''),kind:String(f.kind||f.type||''),opt:f.options||f.opt};});
    var opts=function(f){return Array.isArray(f.opt)?f.opt:String(f.opt||'').split(/[|,]/).map(function(x){return x.trim();}).filter(Boolean);};
    var now=new Date().toISOString(), rec={id:NX.uid(),type:m.type,createdAt:now,updatedAt:now};
    F.forEach(function(f){ if(/select|choice/i.test(f.kind)){ var op=opts(f); if(op.length) rec[f.k]=op[0]; } });
    var find=function(re,kre){return F.find(function(f){return re.test(f.k)||(kre&&kre.test(f.kind));});};
    var tk=(F.find(function(f){return /^(title|name)$/i.test(f.k);})||F[0]||{k:'title'}).k; rec[tk]=o.title;
    if(tk!=='title'&&!F.some(function(f){return f.k==='title';})) rec.title=o.title;
    var df=find(/due|date|when|day/i,/^date$/i); if(df) rec[df.k]=o.date||(/transaction|workout|memory|event/.test(m.type)?NX.today():''); else if(o.date) rec.dueDate=o.date;
    var tf=find(/time|hour|start/i,/^time$/i); if(tf&&o.time) rec[tf.k]=o.time;
    var af=find(/amount|value|price|cost|total/i,/number|money/i); if(af&&o.amount!=null) rec[af.k]=o.amount;
    var pf=find(/priority|importance/i); if(pf&&o.pri){ var op=opts(pf); rec[pf.k]=op.find(function(x){return new RegExp(o.pri,'i').test(x);})||(o.pri==='high'?(op[op.length-1]||'High'):(op[0]||'Low')); }
    var gf=find(/tag|label|category/i); if(gf&&o.tags.length){ var gop=opts(gf); rec[gf.k]=gop.length?(gop.find(function(x){return o.tags.some(function(t){return x.toLowerCase()===t.toLowerCase();});})||rec[gf.k]):o.tags.join(', '); }
    if(o.tags.length) rec.tags=o.tags;
    var lf=find(/link|url|website/i,/url/i); if(o.url){ if(lf) rec[lf.k]=o.url; else rec.link=o.url; }
    var kf=find(/^(kind|flow|direction|type2|txtype)$/i); if(m.type==='transaction'){ var kk=kf||F.find(function(f){return opts(f).some(function(x){return /income|expense/i.test(x);});}); if(kk){ var ko=opts(kk); rec[kk.k]=(/received|salary|earned|income|got paid/i.test(o.raw)?ko.find(function(x){return /income/i.test(x);}):ko.find(function(x){return /expense/i.test(x);}))||rec[kk.k]; } }
    var bf=find(/body|content|notes?|desc|details/i,/textarea|long/i); if(bf&&bf.k!==tk) rec[bf.k]=o.raw;
    if(photos&&photos.length) rec.photos=photos;
    return {rec:rec,m:m};
  }

  /* ---------- Voice (Web Speech API) with graceful fallback ---------- */
  var SR=window.SpeechRecognition||window.webkitSpeechRecognition;
  function listen(btn,onText){
    if(!SR){ NX.toast('Voice input isn’t supported in this browser — just type instead ✍️'); return; }
    if(btn.classList.contains('rec')&&btn._r){ btn._r.stop(); return; }
    var r=new SR(); btn._r=r; r.lang=(navigator.language||'en-IN'); r.interimResults=true; r.maxAlternatives=1;
    r.onresult=function(e){ var s=''; for(var i=0;i<e.results.length;i++) s+=e.results[i][0].transcript; onText(s,e.results[e.results.length-1].isFinal); };
    r.onerror=function(e){ NX.toast(e.error==='not-allowed'||e.error==='service-not-allowed'?'Microphone is blocked — allow it in browser settings, or type instead.':e.error==='network'?'Voice needs internet — type instead, I still work offline.':'Didn’t catch that — try again or type.'); };
    r.onend=function(){ btn.classList.remove('rec'); };
    try{ r.start(); btn.classList.add('rec'); NX.haptic&&NX.haptic(10); }catch(err){ NX.toast('Voice couldn’t start — type instead.'); }
  }
  NX.listen=listen;

  /* ---------- AI suggestions from your own data ---------- */
  function suggestions(){
    var t=NX.today(), out=[], h=new Date().getHours();
    var open=NX.list('task').filter(function(x){return ['Completed','Cancelled','Done'].indexOf(x.status)<0;});
    var over=open.filter(function(x){return x.dueDate&&x.dueDate<t;}), due=open.filter(function(x){return x.dueDate===t;});
    if(over.length) out.push(['⏰',over.length+' overdue — start with “'+over[0].title+'”','go:tasks']);
    if(due.length) out.push(['🎯',due.length+' due today. Knock out “'+due[0].title+'” first','go:tasks']);
    if(h<12) out.push(['☀️','Set your top 3 for today in one line','fill:Top 3 today: ']);
    if(h>=19) out.push(['🌙','Plan tomorrow — type it, I’ll file it','fill:Tomorrow ']);
    if(modFor('transaction')&&!NX.list('transaction').some(function(x){return String(x.date||x.createdAt||'').slice(0,10)===t;})) out.push(['₹','Log today’s spending — e.g. “spent 120 on chai”','fill:Spent ₹']);
    if(modFor('workout')&&!NX.list('workout').some(function(x){return String(x.date||x.createdAt||'').slice(0,10)===t;})) out.push(['⚡','No workout logged yet — “ran 3 km” is enough','fill:Workout: ']);
    var goals=NX.list('goal'); if(goals.length) out.push(['◎','Take one step on “'+goals[0].title+'”','go:goals']);
    out.push(['💬','Ask your companion to plan your day','chat']);
    return out.slice(0,5);
  }
  function runSugg(a){ if(!a) return; if(a==='chat') return NX.openChat&&NX.openChat(); if(a.indexOf('go:')===0){ NX.closeSheet&&NX.closeSheet(); return NX.go(a.slice(3)); } if(a.indexOf('fill:')===0) return openOmni(a.slice(5)); }
  var suggHTML=function(){return suggestions().map(function(s){return '<button class="nx-sg" data-sg="'+esc(s[2])+'"><span>'+s[0]+'</span>'+esc(s[1])+'</button>';}).join('');};
  NX.aiSuggestions=suggestions;

  /* ---------- Omnibar: "Bored of forms?" ---------- */
  var origQuick=NX.openQuickAdd;
  function openOmni(prefill){
    var over={}, photos=[];
    NX.openSheet('<div class="omni"><div class="sheet-h"><h2>Just tell me ✨</h2></div><p class="dim omni-lead">Bored to fill all these fields? Just type what you want to do or paste any link/attachment, and I’ll organize it for you!</p>'+
      '<div class="omni-box"><textarea id="omniIn" rows="3" placeholder="Call mom tomorrow at 6pm #family !!\nSpent ₹250 on lunch\nNote: app idea — voice journal\nMeeting with Ravi on friday 4pm"></textarea>'+
      '<div class="omni-tools"><button type="button" class="omni-ic" id="omniMic" aria-label="Speak">🎙</button><label class="omni-ic" aria-label="Attach">📎<input id="omniFile" type="file" accept="image/*" multiple hidden></label><span class="tiny dim" id="omniFiles">One item per line · works offline</span></div></div>'+
      '<div id="omniPrev" class="omni-prev"></div><div class="actions"><button class="btn solid" id="omniSave">Save</button>'+(origQuick?'<button class="btn" id="omniFull">Use full form</button>':'')+'</div>'+
      '<div class="mono dim omni-sh">SUGGESTED FOR YOU</div><div class="nx-sgs">'+suggHTML()+'</div></div>');
    var sb=document.getElementById('sheetBody'), inp=sb.querySelector('#omniIn'), prev=sb.querySelector('#omniPrev');
    var lines=function(){return inp.value.split('\n').map(function(x){return x.trim();}).filter(Boolean);};
    var paint=function(){ prev.innerHTML=lines().map(function(l,i){ var o=parse(l); if(over[i]) o.type=over[i]; var ty=TYPES.find(function(t){return t[0]===o.type;})||TYPES[0];
      return '<div class="omni-card" style="--k:'+i+'"><button class="omni-type" data-cyc="'+i+'" title="Tap to change">'+ty[2]+' '+ty[1]+' ▾</button><b>'+esc(o.title)+'</b><div class="omni-chips">'+
        (o.date?'<i>📅 '+esc(NX.fmtDate?NX.fmtDate(o.date):o.date)+'</i>':'')+(o.time?'<i>🕒 '+o.time+'</i>':'')+(o.amount!=null?'<i>₹ '+o.amount+'</i>':'')+(o.pri?'<i class="p-'+o.pri+'">'+(o.pri==='high'?'🔥 High':'🌿 Low')+'</i>':'')+o.tags.map(function(t){return '<i>#'+esc(t)+'</i>';}).join('')+(o.url?'<i>🔗 link</i>':'')+'</div></div>'; }).join(''); };
    inp.addEventListener('input',paint); if(prefill){ inp.value=prefill; } paint(); setTimeout(function(){ inp.focus(); inp.setSelectionRange(inp.value.length,inp.value.length); },60);
    prev.addEventListener('click',function(e){ var b=e.target.closest('[data-cyc]'); if(!b) return; var i=+b.dataset.cyc, av=avail(), cur=over[i]||parse(lines()[i]).type, k=av.findIndex(function(t){return t[0]===cur;}); over[i]=av[(k+1)%av.length][0]; paint(); });
    sb.querySelector('#omniMic').onclick=function(){ var base=inp.value?inp.value.replace(/\s*$/,'\n'):''; listen(this,function(s){ inp.value=base+s; paint(); }); };
    sb.querySelector('#omniFile').onchange=async function(){ photos=[]; for(var f of [].slice.call(this.files||[]).slice(0,4)){ try{ var p=NX.photoData?await NX.photoData(f):null; if(p) photos.push(p); }catch(e){} } sb.querySelector('#omniFiles').textContent=photos.length?('📎 '+photos.length+' image'+(photos.length>1?'s':'')+' attached'):'Couldn’t attach those files'; };
    if(origQuick) sb.querySelector('#omniFull').onclick=function(){ origQuick(); };
    sb.querySelector('.nx-sgs').addEventListener('click',function(e){ var b=e.target.closest('[data-sg]'); if(b) runSugg(b.dataset.sg); });
    var save=function(){ var L=lines(); if(!L.length){ NX.toast('Type something first ✍️'); return; } var saved=[], last=null;
      L.forEach(function(l,i){ var o=parse(l); if(over[i]) o.type=over[i]; var r=build(o,i===0?photos:null); if(r){ NX.upsert(r.rec); saved.push(r.m.name); last=r.m; } });
      try{ NX.save&&NX.save(); }catch(e){} try{ NX.award&&NX.award(5*saved.length,'Quick capture','quick'); }catch(e){}
      NX.closeSheet(); NX.toast('Saved '+saved.length+' → '+Array.from(new Set(saved)).join(', ')+' ✓');
      if(last){ if(NX.current===last.id||saved.length>1) NX.go(NX.current,false); else NX.go(last.id); }
      NX.droid&&NX.droid.say&&NX.droid.say(['Filed it! ✨','Done — one less thing to remember. ✅','Got it, organised for you. 📂'][Math.floor(Math.random()*3)]); };
    sb.querySelector('#omniSave').onclick=save;
    inp.addEventListener('keydown',function(e){ if(e.key==='Enter'&&(e.metaKey||e.ctrlKey)){ e.preventDefault(); save(); } });
  }
  NX.openOmni=openOmni; NX.openQuickAdd=openOmni;
  ['quick','quickTop'].forEach(function(id){ var b=document.getElementById(id); if(b) b.onclick=function(){ openOmni(); }; });

  /* ---------- Home: AI suggestion card + one-line capture ---------- */
  ['renderHome','renderDashboard'].forEach(function(fn){ var o=NX[fn]; if(typeof o!=='function') return; NX[fn]=function(v){ var r=o.apply(this,arguments); try{ if(v&&!v.querySelector('.nx-ai')){ var d=document.createElement('section'); d.className='nx-ai';
      d.innerHTML='<button class="nx-omni-line" data-omni><span>✨</span><span class="dim">Bored of forms? Just type what you want to do…</span><span class="nx-k">🎙</span></button><div class="nx-sgs">'+suggHTML()+'</div>';
      var hero=v.querySelector('.hero'); if(hero&&hero.nextSibling) hero.after(d); else v.prepend(d);
      d.addEventListener('click',function(e){ var b=e.target.closest('[data-sg]'); if(b) return runSugg(b.dataset.sg); if(e.target.closest('[data-omni]')) openOmni(); }); } }catch(e){} return r; }; });

  /* ---------- Chat: microphone + spoken replies ---------- */
  var TTS='nx.tts', lastSpoken='';
  new MutationObserver(function(){ var f=document.getElementById('v11form'); if(!f||f.querySelector('.omni-ic')) return;
    var input=f.querySelector('input'), mic=document.createElement('button'); mic.type='button'; mic.className='omni-ic'; mic.textContent='🎙'; mic.setAttribute('aria-label','Speak to your companion');
    mic.onclick=function(){ listen(mic,function(s,fin){ input.value=s; if(fin){ f.requestSubmit?f.requestSubmit():f.dispatchEvent(new Event('submit',{cancelable:true})); } }); };
    var tts=document.createElement('button'); tts.type='button'; tts.className='omni-ic'+(localStorage.getItem(TTS)==='1'?' on':''); tts.textContent='🔊'; tts.title='Read replies aloud';
    tts.onclick=function(){ var on=localStorage.getItem(TTS)!=='1'; localStorage.setItem(TTS,on?'1':'0'); tts.classList.toggle('on',on); if(!on&&window.speechSynthesis) speechSynthesis.cancel(); NX.toast(on?'I’ll read replies aloud 🔊':'Replies muted'); };
    f.prepend(tts); f.prepend(mic);
    var box=document.getElementById('v11msgs'); if(box) new MutationObserver(function(){ if(localStorage.getItem(TTS)!=='1'||!window.speechSynthesis) return; var ms=box.querySelectorAll('.v11-msg.assistant'), last=ms[ms.length-1]; if(!last) return; var tx=last.childNodes[0]&&last.childNodes[0].textContent||last.textContent; if(tx&&tx!==lastSpoken){ lastSpoken=tx; speechSynthesis.cancel(); var u=new SpeechSynthesisUtterance(tx.replace(/[\u{1F300}-\u{1FAFF}\u2600-\u27BF]/gu,'')); u.rate=1.02; speechSynthesis.speak(u); } }).observe(box,{childList:true});
  }).observe(document.getElementById('sheet')||document.body,{childList:true,subtree:true});

  /* ---------- Music player drawer: Spotify / YouTube / audio link / upload / ambient ---------- */
  var P=document.createElement('div'); P.id='nxPlayer'; P.className='nxp';
  P.innerHTML='<button class="nxp-tab" aria-label="Open music player">♫</button><div class="nxp-body"><div class="nxp-h"><b>Player</b><span class="tiny dim" id="nxpNow">Nothing playing</span><button class="nxp-x" aria-label="Collapse">⌄</button></div>'+
    '<form class="nxp-in"><input id="nxpUrl" placeholder="Paste a Spotify, YouTube or MP3 link" autocomplete="off"><button class="btn small solid">Play</button></form>'+
    '<div class="nxp-row"><label class="btn small">⬆ Upload audio<input id="nxpFile" type="file" accept="audio/*" hidden></label><button class="btn small" id="nxpStop">■ Stop all</button></div>'+
    '<div class="mono dim tiny">AMBIENT · generated on-device, works offline</div><div class="nxp-amb"><button data-amb="rain">🌧 Rain</button><button data-amb="ocean">🌊 Ocean</button><button data-amb="brown">🧠 Deep focus</button><button data-amb="white">❄ White noise</button></div>'+
    '<input id="nxpVol" type="range" min="0" max="1" step="0.01" value="0.5" aria-label="Ambient volume"><div class="nxp-stage" id="nxpStage"></div></div>';
  document.body.append(P);
  var stage=P.querySelector('#nxpStage'), now=P.querySelector('#nxpNow');
  var setNow=function(t){ now.textContent=t; document.body.classList.toggle('nxp-has',t!=='Nothing playing'); };
  P.querySelector('.nxp-tab').onclick=function(){ P.classList.toggle('open'); };
  P.querySelector('.nxp-x').onclick=function(){ P.classList.remove('open'); };
  function playUrl(u){ u=(u||'').trim(); if(!u) return; var m, html='';
    if((m=u.match(/open\.spotify\.com\/(?:intl-\w+\/)?(track|playlist|album|episode|show|artist)\/([A-Za-z0-9]+)/))) { html='<iframe src="https://open.spotify.com/embed/'+m[1]+'/'+m[2]+'?utm_source=generator&theme=0" height="'+(m[1]==='track'?152:352)+'" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy"></iframe>'; setNow('Spotify '+m[1]); }
    else if((m=u.match(/(?:youtu\.be\/|youtube\.com\/(?:watch\?(?:.*&)?v=|embed\/|shorts\/|live\/)|music\.youtube\.com\/watch\?(?:.*&)?v=)([\w-]{11})/))) { html='<iframe src="https://www.youtube-nocookie.com/embed/'+m[1]+'?autoplay=1&playsinline=1" height="200" allow="autoplay; encrypted-media; picture-in-picture" allowfullscreen></iframe>'; setNow('YouTube'); }
    else if(/^https?:\/\//.test(u)||/^blob:/.test(u)) { html='<audio controls autoplay src="'+esc(u)+'"></audio>'; setNow('Audio stream'); }
    else { NX.toast('That doesn’t look like a Spotify, YouTube or audio link'); return; }
    stage.innerHTML=html; P.classList.add('open'); }
  NX.playMedia=playUrl;
  P.querySelector('.nxp-in').onsubmit=function(e){ e.preventDefault(); playUrl(P.querySelector('#nxpUrl').value); };
  P.querySelector('#nxpFile').onchange=function(){ var f=this.files&&this.files[0]; if(!f) return; stage.innerHTML='<audio controls autoplay src="'+URL.createObjectURL(f)+'"></audio>'; setNow(f.name.slice(0,40)); };
  var ac=null, src=null, gain=null;
  function amb(kind){ try{ if(!ac) ac=new (window.AudioContext||window.webkitAudioContext)(); if(ac.state==='suspended') ac.resume(); if(src){ src.stop(); src=null; }
    var len=ac.sampleRate*4, buf=ac.createBuffer(2,len,ac.sampleRate);
    for(var c=0;c<2;c++){ var d=buf.getChannelData(c), last=0, b0=0,b1=0,b2=0; for(var i=0;i<len;i++){ var w=Math.random()*2-1;
      if(kind==='white') d[i]=w*0.25; else if(kind==='brown'||kind==='ocean'){ last=(last+0.02*w)/1.02; d[i]=last*3.2; } else { b0=0.99765*b0+w*0.099; b1=0.963*b1+w*0.2965; b2=0.57*b2+w*1.0526; d[i]=(b0+b1+b2+w*0.1848)*0.06; } } }
    src=ac.createBufferSource(); src.buffer=buf; src.loop=true; gain=gain||ac.createGain(); gain.gain.value=+P.querySelector('#nxpVol').value; var node=src;
    if(kind==='rain'){ var f=ac.createBiquadFilter(); f.type='highpass'; f.frequency.value=900; node.connect(f); node=f; }
    if(kind==='brown'){ var lp=ac.createBiquadFilter(); lp.type='lowpass'; lp.frequency.value=500; node.connect(lp); node=lp; }
    if(kind==='ocean'){ var og=ac.createGain(), lfo=ac.createOscillator(), lg=ac.createGain(); lfo.frequency.value=0.09; lg.gain.value=0.45; og.gain.value=0.55; lfo.connect(lg); lg.connect(og.gain); lfo.start(); node.connect(og); node=og; }
    try{ gain.disconnect(); }catch(e){} node.connect(gain); gain.connect(ac.destination); src.start();
    P.querySelectorAll('[data-amb]').forEach(function(b){ b.classList.toggle('on',b.dataset.amb===kind); }); setNow('Ambient · '+kind); }catch(e){ NX.toast('Ambient sound isn’t available in this browser'); } }
  P.querySelector('.nxp-amb').onclick=function(e){ var b=e.target.closest('[data-amb]'); if(!b) return; if(b.classList.contains('on')){ if(src){src.stop();src=null;} b.classList.remove('on'); setNow('Nothing playing'); } else amb(b.dataset.amb); };
  P.querySelector('#nxpVol').oninput=function(){ if(gain) gain.gain.value=+this.value; };
  P.querySelector('#nxpStop').onclick=function(){ if(src){src.stop();src=null;} stage.innerHTML=''; P.querySelectorAll('[data-amb]').forEach(function(b){b.classList.remove('on');}); setNow('Nothing playing'); };
  var og=NX.go; NX.go=function(id){ var r=og.apply(this,arguments); document.body.classList.toggle('nxp-page',id==='music'); return r; }; document.body.classList.toggle('nxp-page',NX.current==='music');
  if(typeof NX.renderMusic==='function'){ var orm=NX.renderMusic; NX.renderMusic=function(v){ var r=orm.apply(this,arguments); try{ var h=v.querySelector('.hero'); if(h&&!h.querySelector('.nxp-open')){ var b=document.createElement('button'); b.className='btn solid nxp-open'; b.textContent='▶ Open player — Spotify · YouTube · Upload · Ambient'; b.onclick=function(){ P.classList.add('open'); }; h.append(b); } v.addEventListener('click',function(e){ var a=e.target.closest('a[href]'); if(a&&/spotify\.com|youtu/.test(a.href)){ e.preventDefault(); playUrl(a.href); } }); }catch(e){} return r; }; }

  /* ---------- Unique companion silhouettes (no more recolour clones) ---------- */
  var ACC=['<line x1="60" y1="24" x2="60" y2="8" style="stroke:var(--c1);stroke-width:3"/><circle cx="60" cy="6" r="4.5" style="fill:var(--c1)"/>',
    '<path d="M42 26 L46 8 L54 18 L60 4 L66 18 L74 8 L78 26 Z" style="fill:#ffd36b;stroke:var(--c4);stroke-width:1.5"/>',
    '<path d="M36 36 Q22 20 30 6 Q35 24 46 30Z M84 36 Q98 20 90 6 Q85 24 74 30Z" style="fill:var(--c1)"/>',
    '<ellipse cx="60" cy="9" rx="21" ry="5" style="fill:none;stroke:#ffe9a8;stroke-width:3"/>',
    '<path d="M32 42 L36 12 L53 30Z M88 42 L84 12 L67 30Z" style="fill:var(--c1);stroke:var(--c4);stroke-width:1.5"/>',
    '<rect x="44" y="0" width="32" height="20" rx="2" style="fill:var(--c3);stroke:var(--c1);stroke-width:2"/><rect x="36" y="18" width="48" height="5" rx="2" style="fill:var(--c3);stroke:var(--c1);stroke-width:2"/>',
    '<path d="M24 68 Q24 18 60 18 Q96 18 96 68" style="fill:none;stroke:var(--c1);stroke-width:5"/><rect x="15" y="58" width="14" height="24" rx="6" style="fill:var(--c1)"/><rect x="91" y="58" width="14" height="24" rx="6" style="fill:var(--c1)"/>',
    '<path d="M60 26 Q60 14 60 8" style="stroke:#6fd38a;stroke-width:3;fill:none"/><path d="M60 13 Q47 2 41 10 Q51 17 60 13Z M60 11 Q73 0 79 8 Q69 15 60 11Z" style="fill:#6fd38a"/>',
    '<path d="M60 22 L43 11 L43 33Z M60 22 L77 11 L77 33Z" style="fill:#ff7aa8"/><circle cx="60" cy="22" r="4.5" style="fill:#ff4f8b"/>',
    '<circle cx="76" cy="66" r="11" style="fill:none;stroke:#ffd36b;stroke-width:2.5"/><path d="M87 68 Q98 92 89 112" style="fill:none;stroke:#ffd36b;stroke-width:1.5"/>',
    '<path d="M47 28 L51 6 L56 25 L60 1 L64 25 L69 6 L73 28Z" style="fill:var(--c1)"/>',
    '<path d="M30 40 Q60 22 90 40 L94 50 Q60 36 26 50Z" style="fill:var(--c2);stroke:var(--c4);stroke-width:1.2"/><path d="M90 44 Q104 52 98 70" style="fill:none;stroke:var(--c2);stroke-width:4"/>'];
  var SX=[[1,1],[1.07,.95],[.93,1.06],[1.04,1.04],[.96,.98]];
  if(typeof NX.avatarSVG==='function'){ var oav=NX.avatarSVG; NX.avatarSVG=function(c){ var s=oav.apply(this,arguments); try{ if(!c||!c.id||c.kind==='astro'||typeof s!=='string'||s.indexOf('</g></svg>')<0) return s; var h=0; for(var i=0;i<c.id.length;i++) h=(h*31+c.id.charCodeAt(i))>>>0;
      var sc=SX[(h>>3)%SX.length], hue=((h>>6)%7-3)*12;
      return s.replace('<g class="cp-b">','<g class="cp-b" style="transform-box:view-box;transform-origin:60px 150px;scale:'+sc[0]+' '+sc[1]+';filter:hue-rotate('+hue+'deg)">').replace(/<\/g><\/svg>$/,'<g class="cp-acc">'+ACC[h%ACC.length]+'</g></g></svg>'); }catch(e){ return s; } }; }
})();
