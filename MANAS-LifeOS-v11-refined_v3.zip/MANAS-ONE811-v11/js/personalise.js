/* =========================================================
   VOICES, SOUNDS & PERSONALISATION
   - NX.sfx: synthesised sound signature per companion (WebAudio, no files).
   - NX.speak: free on-device text-to-speech (Web Speech API). Each companion
     has its own voice profile (pitch, rate, accent); user can override.
   - Studio › Voice & sound and Studio › Personalise.
   ========================================================= */
(function () {
  /* ---------------- sound engine ---------------- */
  let ac = null, noiseBuf = null;
  const ctx = () => { ac = ac || new (window.AudioContext || window.webkitAudioContext)(); if (ac.state === 'suspended') ac.resume(); return ac; };
  const vol = () => (NX.mx.vol ?? 70) / 100;
  const tone = (t, f, d, o = {}) => {
    const a = ctx(), osc = a.createOscillator(), g = a.createGain();
    osc.type = o.type || 'sine'; osc.frequency.setValueAtTime(f, t); if (o.f2) osc.frequency.exponentialRampToValueAtTime(o.f2, t + d);
    g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime((o.g ?? .06) * vol(), t + (o.att ?? .01)); g.gain.exponentialRampToValueAtTime(.0001, t + d);
    osc.connect(g).connect(a.destination); osc.start(t); osc.stop(t + d + .05);
  };
  const noise = (t, d, o = {}) => {
    const a = ctx();
    if (!noiseBuf) { noiseBuf = a.createBuffer(1, a.sampleRate, a.sampleRate); const ch = noiseBuf.getChannelData(0); for (let i = 0; i < ch.length; i++) ch[i] = Math.random() * 2 - 1; }
    const s = a.createBufferSource(), F = a.createBiquadFilter(), g = a.createGain();
    s.buffer = noiseBuf; s.loop = true; F.type = o.type || 'bandpass'; F.frequency.setValueAtTime(o.f || 1200, t); if (o.f2) F.frequency.exponentialRampToValueAtTime(o.f2, t + d); F.Q.value = o.q ?? 1;
    g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime((o.g ?? .05) * vol(), t + .01); g.gain.exponentialRampToValueAtTime(.0001, t + d);
    s.connect(F).connect(g).connect(a.destination); s.start(t); s.stop(t + d + .05);
  };
  const R = Math.random;
  const P = {
    beep: (t, b) => { for (let i = 0; i < 6; i++) { const d = .05 + R() * .09; tone(t, 700 + R() * 2200, d, { type: R() > .5 ? 'triangle' : 'sine', f2: 700 + R() * 2600, g: .05 }); t += d + R() * .04; } },
    pulse: (t, b) => [1, 1.25, 1.5].forEach((m, i) => tone(t + i * .12, b * m, .24, { g: .07 })),
    horn: (t, b) => { tone(t, b * .5, .22, { type: 'triangle', g: .03, f2: b * .75 }); tone(t + .24, b * .75, .45, { type: 'triangle', g: .03 }); tone(t + .24, b * 1.5, .45, { g: .03 }); },
    hoot: (t, b) => [0, .42].forEach(o => tone(t + o, b * .5, .34, { g: .1, f2: b * .42, att: .06 })),
    whoosh: (t, b) => { noise(t, .55, { f: 400, f2: 3200, q: .8, g: .09 }); tone(t + .1, b, .3, { type: 'triangle', f2: b * 2, g: .04 }); },
    flutter: (t, b) => { for (let i = 0; i < 6; i++) noise(t + i * .06, .05, { f: 900 + i * 120, q: 2, g: .07 }); tone(t + .38, b * 1.5, .2, { g: .03 }); },
    growl: (t, b) => { tone(t, b * .3, .55, { type: 'triangle', g: .05, f2: b * .22 }); noise(t, .45, { f: 280, q: 2, g: .035 }); },
    drone: (t, b) => { tone(t, b * .5, 1, { type: 'triangle', g: .022, att: .25 }); tone(t, b * .515, 1, { type: 'triangle', g: .022, att: .25 }); tone(t + .25, b * 1.5, .7, { g: .03, f2: b * 1.2 }); },
    bell: (t, b) => { [1, 2.76, 5.4].forEach((m, i) => tone(t, b * m, 1.2 - i * .3, { g: .06 / (i + 1), att: .003 })); tone(t + .38, b * 1.335, 1, { g: .04, att: .003 }); },
    static: (t, b) => { noise(t, .2, { f: 2500, q: .5, g: .08 }); tone(t + .22, b + 600, .08, { type: 'triangle', g: .03 }); tone(t + .32, b + 900, .08, { type: 'triangle', g: .03 }); noise(t + .44, .14, { f: 1800, q: .6, g: .07 }); },
    glitch: (t, b) => { for (let i = 0; i < 10; i++) tone(t + i * .035, b * (1 + Math.floor(R() * 4) / 2), .03, { type: 'triangle', g: .035 }); },
    boing: (t, b) => { tone(t, b * 1.5, .35, { f2: b * .5, g: .08 }); tone(t + .3, b, .22, { f2: b * 1.6, g: .05 }); },
    chime: (t, b) => [1, 1.5, 2, 2.5].forEach((m, i) => tone(t + i * .09, b * m, .7, { g: .045, att: .004 })),
    blip: (t, b) => tone(t, b, .12, { g: .06 }),
    click: (t, b) => { for (let i = 0; i < 5; i++) noise(t + i * .07 + R() * .03, .025, { f: b * 3, q: 3, g: .09 }); tone(t + .42, b * 2, .16, { g: .03, type: 'triangle' }); },
    crackle: (t, b) => { for (let i = 0; i < 14; i++) noise(t + R() * .6, .02 + R() * .03, { f: 800 + R() * 3000, q: 1, g: .07 }); noise(t, .6, { f: 300, type: 'lowpass', g: .03 }); },
    bubble: (t, b) => { for (let i = 0; i < 4; i++) tone(t + i * .11, b * (1 + R()), .08, { f2: b * (2.5 + R()), g: .06 }); },
    arp: (t, b) => [1, 1.25, 1.5, 2].forEach((m, i) => tone(t + i * .08, b * m, .15, { type: 'triangle', g: .05 })),
    chip: (t, b) => [1, 1.5, 1, 2, 1.5, 2.5].forEach((m, i) => tone(t + i * .06, b * m, .055, { type: 'triangle', g: .035 })),
    koto: (t, b) => [1, 1.125, 1.5, 1.6875].forEach((m, i) => { tone(t + i * .14, b * m, .5, { type: 'triangle', g: .06, att: .002 }); tone(t + i * .14, b * m * 2, .25, { g: .02, att: .002 }); }),
  };
  NX.sfxNames = { beep: 'Astromech beeps', pulse: 'Energy pulse', horn: 'Hero horn', hoot: 'Owl hoot', whoosh: 'Wing whoosh', flutter: 'Moth flutter', growl: 'Low growl', drone: 'Eerie drone', bell: 'Butler bell', static: 'Radio static', glitch: 'Glitch arpeggio', boing: 'Bouncy boing', chime: 'Crystal chime', blip: 'Soft blip', click: 'Typewriter clicks', crackle: 'Fire crackle', bubble: 'Bubbles', arp: 'Happy arpeggio', chip: '8-bit chiptune', koto: 'Plucked strings' };
  const KIND_SFX = { astro: 'beep', orb: 'pulse', visor: 'horn', owl: 'hoot', stone: 'drone', phoenix: 'whoosh', raven: 'growl', shade: 'drone', aide: 'bell', moth: 'flutter', radio: 'static', eye: 'drone', cat: 'boing', crt: 'glitch', lantern: 'chime', crystal: 'chime', cube: 'blip', quill: 'click', film: 'click', flame: 'crackle', fox: 'koto', jelly: 'bubble', sprout: 'arp', invader: 'chip', scarab: 'drone', helm: 'horn' };
  const ID_SFX = { lumen: 'blip', halo: 'arp', aurum: 'bell', nova: 'chime', orion: 'pulse', sunny: 'arp', kite: 'whoosh', mint: 'boing', pulse: 'pulse', nexus: 'chime', echo9: 'drone', static: 'static', cron: 'click', root: 'glitch', daemon: 'click', block: 'horn', slab: 'drone', sensei: 'koto', ronin: 'koto', iris: 'chime' };
  NX.sfxFor = c => (NX.mx.sfxOv || {})[c.id] || ID_SFX[c.id] || KIND_SFX[c.kind] || 'beep';
  NX.sfx = (c, force, kind) => {
    if (!c || (!force && NX.mx.sound === false)) return;
    try { const b = Math.min(1400, Math.max(160, (c.sound && c.sound.base) || 600)); (P[kind || NX.sfxFor(c)] || P.beep)(ctx().currentTime + .02, b); } catch (e) {}
  };

  /* ---------------- text to speech (on-device, free) ---------------- */
  const G = {
    gbM: ['Daniel', 'Arthur', 'Oliver', 'Google UK English Male', 'en-GB'], gbF: ['Serena', 'Kate', 'Martha', 'Stephanie', 'Google UK English Female', 'en-GB'],
    usM: ['Aaron', 'Alex', 'Evan', 'Nathan', 'Tom', 'Google US English', 'en-US'], usF: ['Samantha', 'Ava', 'Allison', 'Susan', 'Zoe', 'Google US English', 'en-US'],
    au: ['Karen', 'Lee', 'Catherine', 'en-AU'], in: ['Rishi', 'Isha', 'Veena', 'Lekha', 'en-IN'], ie: ['Moira', 'en-IE'], za: ['Tessa', 'en-ZA'],
    robot: ['Trinoids', 'Zarvox', 'Fred', 'Ralph', 'Junior', 'en-US'], whisper: ['Whisper', 'Moira', 'en-GB'], jp: ['Kyoko', 'Otoya', 'en-GB'],
  };
  // id: [voice group, pitch, rate]
  const V = {
    one811: ['robot', 1.6, 1.15], lumen: ['usF', 1, .95], prism: ['gbF', 1.2, 1], pebble: ['usF', 1, .9], halo: ['usF', 1.2, 1.05], breeze: ['au', .95, .85],
    sterling: ['gbM', .85, .92], aurum: ['gbM', .7, .9], velvet: ['whisper', .8, .85], glitch: ['robot', 1.3, 1.25], neon7: ['usM', .8, 1.1], byte: ['usF', 1.7, 1.2],
    quill: ['gbF', 1, 1.05], ledger: ['usM', .9, 1], margo: ['gbF', .85, .9], dot: ['usF', 1, .9], mono: ['usM', .9, .9], line: ['gbM', 1, .95],
    nova: ['usF', 1.3, .95], lyra: ['ie', 1.1, .9], orion: ['gbM', .8, .9], reel: ['usM', 1.1, 1.15], director: ['gbM', .6, .85], usher: ['gbF', 1, .95],
    block: ['usM', .5, .9], rivet: ['au', .9, 1.05], slab: ['usM', .4, .8], doodle: ['usF', 1.6, 1.15], blob: ['usF', 1.8, 1], pixel: ['in', 1.1, 1.05],
    daemon: ['robot', .8, 1], cron: ['robot', 1, 1.1], root: ['usM', .7, 1], sunny: ['au', 1.3, 1.1], kite: ['usF', 1.2, 1.05], mint: ['in', 1.2, 1],
    cinder: ['usM', 1, 1.15], forge: ['gbM', .5, .85], ash: ['gbF', .8, .8], vanguard: ['usM', .75, 1], pulse: ['usF', 1.3, 1.15], nexus: ['gbM', 1, 1],
    nightwatch: ['usM', .55, .9], shade: ['gbM', .45, .8], marlowe: ['gbM', .9, .92], wisp: ['gbF', 1.3, .95], runestone: ['gbM', .6, .85], emberwing: ['ie', 1.1, 1],
    static: ['robot', .9, 1.1], moth: ['usF', 1.4, 1], echo9: ['robot', 1.2, .9],
    kitsu: ['jp', 1.3, 1], ronin: ['gbM', .55, .85], sensei: ['jp', .8, .85], lumi: ['usF', 1.5, .9], nautilus: ['gbM', .65, .85], coral: ['au', 1.2, 1],
    fern: ['gbF', 1.1, .95], sol: ['za', 1.15, 1.05], wren: ['usF', 1.5, 1.1], player1: ['robot', 1.4, 1.2], combo: ['usM', 1.2, 1.25], bit: ['robot', 1.8, 1.1],
    khepri: ['gbM', .6, .85], nomad: ['in', .8, .9], mirage: ['whisper', 1.1, .85], pallas: ['gbF', .9, .9], helios: ['usM', .7, .95], iris: ['ie', 1.3, 1.05],
  };
  // v11: text-to-speech removed entirely. Companions talk through animated speech bubbles + soft UI sounds.
  NX.ttsSupported = false;
  NX.voiceProfile = c => { const d = V[c.id] || ['usF', 1, 1], ov = (NX.mx.voices || {})[c.id] || {}; return { pitch: ov.pitch ?? d[1], rate: ov.rate ?? d[2], voice: null }; };
  NX.speak = (text, c) => { if (NX.droid && NX.mx.droid) NX.droid.say(String(text || ''), true); else if (text) NX.toast(String(text).slice(0, 140)); NX.sfx && NX.sfx(c || NX.activeCompanion(), true); };
  NX.speakAuto = () => {};
  NX.stopSpeech = () => {};

  /* ---------------- personal touches ---------------- */
  const h0 = NX.haptic; NX.haptic = ms => (NX.mx.haptics === false ? 0 : h0 && h0(ms));
  const home0 = NX.renderHome;
  NX.renderHome = v => {
    home0(v);
    const t = (NX.mx.heroText || '').trim(), h = v.querySelector('.hero h1');
    if (t && h) h.innerHTML = NX.esc(t).replace(/\{name\}/gi, `<em>${NX.esc(NX.prefs.name || 'Manas')}</em>`);
  };
  NX.applyPersonal = () => { const b = document.body.dataset; b.rxspin = NX.mx.rxSpin || 'spin'; b.cpsize = NX.mx.cpSize || 'm'; b.mdock = NX.mx.mdockStyle || 'dock'; };

  /* ---------------- Studio › Voice & sound ---------------- */
  const opt = (v, l, cur) => `<option value="${NX.esc(v)}" ${v === cur ? 'selected' : ''}>${NX.esc(l)}</option>`;
  NX.studioVoiceHTML = () => {
    const c = NX.activeCompanion();
    return `<p class="dim tiny">Companions talk through animated speech bubbles and soft signature sounds — no robotic voices. Pick a mood in the music bar to change the soundtrack and the room.</p>
      <div class="vx-hero" style="${NX.cpVars(c)}"><div class="cp-av sm">${NX.avatarSVG(c)}</div><div><b>${NX.esc(c.name)}</b><div class="mono dim">${NX.esc(c.role)} · ${NX.esc(NX.world().name)}</div></div></div>
      <label class="field"><span class="mono dim">${NX.esc(c.name)}'s sound</span><select id="vxSfx">${Object.entries(NX.sfxNames).map(([k, l]) => opt(k, l, NX.sfxFor(c))).join('')}</select></label>
      <label class="field"><span class="mono dim">Volume · <b id="vxVv">${NX.mx.vol ?? 70}</b>%</span><input type="range" id="vxVol" min="0" max="100" value="${NX.mx.vol ?? 70}"></label>
      <div class="actions"><button class="btn" id="vxSnd">♪ Play sound</button><button class="btn solid" id="vxTry">💬 Say hello</button><button class="btn" id="vxReset">Reset to ${NX.esc(c.name)}'s default</button></div>`;
  };
  NX.wireStudioVoice = (sb, re) => {
    const c = NX.activeCompanion(), q = id => sb.querySelector('#' + id);
    sb.querySelectorAll('[data-tts]').forEach(b => b.onclick = () => { NX.mx.tts = b.dataset.tts; NX.saveMx(); re(); });
    if (!q('vxSfx')) return;
    if (q('vxVoice')) {
      q('vxVoice').onchange = e => setVo(c, { name: e.target.value || undefined });
      q('vxPitch').oninput = e => { setVo(c, { pitch: +e.target.value }); q('vxPv').textContent = (+e.target.value).toFixed(2); };
      q('vxRate').oninput = e => { setVo(c, { rate: +e.target.value }); q('vxRv').textContent = (+e.target.value).toFixed(2); };
    }
    q('vxSfx').onchange = e => { NX.mx.sfxOv = Object.assign({}, NX.mx.sfxOv, { [c.id]: e.target.value }); NX.saveMx(); NX.sfx(c, true); };
    q('vxVol').oninput = e => { NX.mx.vol = +e.target.value; q('vxVv').textContent = e.target.value; NX.saveMx(); };
    q('vxVol').onchange = () => NX.sfx(c, true);
    q('vxSnd').onclick = () => NX.sfx(c, true);
    q('vxTry').onclick = () => NX.speak(NX.cpGreet(c) + ' ' + c.sign, c, true);
    q('vxReset').onclick = () => { if (NX.mx.voices) delete NX.mx.voices[c.id]; if (NX.mx.sfxOv) delete NX.mx.sfxOv[c.id]; NX.saveMx(); re(); NX.toast(`${c.name}'s voice reset`); };
  };

  /* ---------------- Studio › Personalise ---------------- */
  NX.studioPersonalHTML = () => {
    const items = NX.navItemsAll ? NX.navItemsAll() : [], hid = NX.mx.navHidden || [], w = NX.world(), fo = (NX.mx.fonts || {})[w.id] || '';
    const chips = (key, list, cur) => `<div class="chips">${list.map(([v, l]) => `<button class="chip ${cur === v ? 'on' : ''}" data-ps="${key}" data-v="${v}">${l}</button>`).join('')}</div>`;
    return `<p class="dim tiny">Make MANAS.ONE811 yours. Everything here is saved in this browser and included in your backup.</p>
      <div class="field"><span class="mono dim">Phone navigation style</span>${chips('mdockStyle', [['dock', 'Floating dock'], ['bar', 'Edge tab bar'], ['icons', 'Icons only'], ['launcher', 'Launcher button']], NX.mx.mdockStyle || 'dock')}</div>
      <div class="field"><span class="mono dim">Pages in navigation — reorder or hide</span><div class="rows ps-nav">${items.map((m, i) => { const lock = m.id === 'home' || m.id === '__studio'; return `<div class="row"><span class="ps-ico">${m.icon}</span><div class="grow"><div class="t">${NX.esc(m.name)}</div></div><button class="btn small" data-nv="up" data-id="${m.id}" ${i ? '' : 'disabled'} aria-label="Move ${NX.esc(m.name)} up">↑</button><button class="btn small" data-nv="dn" data-id="${m.id}" ${i < items.length - 1 ? '' : 'disabled'} aria-label="Move ${NX.esc(m.name)} down">↓</button><input type="checkbox" data-nv-show="${m.id}" ${hid.includes(m.id) ? '' : 'checked'} ${lock ? 'disabled' : ''} aria-label="Show ${NX.esc(m.name)}"></div>`; }).join('')}</div>
        <div class="actions"><button class="btn small" id="psNavReset">Reset order</button></div></div>
      <label class="field"><span class="mono dim">Home headline (use {name}; leave empty for automatic)</span><input id="psHero" maxlength="80" placeholder="e.g. Build the empire, {name}." value="${NX.esc(NX.mx.heroText || '')}"></label>
      <div class="field"><span class="mono dim">Reactor orbit</span>${chips('rxSpin', [['spin', 'Spinning'], ['slow', 'Slow'], ['still', 'Still']], NX.mx.rxSpin || 'spin')}</div>
      <div class="field"><span class="mono dim">Companion size</span>${chips('cpSize', [['s', 'Small'], ['m', 'Medium'], ['l', 'Large']], NX.mx.cpSize || 'm')}</div>
      <label class="field"><span class="mono dim">Font for ${NX.esc(w.name)}</span><select id="psFont"><option value="">World default</option>${NX.fonts.map(f => opt(f[0], f[1], fo)).join('')}</select></label>
      <div class="rows">
        <label class="row"><div class="grow"><div class="t">Haptic taps</div><div class="s">Small vibrations on supported phones</div></div><input type="checkbox" id="psHap" ${NX.mx.haptics === false ? '' : 'checked'}></label>
        <button class="row" id="psDroidPos"><div class="grow"><div class="t">Reset companion position</div><div class="s">Moves your companion back to its corner</div></div><span>↺</span></button>
      </div>`;
  };
  NX.wireStudioPersonal = (sb, re) => {
    sb.querySelectorAll('[data-ps]').forEach(b => b.onclick = () => { NX.mx[b.dataset.ps] = b.dataset.v; NX.saveMx(); NX.applyPersonal(); NX.renderNav(); re(); });
    sb.querySelectorAll('[data-nv]').forEach(b => b.onclick = () => {
      const ids = NX.navItemsAll().map(m => m.id), i = ids.indexOf(b.dataset.id), j = b.dataset.nv === 'up' ? i - 1 : i + 1;
      if (i < 0 || j < 0 || j >= ids.length) return; [ids[i], ids[j]] = [ids[j], ids[i]]; NX.mx.navOrder = ids; NX.saveMx(); NX.renderNav(); re();
    });
    sb.querySelectorAll('[data-nv-show]').forEach(b => b.onchange = () => { const s = new Set(NX.mx.navHidden || []); b.checked ? s.delete(b.dataset.nvShow) : s.add(b.dataset.nvShow); NX.mx.navHidden = [...s]; NX.saveMx(); NX.renderNav(); });
    const q = id => sb.querySelector('#' + id);
    if (!q('psHero')) return;
    q('psNavReset').onclick = () => { NX.mx.navOrder = []; NX.mx.navHidden = []; NX.saveMx(); NX.renderNav(); re(); };
    q('psHero').onchange = e => { NX.mx.heroText = e.target.value; NX.saveMx(); if (NX.current === 'home') NX.go('home', false); NX.toast('Headline saved'); };
    q('psFont').onchange = e => { NX.mx.fonts = Object.assign({}, NX.mx.fonts, { [NX.world().id]: e.target.value }); if (!e.target.value) delete NX.mx.fonts[NX.world().id]; NX.saveMx(); NX.applyWorld(); };
    q('psHap').onchange = e => { NX.mx.haptics = e.target.checked; NX.saveMx(); };
    q('psDroidPos').onclick = () => { localStorage.removeItem('manas.droidpos'); const d = document.getElementById('droid'); if (d) { d.classList.remove('placed'); d.style.left = d.style.top = ''; } NX.toast('Companion is back in its corner'); };
  };
})();
