/* =========================================================
   FX — the living particle "aura" behind everything + spotlight on shards.
   v11: parses ANY colour format (hex3/4/6/8, rgb[a], hsl[a], named) by
   letting the browser resolve it; speed / density / mood are live tunables.
   ========================================================= */
(function () {
  const cv = document.getElementById('aura'), ctx = cv.getContext('2d');
  let W, H, pts = [], touch = { x: -999, y: -999 }, color = '126,224,255', color2 = '163,255,207';
  const DPR = () => Math.min(2, devicePixelRatio || 1);
  const resize = () => { const d = DPR(); W = cv.width = innerWidth * d; H = cv.height = innerHeight * d; cv.style.width = innerWidth + 'px'; cv.style.height = innerHeight + 'px'; };
  resize(); addEventListener('resize', () => { resize(); seed(); }, { passive: true });

  const tune = () => { const a = (window.NX && NX.mx && NX.mx.aura) || {}; return { speed: a.speed ?? 1, density: a.density ?? 1, links: a.links !== false }; };
  const seed = () => {
    const t = tune(), N = Math.round(Math.min(64, Math.floor(innerWidth / 24)) * Math.max(0, Math.min(2, t.density)));
    while (pts.length < N) pts.push({ x: Math.random() * W, y: Math.random() * H, vx: (Math.random() - .5) * .3, vy: (Math.random() - .5) * .3, r: Math.random() * 1.6 + .4, k: Math.random() < .3 });
    pts.length = N;
  };
  NX.reseedAura = seed; seed();

  // Resolve any CSS colour to "r,g,b" using a 1px canvas (handles hex/rgb/hsl/named/var-resolved).
  const probe = document.createElement('canvas').getContext('2d');
  const toRGB = c => {
    c = (c || '').trim(); if (!c) return null;
    const m = c.match(/^#([0-9a-f]{3,8})$/i);
    if (m) { let h = m[1]; if (h.length <= 4) h = h.split('').map(x => x + x).join(''); return [0, 2, 4].map(i => parseInt(h.substr(i, 2), 16)).join(','); }
    const r = c.match(/^rgba?\(\s*([\d.]+)[ ,]+([\d.]+)[ ,]+([\d.]+)/i); if (r) return [r[1], r[2], r[3]].map(n => Math.round(+n)).join(',');
    try { probe.fillStyle = '#000'; probe.fillStyle = c; const v = probe.fillStyle; if (v[0] === '#') return toRGB(v); const q = v.match(/rgba?\(([^)]+)\)/); if (q) return q[1].split(',').slice(0, 3).map(n => Math.round(+n)).join(','); } catch (e) {}
    return null;
  };
  NX.toRGB = toRGB;
  NX.refreshAuraColor = () => {
    const read = (el, k) => getComputedStyle(el).getPropertyValue(k).trim();
    const a1 = read(document.body, '--a1') || read(document.documentElement, '--a1');
    const a2 = read(document.body, '--a2') || read(document.documentElement, '--a2');
    color = toRGB(a1) || color; color2 = toRGB(a2) || color;
  };
  const move = e => { const p = e.touches ? e.touches[0] : e, d = DPR(); touch.x = p.clientX * d; touch.y = p.clientY * d;
    const s = e.target && e.target.closest && e.target.closest('.shard'); if (s) { const r = s.getBoundingClientRect(); s.style.setProperty('--mx', p.clientX - r.left + 'px'); s.style.setProperty('--my', p.clientY - r.top + 'px'); } };
  addEventListener('pointermove', move, { passive: true });

  let frame, last = 0;
  const loop = now => {
    if (document.hidden || document.body.classList.contains('no-aura') || matchMedia('(prefers-reduced-motion: reduce)').matches) { frame = 0; return; }
    frame = requestAnimationFrame(loop);
    if (now - last < 15) return; last = now;
    const t = tune(), sp = Math.max(0, Math.min(3, t.speed * (NX.auraMoodK || 1))), d = DPR();
    ctx.clearRect(0, 0, W, H);
    const D = 120 * d;
    for (const p of pts) {
      const dx = p.x - touch.x, dy = p.y - touch.y, dd = Math.hypot(dx, dy);
      if (dd < D && dd > 0) { p.vx += dx / dd * .06; p.vy += dy / dd * .06; }
      p.vx *= .985; p.vy *= .985; p.x += (p.vx + .05) * sp; p.y += (p.vy - .04) * sp;
      if (p.x < 0) p.x = W; if (p.x > W) p.x = 0; if (p.y < 0) p.y = H; if (p.y > H) p.y = 0;
      ctx.fillStyle = `rgba(${p.k ? color2 : color},.7)`; ctx.beginPath(); ctx.arc(p.x, p.y, p.r * d, 0, 7); ctx.fill();
    }
    if (t.links) { ctx.lineWidth = d * .6;
      for (let i = 0; i < pts.length; i++) for (let j = i + 1; j < pts.length; j++) {
        const a = pts[i], b = pts[j], dx = a.x - b.x, dy = a.y - b.y; if (Math.abs(dx) > D || Math.abs(dy) > D) continue; const dd = Math.hypot(dx, dy);
        if (dd < D) { ctx.strokeStyle = `rgba(${color},${.14 * (1 - dd / D)})`; ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke(); }
      } }
  };
  NX.kickAura = () => { if (!frame) frame = requestAnimationFrame(loop); };
  document.addEventListener('visibilitychange', NX.kickAura);
  frame = requestAnimationFrame(loop);
})();

NX.haptic = (ms = 8) => { try { navigator.vibrate && navigator.vibrate(ms); } catch (e) {} };
