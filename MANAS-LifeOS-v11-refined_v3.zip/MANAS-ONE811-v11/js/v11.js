/* =========================================================
   V11 — loaded last. Adds, without rewriting the core:
   1. Gamification engine (XP, levels, streaks, quests, achievements, FX)
   2. Character cameos with praise
   3. Interactive companion actions (high five, celebrate, joke, AI chat)
   4. Proactive wellness care (water, meals, posture, stretch)
   5. Mood engine — music + room + aura follow your mood
   6. Studio Zero — live control deck (nav, accent, aura, radius, contrast, density)
   7. World atmospherics — Golden Snitch, collectible sparks
   ========================================================= */
(function () {
  const $ = s => document.querySelector(s);
  const esc = NX.esc;
  const today = () => NX.today();
  const yday = () => { const d = new Date(); d.setDate(d.getDate() - 1); return [d.getFullYear(), String(d.getMonth() + 1).padStart(2, '0'), String(d.getDate()).padStart(2, '0')].join('-'); };
  const reduced = () => NX.mx.motion === 'off' || matchMedia('(prefers-reduced-motion: reduce)').matches;
  const pick = a => a[Math.floor(Math.random() * a.length)];
  const lastPt = { x: innerWidth / 2, y: innerHeight / 2 };
  addEventListener('pointerdown', e => { lastPt.x = e.clientX; lastPt.y = e.clientY; }, { passive: true, capture: true });

  /* ============ 1. GAMIFICATION ============ */
  const GK = 'manas.gamify';
  const G = Object.assign({ xp: 0, streak: 0, best: 0, lastDay: '', counts: {}, badges: {}, day: '', dayCounts: {}, worlds: [], moods: [], log: [] },
    (() => { try { return JSON.parse(localStorage.getItem(GK) || '{}'); } catch (e) { return {}; } })());
  const saveG = () => { try { localStorage.setItem(GK, JSON.stringify(G)); } catch (e) {} };
  const TITLES = ['Novice', 'Apprentice', 'Initiate', 'Adept', 'Seeker', 'Pathfinder', 'Artisan', 'Strategist', 'Vanguard', 'Sentinel', 'Luminary', 'Virtuoso', 'Sage', 'Paragon', 'Archon', 'Mythic', 'Ascendant', 'Titan', 'Grandmaster', 'Legend'];
  const need = l => Math.round(60 * Math.pow(l, 1.45)); // xp to go from level l to l+1
  const levelOf = xp => { let l = 1, acc = 0; while (xp >= acc + need(l)) { acc += need(l); l++; } return { level: l, into: xp - acc, span: need(l), title: TITLES[Math.min(l, 20) - 1] + (l > 20 ? ' ' + (l - 19) : '') }; };
  NX.gamify = { state: G, levelOf, XP: { task: 25, habit: 15, journal: 20, streak: 50, hi5: 10, goal: 50, water: 5, spark: 5, snitch: 15, chat: 5, record: 5 } };
  const XP = NX.gamify.XP;
  const QUESTS = [
    ['task', 3, 'Complete 3 tasks', '◇'], ['habit', 1, 'Log a workout or habit', '⚡'], ['journal', 1, 'Write a note or memory', '✎'],
    ['water', 4, 'Drink 4 glasses of water', '💧'], ['chat', 1, 'Talk to your companion', '💬'],
  ];
  const BADGES = [
    ['first', 'First Blood', 'Complete your first task', g => (g.counts.task || 0) >= 1, '🗡'],
    ['ten', 'Momentum', '10 tasks completed', g => (g.counts.task || 0) >= 10, '🚀'],
    ['fifty', 'Unstoppable', '50 tasks completed', g => (g.counts.task || 0) >= 50, '🏆'],
    ['s3', 'On Fire', '3-day streak', g => g.best >= 3, '🔥'], ['s7', 'Week Warrior', '7-day streak', g => g.best >= 7, '⚔'], ['s30', 'Iron Will', '30-day streak', g => g.best >= 30, '🛡'],
    ['l5', 'Rising', 'Reach level 5', g => levelOf(g.xp).level >= 5, '⭐'], ['l10', 'Ascended', 'Reach level 10', g => levelOf(g.xp).level >= 10, '🌟'], ['l20', 'Legend', 'Reach level 20', g => levelOf(g.xp).level >= 20, '👑'],
    ['hi5', 'High-Five Club', '10 high fives', g => (g.counts.hi5 || 0) >= 10, '✋'], ['hydra', 'Hydra-ted', '20 glasses of water', g => (g.counts.water || 0) >= 20, '💧'],
    ['voyager', 'World Voyager', 'Visit 6 different worlds', g => (g.worlds || []).length >= 6, '🌍'], ['dj', 'Mood DJ', 'Try all 5 moods', g => (g.moods || []).length >= 5, '🎧'],
    ['seeker', 'Snitch Seeker', 'Catch the Golden Snitch', g => (g.counts.snitch || 0) >= 1, '✨'], ['talker', 'Kindred Spirit', '10 chats with your companion', g => (g.counts.chat || 0) >= 10, '🫂'],
    ['quest', 'Quest Master', 'Finish every daily quest in one day', g => !!g.badges._allq, '📜'],
  ];
  const rollDay = () => { if (G.day !== today()) { G.day = today(); G.dayCounts = {}; } };
  const touchStreak = () => {
    const t = today(); if (G.lastDay === t) return 0;
    G.streak = G.lastDay === yday() ? G.streak + 1 : 1; G.best = Math.max(G.best, G.streak); G.lastDay = t; return G.streak;
  };
  NX.award = (amt, reason, kind, at) => {
    rollDay(); const before = levelOf(G.xp).level;
    const st = touchStreak();
    G.xp += amt; if (kind) { G.counts[kind] = (G.counts[kind] || 0) + 1; G.dayCounts[kind] = (G.dayCounts[kind] || 0) + 1; }
    G.log.unshift({ t: Date.now(), amt, reason }); G.log.length = Math.min(G.log.length, 40);
    floatXP('+' + amt + ' XP', at || lastPt); burst(at || lastPt, kind === 'task' ? 26 : 14);
    NX.sfxSoft && NX.sfxSoft('coin');
    if (st) setTimeout(() => { G.xp += XP.streak; saveG(); floatXP(`🔥 ${st}-day streak +${XP.streak}`, { x: innerWidth / 2, y: innerHeight * .35 }); paintChip(); }, 700);
    if (QUESTS.every(([k, n]) => (G.dayCounts[k] || 0) >= n) && !G.dayCounts._q) { G.dayCounts._q = 1; G.badges._allq = 1; G.xp += 100; setTimeout(() => banner('📜', 'All daily quests complete', '+100 XP bonus'), 1200); }
    const after = levelOf(G.xp).level;
    if (after > before) setTimeout(() => levelUp(after), 500);
    BADGES.forEach(([id, name, desc, test, ico]) => { if (!G.badges[id] && test(G)) { G.badges[id] = Date.now(); setTimeout(() => banner(ico, 'Achievement · ' + name, desc), 1600); } });
    saveG(); paintChip(); if (NX.current === 'home') paintHomeCard();
  };

  /* --- FX layer --- */
  const fx = document.createElement('div'); fx.id = 'v11fx'; fx.setAttribute('aria-hidden', 'true'); document.body.append(fx);
  const floatXP = (txt, p) => { const b = document.createElement('div'); b.className = 'v11-xp'; b.textContent = txt; b.style.left = p.x + 'px'; b.style.top = p.y + 'px'; fx.append(b); setTimeout(() => b.remove(), 1500); };
  const burst = (p, n = 18) => {
    if (reduced()) return;
    for (let i = 0; i < n; i++) { const s = document.createElement('i'); s.className = 'v11-spark' + (i % 3 === 0 ? ' c2' : i % 5 === 0 ? ' c3' : ''); const a = Math.random() * Math.PI * 2, d = 40 + Math.random() * 90;
      s.style.cssText = `left:${p.x}px;top:${p.y}px;--dx:${Math.cos(a) * d}px;--dy:${Math.sin(a) * d - 30}px;--r:${Math.random() * 720 - 360}deg`; fx.append(s); setTimeout(() => s.remove(), 1100); }
  };
  NX.burst = burst; NX.floatXP = floatXP;
  const banner = (ico, title, sub) => {
    const b = document.createElement('div'); b.className = 'v11-banner'; b.innerHTML = `<span class="ico">${ico}</span><div><b>${esc(title)}</b><small>${esc(sub)}</small></div>`;
    document.body.append(b); requestAnimationFrame(() => b.classList.add('in')); setTimeout(() => { b.classList.remove('in'); setTimeout(() => b.remove(), 500); }, 3600);
  };
  NX.banner = banner;
  const levelUp = l => {
    const lv = levelOf(G.xp); const o = document.createElement('div'); o.className = 'v11-levelup';
    o.innerHTML = `<div class="ring"><b>${l}</b></div><h2>Level up!</h2><p>You are now <em>${esc(lv.title)}</em></p>`; document.body.append(o);
    for (let i = 0; i < 4; i++) setTimeout(() => burst({ x: innerWidth * (.2 + Math.random() * .6), y: innerHeight * (.25 + Math.random() * .3) }, 22), i * 180);
    NX.music && NX.music.chime && NX.music.chime(); o.onclick = () => o.remove(); setTimeout(() => o.classList.add('out'), 2600); setTimeout(() => o.remove(), 3200);
  };

  /* --- XP chip in the top strip + quest sheet --- */
  const chip = document.createElement('button'); chip.id = 'v11chip'; chip.className = 'v11-chip'; chip.setAttribute('aria-label', 'Level, XP and quests');
  const paintChip = () => { const lv = levelOf(G.xp); chip.innerHTML = `<b>Lv ${lv.level}</b><i style="--p:${Math.round(lv.into / lv.span * 100)}%"></i>${G.streak ? `<span>🔥${G.streak}</span>` : ''}`; };
  chip.onclick = () => openQuests();
  const aiBtn = document.createElement('button'); aiBtn.className = 'ghost-ico v11-ai-btn'; aiBtn.id = 'v11ai'; aiBtn.title = 'Talk to your companion'; aiBtn.setAttribute('aria-label', 'Talk to your companion'); aiBtn.textContent = '✦'; aiBtn.onclick = () => NX.openChat();
  const zBtn = document.createElement('button'); zBtn.className = 'ghost-ico'; zBtn.id = 'v11zero'; zBtn.title = 'Studio Zero — customise everything'; zBtn.setAttribute('aria-label', 'Studio Zero — customise everything'); zBtn.textContent = '⚙'; zBtn.onclick = () => NX.openZero();
  const mountStrip = () => { const s = document.querySelector('.strip'), sb = document.getElementById('searchBtn'); if (!s || !sb) return; if (!chip.isConnected) s.insertBefore(chip, sb.parentNode === s ? sb : null); if (!aiBtn.isConnected) s.insertBefore(aiBtn, sb.parentNode === s ? sb : null); if (!zBtn.isConnected) s.insertBefore(zBtn, sb.parentNode === s ? sb : null); };
  paintChip();

  const openQuests = () => {
    rollDay(); const lv = levelOf(G.xp);
    NX.openSheet(`<div class="v11-q"><div class="sheet-h"><h2>Your journey</h2><button class="btn small" data-close>Close</button></div>
      <div class="v11-lv"><div class="v11-lv-ring" style="--p:${lv.into / lv.span * 360}deg"><b>${lv.level}</b></div><div class="grow"><div class="t">${esc(lv.title)}</div><div class="mono dim">${lv.into} / ${lv.span} XP to level ${lv.level + 1} · ${G.xp} total</div>${NX.bar(lv.into / lv.span * 100)}</div></div>
      <div class="v11-stats"><div><b>🔥 ${G.streak}</b><small>day streak</small></div><div><b>🏅 ${G.best}</b><small>best streak</small></div><div><b>◇ ${G.counts.task || 0}</b><small>tasks done</small></div><div><b>💧 ${G.counts.water || 0}</b><small>glasses</small></div></div>
      <div class="section-h"><h2>Daily quests</h2></div><div class="rows">${QUESTS.map(([k, n, label, ico]) => { const c = Math.min(n, G.dayCounts[k] || 0); return `<div class="row v11-quest ${c >= n ? 'done' : ''}"><span class="ps-ico">${ico}</span><div class="grow"><div class="t">${label}</div>${NX.bar(c / n * 100)}</div><span class="mono">${c}/${n}</span></div>`; }).join('')}</div>
      <p class="dim tiny">Finish all five for a +100 XP bonus. XP: task +${XP.task}, workout/habit +${XP.habit}, note/memory +${XP.journal}, daily streak +${XP.streak}.</p>
      <div class="section-h"><h2>Achievements · ${BADGES.filter(b => G.badges[b[0]]).length}/${BADGES.length}</h2></div>
      <div class="v11-badges">${BADGES.map(([id, name, desc, , ico]) => `<div class="v11-badge ${G.badges[id] ? 'on' : ''}" title="${esc(desc)}"><span>${ico}</span><b>${esc(name)}</b><small>${esc(desc)}</small></div>`).join('')}</div>
      <div class="section-h"><h2>Recent XP</h2></div><div class="rows">${G.log.slice(0, 8).map(l => `<div class="row"><div class="grow"><div class="t">${esc(l.reason)}</div><div class="s">${new Date(l.t).toLocaleString('en-IN', { hour: '2-digit', minute: '2-digit', day: 'numeric', month: 'short' })}</div></div><b class="mono">+${l.amt}</b></div>`).join('') || '<div class="empty">Complete a task to earn your first XP.</div>'}</div></div>`);
    document.querySelector('#sheetBody [data-close]')?.addEventListener('click', () => NX.closeSheet());
  };
  NX.openQuests = openQuests;

  /* --- Hook record writes --- */
  const up0 = NX.upsert;
  NX.upsert = rec => {
    const before = rec && rec.id ? NX.get(rec.id) : null;
    const prev = before ? { ...before } : null;
    const out = up0(rec);
    try {
      const r = rec || {}, t = r.type;
      if (t === 'task' && r.status === 'Completed' && (!prev || prev.status !== 'Completed')) { NX.award(XP.task, 'Task · ' + (r.title || 'done'), 'task'); setTimeout(() => cameo(), 650); }
      else if (!prev && !r.demo) {
        if (['workout', 'supplement', 'habit', 'bodymetric', 'body'].includes(t)) NX.award(XP.habit, 'Habit logged · ' + (r.title || t), 'habit');
        else if (['note', 'memory', 'journal'].includes(t)) NX.award(XP.journal, 'Journal · ' + (r.title || 'entry'), 'journal');
        else if (t && t !== 'task') NX.award(XP.record, 'Added · ' + (r.title || t), 'record');
      }
      if (t === 'goal' && +r.progress >= 100 && (!prev || +prev.progress < 100)) { NX.award(XP.goal, 'Goal achieved · ' + (r.title || ''), 'goal'); setTimeout(() => cameo(), 650); }
    } catch (e) {}
    return out;
  };

  /* ============ 2. CHARACTER CAMEOS ============ */
  const CAMEOS = {
    wizard: ['Albus Dumbledore', '🧙', ['10 points to Gryffindor!', 'Happiness can be found even in the darkest of times — and in a finished task.', 'It is our choices that show what we truly are. Good choice.']],
    middleearth: ['Gandalf', '🧙‍♂️', ['A task completed precisely when meant to be.', 'All we have to decide is what to do with the time given us. Well decided.', 'Even the smallest person can change the course of the future.']],
    westeros: ['Tyrion Lannister', '🍷', ['A mind needs books as a sword needs a whetstone — well done.', 'Never forget what you are. Today, you are productive.', 'I drink and I know things. You finish things.']],
    bakerst: ['Sherlock Holmes', '🔍', ['Elementary execution.', 'You see, but you also observe. Excellent.', 'The game is afoot — and you are winning it.']],
    heisenberg: ['Walter White', '⚗️', ["You're goddamn right.", 'Ninety-nine point one percent pure productivity.', 'Say my name. …Exactly. Task complete.']],
    heist: ['The Professor', '🎭', ['Everything is going according to plan.', 'Phase one complete. Proceed to phase two.', 'Bella ciao to that task.']],
  };
  const cameo = (forceKey) => {
    const w = NX.mx.world, key = forceKey || (CAMEOS[w] ? w : pick(Object.keys(CAMEOS)));
    const [name, ico, lines] = CAMEOS[key];
    const el = document.createElement('div'); el.className = 'v11-cameo'; el.innerHTML = `<div class="av">${ico}</div><div><b>${esc(name)}</b><p>“${esc(pick(lines))}”</p></div>`;
    document.body.append(el); requestAnimationFrame(() => el.classList.add('in'));
    el.onclick = () => el.remove(); setTimeout(() => { el.classList.remove('in'); setTimeout(() => el.remove(), 600); }, 4200);
  };
  NX.cameo = cameo;

  /* ============ 3. COMPANION ACTIONS ============ */
  const JOKES = {
    default: ['I told my to-do list a joke. It didn’t laugh — it just got shorter.', 'Why did the calendar break up with the clock? It felt its days were numbered.', 'I’m not procrastinating. I’m doing side quests.', 'My code has no bugs. Only surprise features.'],
    wizard: ['Why did the wizard fail the exam? He was bad at spell-ing.', 'Hogwarts Wi-Fi password? Alohomora.'], middleearth: ['One does not simply… skip breakfast.', 'Second breakfast is not a meal. It is a lifestyle.'],
    westeros: ['Winter is coming. So is your deadline — but you’ll beat it.', 'In the game of tasks, you win or you reschedule.'], bakerst: ['I deduce you need a coffee. Elementary.', 'When you eliminate the impossible, what remains is… your inbox.'],
    heisenberg: ['I am the one who… checks things off.', 'Chemistry joke? All the good ones argon.'], heist: ['The Professor has a plan B. And C. And a snack plan.', 'We steal time, not gold.'],
  };
  const jokeFor = () => pick(JOKES[NX.mx.world] || JOKES.default);
  const droidEl = () => document.getElementById('droid');
  const cmpName = () => (NX.activeCompanion ? NX.activeCompanion().name : 'ONE-811');
  const say = (msg, actions) => { if (NX.droid && NX.mx.droid) NX.droid.say(msg, true, actions); else NX.toast(msg); };
  const anim = cls => { const d = droidEl(); if (!d) return; d.classList.remove(cls); void d.offsetWidth; d.classList.add(cls); setTimeout(() => d.classList.remove(cls), 1300); };
  const droidPt = () => { const d = droidEl()?.querySelector('.dr-bot'); if (!d) return lastPt; const r = d.getBoundingClientRect(); return { x: r.left + r.width / 2, y: r.top + r.height * .4 }; };
  NX.companionAct = k => {
    if (k === 'hi5') { anim('v11-hi5'); const p = droidPt(); const s = document.createElement('div'); s.className = 'v11-slap'; s.textContent = '✋'; s.style.left = p.x + 'px'; s.style.top = p.y + 'px'; fx.append(s); setTimeout(() => s.remove(), 900);
      NX.award(XP.hi5, 'High five with ' + cmpName(), 'hi5', p); setTimeout(() => say(pick(['Up top! ✋', 'Yesss! That’s the energy.', 'Boom. Partners in productivity.', 'Legendary high five.'])), 350); }
    if (k === 'cheer') { anim('v11-spin'); for (let i = 0; i < 3; i++) setTimeout(() => burst(droidPt(), 20), i * 220); NX.music && NX.music.chime(); say(pick(['🎉 Woo-hoo! Look at you go!', 'Celebration protocol engaged!', 'Every win counts. This one too.'])); }
    if (k === 'joke') { anim('hop'); say('💬 ' + jokeFor(), [['v11joke', '😂 Another'], ['v11hi5', '✋ High five']]); }
    if (k === 'chat') NX.openChat();
    if (k === 'mood') NX.openMood();
    if (k === 'water') { NX.award(XP.water, 'Glass of water 💧', 'water'); say(pick(['Hydration level: excellent. 💧', 'Your brain says thank you.', 'Sip logged. Keep flowing.'])); }
    if (k === 'later') say('No worries — I’ll check back soon.');
    if (k === 'stretch') { NX.award(XP.water, 'Stretch break', 'stretch'); say('Shoulders down, chin tucked, deep breath. Nice. 🧘'); }
    if (k === 'ate') { NX.award(XP.water, 'Fuelled up 🍽', 'meal'); say('Fuel in the tank. Let’s go.'); }
  };
  const EXTRA = [['v11hi5', '✋ High five'], ['v11cheer', '🎉 Celebrate'], ['v11joke', '💬 Joke'], ['v11chat', '✦ Talk (AI)'], ['v11mood', '🎧 Mood']];
  const wireDroid = () => {
    const d = droidEl(); if (!d || d._v11) return; d._v11 = 1;
    const menu = d.querySelector('#drMenu');
    d.addEventListener('click', e => { const b = e.target.closest('[data-dr^="v11"]'); if (!b) return; e.stopPropagation(); e.preventDefault(); d.querySelector('.dr-bubble')?.classList.remove('show'); NX.companionAct(b.dataset.dr.slice(3)); }, true);
    new MutationObserver(() => { if (menu.children.length && !menu.querySelector('[data-dr^="v11"]') && menu.querySelector('[data-dr="brief"]')) menu.insertAdjacentHTML('afterbegin', EXTRA.map(([k, l]) => `<button type="button" data-dr="${k}" class="v11-dr">${l}</button>`).join('')); }).observe(menu, { childList: true });
  };

  /* ============ 4. WELLNESS CARE ============ */
  const CK = 'manas.care';
  const care = Object.assign({ day: '', done: {}, lastWater: 0, lastPosture: 0 }, (() => { try { return JSON.parse(localStorage.getItem(CK) || '{}'); } catch (e) { return {}; } })());
  const saveC = () => { try { localStorage.setItem(CK, JSON.stringify(care)); } catch (e) {} };
  const bootAt = Date.now();
  const careTick = () => {
    if (NX.mx.care === false || document.hidden || Date.now() - bootAt < 25000) return;
    if (document.querySelector('.sheet.open, .v11-levelup')) return;
    const d = new Date(), m = d.getHours() * 60 + d.getMinutes(), now = Date.now();
    if (care.day !== today()) { care.day = today(); care.done = {}; }
    const once = (k, from, to, msg, acts) => { if (m >= from && m <= to && !care.done[k]) { care.done[k] = 1; saveC(); say(msg, acts); return true; } };
    const n = NX.prefs.name || 'friend';
    if (once('breakfast', 480, 630, `Good morning, ${n}. Have you had breakfast? Fuel up for the day. 🍳`, [['v11ate', '✓ Eaten'], ['v11later', 'Soon']])) return;
    if (once('lunch', 750, 870, 'Lunch break time — step away and recharge. 🥗', [['v11ate', '✓ Done'], ['v11later', 'Later']])) return;
    if (once('dinner', 1170, 1290, 'Time for dinner and wrapping up your wins. 🍲', [['v11ate', '✓ Done'], ['v11later', 'Later']])) return;
    if (m >= 540 && m <= 1350 && now - (care.lastWater || 0) > 90 * 60000) { care.lastWater = now; saveC(); return say('Hydrated yet? Take a sip of water! 💧', [['v11water', '💧 Done (+5 XP)'], ['v11later', 'Later']]); }
    if (m >= 600 && m <= 1320 && now - (care.lastPosture || bootAt) > 150 * 60000) { care.lastPosture = now; saveC(); return say('Posture check: shoulders back, screen at eye level. Stretch for 30 seconds? 🧘', [['v11stretch', '✓ Stretched'], ['v11later', 'Later']]); }
  };
  if (!care.lastWater) { care.lastWater = Date.now() - 80 * 60000; saveC(); }
  setInterval(careTick, 30000);

  /* ============ 5. MOOD ENGINE ============ */
  const MOOD_K = { calm: .7, focus: .45, energize: 1.7, uplift: 1.15, sleep: .3 };
  const moodLayer = document.createElement('div'); moodLayer.id = 'v11mood'; moodLayer.setAttribute('aria-hidden', 'true'); document.body.prepend(moodLayer);
  const MOOD_LINES = { calm: 'Calm mode. Soft light, slow breath, gentle music. 🌿', focus: 'Focus mode. Fewer distractions, steady pulse. Let’s get one thing done. 🎯', energize: 'Energize mode! Brighter room, faster beat. Let’s move. ⚡', uplift: 'Uplift mode. Warm and bright — you’ve got this. ☀', sleep: 'Sleep mode. Dim, slow and quiet. Wind down, you did enough today. 🌙' };
  NX.onMood = m => {
    NX.auraMoodK = MOOD_K[m] || 1; document.body.dataset.mood = m; NX.kickAura && NX.kickAura();
    if (!G.moods.includes(m)) { G.moods.push(m); saveG(); }
  };
  NX.auraMoodK = MOOD_K[(NX.music && NX.music.mood) || 'calm'] || 1;
  NX.setMood = (m, talk = true) => { if (NX.music && NX.music.setMood) NX.music.setMood(m); else NX.onMood(m); if (NX.music && !NX.music.on) NX.music.start(); if (talk) say(MOOD_LINES[m]); paintHomeCard(); };
  NX.openMood = () => {
    const M = (NX.music && NX.music.moods) || {}; const cur = NX.music && NX.music.mood;
    NX.openSheet(`<div class="sheet-h"><h2>How are you feeling?</h2><button class="btn small" data-close>Close</button></div><p class="dim tiny">Your mood sets the soundtrack, the room lighting and the pace of the particles.</p>
      <div class="v11-moods big">${Object.entries(M).map(([k, v]) => `<button class="v11-mood ${cur === k ? 'on' : ''}" data-setmood="${k}"><span>${v.icon}</span><b>${v.label}</b></button>`).join('')}</div>`);
    const sb = $('#sheetBody'); sb.querySelector('[data-close]').onclick = () => NX.closeSheet();
    sb.querySelectorAll('[data-setmood]').forEach(b => b.onclick = () => { NX.setMood(b.dataset.setmood); NX.closeSheet(); });
  };

  /* --- Home card: level, quests, mood check-in --- */
  const paintHomeCard = () => {
    if (NX.current !== 'home') return; const v = document.getElementById('view'); if (!v) return;
    let c = v.querySelector('#v11home'); if (!c) { c = document.createElement('section'); c.id = 'v11home'; c.className = 'shard v11-home'; const hero = v.querySelector('.hero'); hero ? hero.after(c) : v.prepend(c); }
    rollDay(); const lv = levelOf(G.xp), M = (NX.music && NX.music.moods) || {}, cur = NX.music && NX.music.mood;
    const qd = QUESTS.filter(([k, n]) => (G.dayCounts[k] || 0) >= n).length;
    c.innerHTML = `<div class="v11-home-top"><button class="v11-lv-ring sm" style="--p:${lv.into / lv.span * 360}deg" data-v11="quests" aria-label="Open your journey"><b>${lv.level}</b></button>
      <div class="grow"><div class="mono dim">LEVEL ${lv.level} · ${esc(lv.title.toUpperCase())}</div>${NX.bar(lv.into / lv.span * 100)}<div class="tiny dim">${lv.span - lv.into} XP to next · 🔥 ${G.streak} day streak · 📜 ${qd}/${QUESTS.length} quests</div></div>
      <button class="btn small" data-v11="chat">✦ Talk to ${esc(cmpName())}</button></div>
      <div class="v11-moods">${Object.entries(M).map(([k, v]) => `<button class="v11-mood ${cur === k ? 'on' : ''}" data-setmood="${k}" aria-label="${v.label} mood"><span>${v.icon}</span><b>${v.label}</b></button>`).join('')}</div>`;
    c.querySelectorAll('[data-setmood]').forEach(b => b.onclick = e => { e.stopPropagation(); NX.setMood(b.dataset.setmood); });
    c.querySelector('[data-v11="quests"]').onclick = e => { e.stopPropagation(); openQuests(); };
    c.querySelector('[data-v11="chat"]').onclick = e => { e.stopPropagation(); NX.openChat(); };
    if (NX.mx.world === 'architect' && !v.querySelector('#v11zeroInline')) { const z = document.createElement('section'); z.id = 'v11zeroInline'; z.className = 'shard v11-zero-inline'; z.innerHTML = `<div class="section-h"><h2>Studio Zero</h2><span class="mono dim">LIVE</span></div>${zeroHTML()}`; c.after(z); wireZero(z); }
  };

  /* ============ 6. STUDIO ZERO ============ */
  const Z = () => (NX.mx.zero = Object.assign({ radius: null, contrast: null, density: 'cozy', glass: null }, NX.mx.zero || {}));
  const A = () => (NX.mx.aura = Object.assign({ speed: 1, density: 1, links: true }, NX.mx.aura || {}));
  const applyZero = () => {
    const z = Z(), b = document.body, r = document.documentElement;
    if (z.radius != null) { b.dataset.v11r = '1'; r.style.setProperty('--v11-radius', z.radius + 'px'); } else delete b.dataset.v11r;
    if (z.contrast != null) { const v = `color-mix(in srgb, ${getComputedStyle(b).getPropertyValue('--text').trim() || '#fff'} ${z.contrast}%, transparent)`; b.style.setProperty('--line', v); r.style.setProperty('--line', v); }
    b.dataset.density = z.density || 'cozy';
  };
  NX.applyZero = applyZero;
  const NAVS = [['island', 'Floating Island'], ['radial', 'Radial Arc'], ['concierge', 'Concierge Split'], ['command', 'Terminal Bar'], ['ticker', 'Minimal Ticker'], ['masthead', 'Masthead'], ['dock', 'Magnetic Dock'], ['side', 'Side Rail'], ['pills', 'Floating Pills'], ['tabs', 'Underline Tabs'], ['launcher', 'Grid Launcher'], ['hud', 'HUD Brackets']];
  const PAL = ['#9aa7ff', '#7ee0ff', '#5cffc8', '#a8c686', '#ffd68c', '#f2a38a', '#ff6a1a', '#ff3b5c', '#ff2bd6', '#e0a94a', '#cfd6e4', '#ffffff'];
  const zeroHTML = () => {
    const z = Z(), a = A(), w = NX.world(), acc = (NX.mx.accents || {})[w.id] || w.v.a1, nav = NX.mx.wnav || '';
    const lineNow = z.contrast ?? 12;
    return `<div class="v11-zero">
      <div class="field"><span class="mono dim">Navigation style · live</span><div class="chips">${[['', 'World default'], ...NAVS].map(([k, l]) => `<button class="chip ${nav === k ? 'on' : ''}" data-znav="${k}">${l}</button>`).join('')}</div>
        <label class="v11-check"><input type="checkbox" data-zmdock ${NX.mx.mobileDock !== false ? 'checked' : ''}> <span class="dim">On phones keep the thumb dock (untick to use the style above on phones too)</span></label></div>
      <div class="field"><span class="mono dim">Accent colour</span><div class="v11-pal">${PAL.map(c => `<button class="sw ${acc.toLowerCase() === c ? 'on' : ''}" style="--c:${c}" data-zacc="${c}" aria-label="Accent ${c}"></button>`).join('')}<input type="color" data-zacc-pick value="${/^#[0-9a-f]{6}$/i.test(acc) ? acc : '#9aa7ff'}" aria-label="Custom accent"></div></div>
      <label class="field"><span class="mono dim">Aura speed · <b data-zv="speed">${(+a.speed).toFixed(1)}×</b></span><input type="range" min="0" max="3" step=".1" value="${a.speed}" data-zaura="speed"></label>
      <label class="field"><span class="mono dim">Aura density · <b data-zv="density">${Math.round(a.density * 100)}%</b></span><input type="range" min="0" max="2" step=".1" value="${a.density}" data-zaura="density"></label>
      <label class="field"><span class="mono dim">Card corner radius · <b data-zv="radius">${z.radius ?? 'world'}${z.radius != null ? 'px' : ''}</b></span><input type="range" min="0" max="32" step="1" value="${z.radius ?? 16}" data-zset="radius"></label>
      <label class="field"><span class="mono dim">Border contrast · <b data-zv="contrast">${lineNow}%</b></span><input type="range" min="0" max="60" step="1" value="${lineNow}" data-zset="contrast"></label>
      <div class="field"><span class="mono dim">Layout density</span><div class="chips">${[['compact', 'Compact'], ['cozy', 'Cozy'], ['spacious', 'Spacious']].map(([k, l]) => `<button class="chip ${z.density === k ? 'on' : ''}" data-zden="${k}">${l}</button>`).join('')}</div></div>
      <div class="field"><span class="mono dim">Font</span><select data-zfont><option value="">World default</option>${NX.fonts.map(f => `<option value="${f[0]}" ${((NX.mx.fonts || {})[w.id] || '') === f[0] ? 'selected' : ''}>${esc(f[1])}</option>`).join('')}</select></div>
      <div class="rows"><label class="row"><div class="grow"><div class="t">Particle links</div></div><input type="checkbox" data-zlinks ${a.links ? 'checked' : ''}></label>
      <label class="row"><div class="grow"><div class="t">Companion wellness check-ins</div><div class="s">Water, meals, posture and stretch reminders</div></div><input type="checkbox" data-zcare ${NX.mx.care !== false ? 'checked' : ''}></label></div>
      <div class="actions"><button class="btn small" data-zreset>Reset Studio Zero</button>${NX.mx.world !== 'architect' ? '<button class="btn small solid" data-zgo>Enter The Architect world</button>' : ''}</div></div>`;
  };
  const wireZero = root => {
    const re = () => { const inl = document.getElementById('v11zeroInline'); [root, inl].forEach(r => { if (r && r.isConnected) { const scroll = r.scrollTop; const host = r.querySelector('.v11-zero'); if (host) { host.outerHTML = zeroHTML(); wireZero(r); r.scrollTop = scroll; } } }); };
    const save = () => { NX.saveMx(); };
    root.querySelectorAll('[data-znav]').forEach(b => b.onclick = () => { NX.mx.wnav = b.dataset.znav; save(); NX.renderNav(); re(); NX.toast('Navigation · ' + (b.textContent)); });
    const md = root.querySelector('[data-zmdock]'); if (md) md.onchange = e => { NX.mx.mobileDock = e.target.checked; save(); NX.renderNav(); };
    const setAcc = c => { NX.mx.accents = Object.assign({}, NX.mx.accents, { [NX.world().id]: c }); save(); NX.applyWorld(); re(); };
    root.querySelectorAll('[data-zacc]').forEach(b => b.onclick = () => setAcc(b.dataset.zacc));
    const ap = root.querySelector('[data-zacc-pick]'); if (ap) { ap.oninput = e => { const c = e.target.value, s = document.body.style, r = document.documentElement.style; ['--a1'].forEach(k => { s.setProperty(k, c); r.setProperty(k, c); }); s.setProperty('--glow', c + '66'); NX.refreshAuraColor(); }; ap.onchange = e => setAcc(e.target.value); }
    root.querySelectorAll('[data-zaura]').forEach(i => i.oninput = e => { const k = i.dataset.zaura; A()[k] = +e.target.value; save(); if (k === 'density') NX.reseedAura && NX.reseedAura(); NX.kickAura && NX.kickAura(); const lab = root.querySelector(`[data-zv="${k}"]`); if (lab) lab.textContent = k === 'speed' ? (+e.target.value).toFixed(1) + '×' : Math.round(e.target.value * 100) + '%'; });
    root.querySelectorAll('[data-zset]').forEach(i => i.oninput = e => { const k = i.dataset.zset; Z()[k] = +e.target.value; save(); applyZero(); const lab = root.querySelector(`[data-zv="${k}"]`); if (lab) lab.textContent = e.target.value + (k === 'radius' ? 'px' : '%'); });
    root.querySelectorAll('[data-zden]').forEach(b => b.onclick = () => { Z().density = b.dataset.zden; save(); applyZero(); re(); });
    const zf = root.querySelector('[data-zfont]'); if (zf) zf.onchange = e => { NX.mx.fonts = Object.assign({}, NX.mx.fonts, { [NX.world().id]: e.target.value }); if (!e.target.value) delete NX.mx.fonts[NX.world().id]; save(); NX.applyWorld(); };
    const zl = root.querySelector('[data-zlinks]'); if (zl) zl.onchange = e => { A().links = e.target.checked; save(); };
    const zc = root.querySelector('[data-zcare]'); if (zc) zc.onchange = e => { NX.mx.care = e.target.checked; save(); };
    const zr = root.querySelector('[data-zreset]'); if (zr) zr.onclick = () => { NX.mx.zero = null; NX.mx.aura = null; NX.mx.wnav = ''; if (NX.mx.accents) delete NX.mx.accents[NX.world().id]; save(); NX.applyWorld(); NX.reseedAura && NX.reseedAura(); re(); NX.toast('Studio Zero reset'); };
    const zg = root.querySelector('[data-zgo]'); if (zg) zg.onclick = () => { NX.closeSheet(); NX.mx.world = 'architect'; save(); NX.worldSwitch ? NX.worldSwitch() : NX.applyWorld(); };
  };
  NX.openZero = () => {
    NX.openSheet(`<div class="sheet-h"><h2>Studio Zero</h2><button class="btn small" data-close>Close</button></div><p class="dim tiny">Every change applies instantly and is saved on this device. ${esc(NX.world().name)}.</p>${zeroHTML()}`);
    const sb = $('#sheetBody'); sb.querySelector('[data-close]').onclick = () => NX.closeSheet(); wireZero(sb);
  };

  /* ============ AI COMPANION CHAT ============ */
  const HK = 'manas.chat';
  let hist = (() => { try { return JSON.parse(localStorage.getItem(HK) || '[]'); } catch (e) { return []; } })();
  const saveH = () => { hist = hist.slice(-30); try { localStorage.setItem(HK, JSON.stringify(hist)); } catch (e) {} };
  const ctxSummary = () => {
    const t = today(), open = NX.list('task').filter(x => !['Completed', 'Cancelled'].includes(x.status)), over = open.filter(x => x.dueDate && x.dueDate < t);
    const goals = NX.list('goal'), lv = levelOf(G.xp);
    return `Time ${new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}. ${open.length} open tasks (${over.length} overdue): ${open.slice(0, 6).map(x => x.title).join('; ') || 'none'}. Goals: ${goals.slice(0, 4).map(g => `${g.title} ${g.progress || 0}%`).join('; ') || 'none'}. Level ${lv.level} ${lv.title}, ${G.streak}-day streak, water today ${G.dayCounts.water || 0} glasses.`.slice(0, 1400);
  };
  const localReply = m => {
    const q = m.toLowerCase();
    if (/plan|day|today/.test(q)) return (NX.brain && NX.brain.briefing && NX.brain.briefing()) || 'Pick your top three tasks, do the hardest first, and take a break every 50 minutes.';
    if (/stress|anx|tired|sad|overwhelm/.test(q)) return 'Breathe in for 4, hold for 4, out for 6. Then pick one tiny thing — just one. I’m here. 🌿';
    if (/joke|funny/.test(q)) return jokeFor();
    const add = m.match(/(?:add|create|new)\s+(?:a\s+)?(task|habit|journal)(?:\s+(?:entry\s+)?(?:to|for|:)?)?\s+(.+)/i);
    if (add) return `Got it — tap below to save “${add[2].trim()}” as a ${add[1].toLowerCase()}. ✅\nACTION: ${add[1].toLowerCase()} | ${add[2].trim()}`;
    const open = NX.list('task').filter(x => !['Completed', 'Cancelled'].includes(x.status)).sort((a, b) => String(a.dueDate || '9').localeCompare(String(b.dueDate || '9')));
    if (/next|what should|focus|priority/.test(q)) return open.length ? `Do “${open[0].title}” next${open[0].dueDate ? ' (due ' + open[0].dueDate + ')' : ''}. ${open.length - 1} more after that. One at a time. 🎯` : 'Your task list is clear! Add a goal or enjoy a break. 🌤️';
    if (/motivat|lazy|can.?t|procrast/.test(q)) return ['Start with 2 minutes. Momentum does the rest. 🚀', 'Small steps every day beat big plans someday. 💪', 'You’ve done hard things before. This is just one more. 🔥'][Math.floor(Math.random() * 3)];
    if (/goal/.test(q)) { const g = NX.list('goal'); return g.length ? 'Your goals: ' + g.slice(0, 4).map(x => x.title).join(', ') + '. Pick one and do one step today.' : 'No goals yet — tell me “add a task …” or create a goal from the Goals page.'; }
    if (/^(hi|hey|hello|yo|sup)\b/.test(q)) return `Hey! You have ${open.length} open task${open.length === 1 ? '' : 's'}. Want me to plan your day?`;
    if (/thank/.test(q)) return 'Always. 💛';
    return `I hear you. You have ${open.length} open task${open.length === 1 ? '' : 's'}. Ask me to “plan my day”, “what should I do next?”, or “add a task …”.`;
  };
  let busy = false, lastSend = 0;
  NX.openChat = () => {
    const c = NX.activeCompanion ? NX.activeCompanion() : { name: 'ONE-811', role: 'Companion' };
    const av = NX.avatarSVG ? NX.avatarSVG(c) : '✦';
    NX.openSheet(`<div class="v11-chat"><div class="sheet-h"><div class="v11-chat-h"><div class="cp-av sm" style="${NX.cpVars ? NX.cpVars(c) : ''}">${av}</div><div><h2>${esc(c.name)}</h2><div class="mono dim">${esc(c.role || '')} · AI companion</div></div></div><button class="btn small" data-close>Close</button></div>
      <div class="v11-msgs" id="v11msgs" aria-live="polite"></div>
      <div class="v11-sugg">${['Plan my day', 'I feel stressed', 'Motivate me', 'Tell me a joke', 'What should I do next?', 'Add a task to call mom'].map(s => `<button class="chip" data-sugg="${esc(s)}">${esc(s)}</button>`).join('')}</div>
      <form class="v11-in" id="v11form"><input id="v11text" maxlength="600" placeholder="Talk to ${esc(c.name)}…" autocomplete="off"><button class="btn solid" type="submit">Send</button></form>
      <div class="actions"><button class="btn small" data-clear>Clear chat</button><span class="tiny dim">Replies are AI-generated. Your data stays on this device; only a short summary is sent.</span></div></div>`);
    const sb = $('#sheetBody'), box = sb.querySelector('#v11msgs'), input = sb.querySelector('#v11text');
    const paint = () => { box.innerHTML = (hist.length ? hist : [{ role: 'assistant', text: NX.cpGreet ? NX.cpGreet(c) : 'Hi! How can I help?' }]).map(h => `<div class="v11-msg ${h.role}">${esc(h.text)}${h.action ? `<button class="btn small solid" data-act='${esc(JSON.stringify(h.action))}'>＋ Add ${esc(h.action.kind)}: ${esc(h.action.title)}</button>` : ''}</div>`).join('') + (busy ? '<div class="v11-msg assistant typing"><i></i><i></i><i></i></div>' : ''); box.scrollTop = box.scrollHeight; };
    paint();
    const send = async text => {
      text = (text || '').trim(); if (!text || busy) return; if (Date.now() - lastSend < 1500) return NX.toast('One moment…'); lastSend = Date.now();
      hist.push({ role: 'user', text }); saveH(); busy = true; paint(); input.value = '';
      let reply = '', action = null;
      try {
        const r = await fetch('/api/public/companion', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ character: `${c.name} (${c.role || 'companion'})${c.persona ? ' — ' + c.persona : ''}`.slice(0, 80), world: NX.world().name, mood: (NX.music && NX.music.mood) || 'calm', name: NX.prefs.name || 'friend', context: ctxSummary(), history: hist.slice(-11, -1).map(h => ({ role: h.role, text: h.text.slice(0, 1100) })), message: text.slice(0, 780) }) });
        const j = await r.json().catch(() => ({}));
        if (r.ok && j.text) reply = j.text; else reply = j.error === 'busy' ? 'I’m getting a lot of messages — give me a few seconds and try again.' : j.error === 'credits' ? 'My AI brain needs a top-up. Here’s my offline advice: ' + localReply(text) : localReply(text);
      } catch (e) { reply = localReply(text); }
      const m = reply.match(/ACTION:\s*(task|habit|journal)\s*\|\s*(.+)$/im); if (m) { action = { kind: m[1].toLowerCase(), title: m[2].trim().slice(0, 120) }; reply = reply.replace(m[0], '').trim(); }
      hist.push({ role: 'assistant', text: reply, action }); saveH(); busy = false; paint();
      if (!G.dayCounts.chat) NX.award(XP.chat, 'Chat with ' + c.name, 'chat'); else { G.counts.chat = (G.counts.chat || 0) + 1; saveG(); }
      NX.sfx && NX.sfx(c, true);
    };
    sb.querySelector('#v11form').onsubmit = e => { e.preventDefault(); send(input.value); };
    sb.querySelectorAll('[data-sugg]').forEach(b => b.onclick = () => send(b.dataset.sugg));
    sb.querySelector('[data-close]').onclick = () => NX.closeSheet();
    sb.querySelector('[data-clear]').onclick = () => { hist = []; saveH(); paint(); };
    box.addEventListener('click', e => { const b = e.target.closest('[data-act]'); if (!b) return; const a = JSON.parse(b.dataset.act);
      const type = a.kind === 'journal' ? 'note' : a.kind === 'habit' ? 'workout' : 'task';
      NX.upsert({ id: NX.uid(), type, title: a.title, status: type === 'task' ? 'Not started' : undefined, date: today(), created: new Date().toISOString() });
      b.disabled = true; b.textContent = '✓ Added'; NX.toast('Added to ' + (NX.mod(type === 'note' ? 'notes' : type === 'workout' ? 'fitness' : 'tasks')?.name || type)); });
    setTimeout(() => input.focus(), 60);
  };

  /* ============ 7. ATMOSPHERICS ============ */
  // Golden Snitch — glides on smooth Bezier curves (wizard world); tap to catch.
  const sn = document.createElement('button'); sn.id = 'v11snitch'; sn.setAttribute('aria-label', 'Catch the Golden Snitch'); sn.innerHTML = '<i class="wl"></i><b></b><i class="wr"></i>'; document.body.append(sn);
  let snRAF = 0, seg = null, snT = 0, trailT = 0;
  const rp = () => ({ x: 40 + Math.random() * (innerWidth - 80), y: 80 + Math.random() * (innerHeight - 220) });
  const newSeg = from => { const p0 = from || rp(); return { p0, p1: rp(), p2: rp(), p3: rp(), dur: 3800 + Math.random() * 3000, t0: performance.now() }; };
  const bez = (a, b, c, d, t) => { const u = 1 - t; return u * u * u * a + 3 * u * u * t * b + 3 * u * t * t * c + t * t * t * d; };
  const snLoop = now => {
    snRAF = requestAnimationFrame(snLoop); if (document.hidden) return;
    if (!seg) seg = newSeg(); let t = (now - seg.t0) / seg.dur; if (t >= 1) { seg = newSeg(seg.p3); t = 0; }
    const e = t < .5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
    const x = bez(seg.p0.x, seg.p1.x, seg.p2.x, seg.p3.x, e), y = bez(seg.p0.y, seg.p1.y, seg.p2.y, seg.p3.y, e) + Math.sin(now / 180) * 4;
    sn.style.transform = `translate3d(${x - 14}px,${y - 10}px,0)`;
    if (now - trailT > 70) { trailT = now; const g = document.createElement('i'); g.className = 'v11-glitter'; g.style.transform = `translate3d(${x + (Math.random() * 10 - 5)}px,${y + (Math.random() * 10 - 5)}px,0)`; fx.append(g); setTimeout(() => g.remove(), 900); }
  };
  const snitchOn = on => { sn.classList.toggle('on', on); if (on && !snRAF && !reduced()) { seg = null; snRAF = requestAnimationFrame(snLoop); } if (!on && snRAF) { cancelAnimationFrame(snRAF); snRAF = 0; } };
  sn.onclick = e => { const r = sn.getBoundingClientRect(); const p = { x: r.left + 14, y: r.top + 10 }; NX.award(XP.snitch, 'Caught the Golden Snitch!', 'snitch', p); burst(p, 30); snitchOn(false); say('You caught the Snitch! 150 points… well, 15 XP. ✨'); setTimeout(() => NX.mx.world === 'wizard' && snitchOn(true), 45000); };
  // Wand sparks on tap in the wizard world
  addEventListener('pointerdown', e => { if (NX.mx.world === 'wizard' && !reduced() && !e.target.closest('input,textarea,select')) burst({ x: e.clientX, y: e.clientY }, 6); }, { passive: true });
  // Collectible focus spark — appears now and then in every world
  const spark = document.createElement('button'); spark.id = 'v11orb'; spark.setAttribute('aria-label', 'Collect a focus spark'); document.body.append(spark);
  const spawnSpark = () => {
    if (document.hidden || reduced() || spark.classList.contains('on')) return;
    const p = rp(); spark.style.left = p.x + 'px'; spark.style.top = p.y + 'px'; spark.classList.add('on');
    clearTimeout(spark._t); spark._t = setTimeout(() => spark.classList.remove('on'), 14000);
  };
  spark.onclick = () => { const r = spark.getBoundingClientRect(); spark.classList.remove('on'); NX.award(XP.spark, 'Collected a focus spark', 'spark', { x: r.left + 15, y: r.top + 15 }); };
  setTimeout(spawnSpark, 40000); setInterval(spawnSpark, 4 * 60000);

  /* ============ WIRING ============ */
  const aw0 = NX.applyWorld;
  NX.applyWorld = () => {
    aw0(); applyZero(); mountStrip();
    const w = NX.mx.world; if (w && !G.worlds.includes(w)) { G.worlds.push(w); saveG(); }
    snitchOn(w === 'wizard');
  };
  const rn0 = NX.renderNav; NX.renderNav = () => { rn0(); mountStrip(); };
  const go0 = NX.go;
  NX.go = (id, push) => { const r = go0(id, push); if (NX.current === 'home') requestAnimationFrame(paintHomeCard); return r; };
  NX.extraCmds = () => [
    { t: '✦  Talk to your companion (AI)', k: 'action', run: () => NX.openChat() },
    { t: '⚙  Studio Zero — customise everything', k: 'action', run: () => NX.openZero() },
    { t: '🏆  Level, quests & achievements', k: 'action', run: () => openQuests() },
    { t: '🎧  Set my mood', k: 'action', run: () => NX.openMood() },
    { t: '✋  High five', k: 'action', run: () => NX.companionAct('hi5') },
    ...Object.entries((NX.music && NX.music.moods) || {}).map(([k, v]) => ({ t: `${v.icon}  Mood · ${v.label}`, k: 'mood', run: () => NX.setMood(k) })),
  ];
  NX.sfxSoft = kind => { try { if (!NX.music || !NX.music.voice) return; if (kind === 'coin') { NX.music.voice('celesta', 84, .5, .05); setTimeout(() => NX.music.voice('celesta', 91, .5, .04), 90); } } catch (e) {} };

  const boot = () => {
    try { applyZero(); mountStrip(); wireDroid(); snitchOn(NX.mx.world === 'wizard'); NX.onMood((NX.music && NX.music.mood) || 'calm'); if (NX.current === 'home') paintHomeCard(); } catch (e) { console.warn('v11 boot', e); }
  };
  if (document.readyState === 'complete') boot(); else addEventListener('load', boot);
  setTimeout(boot, 1500);
})();
