/* =========================================================
   LEGENDS (v10) — loaded before app.js.
   1. Procedural ambient music per world (Web Audio only, no files).
   2. Floating Music HUD (play/pause, volume, style).
   3. Back system: in-app back button, edge-swipe back, Android/browser
      back closes open sheets first, Esc closes sheets.
   4. Command palette (Ctrl/Cmd + K, or double-tap the title).
   5. "QA" page: per-page testing checklist + one-tap auto checks.
   ========================================================= */
(function () {
  const $ = s => document.querySelector(s);
  const LS = 'manas.legends';
  const st = Object.assign({ vol: 0.35, style: 'auto', on: false, checks: {} }, (() => { try { return JSON.parse(localStorage.getItem(LS) || '{}'); } catch (e) { return {}; } })());
  const save = () => { try { localStorage.setItem(LS, JSON.stringify(st)); } catch (e) {} };

  /* ---------------- 1. MUSIC ENGINE (v11 — warm, calm, mood-driven) ----------------
     Soft physical-model-ish voices (sine/filtered-triangle, exponential decay, warm low-pass,
     generated reverb). Each signature world has its own iconic-inspired motif; every other
     world gets a gentle generative motif. Mood changes tempo, brightness, density and room. */
  const MOODS = {
    calm:     { label: 'Calm',     icon: '🌿', bpm: 64, cut: 2200, dens: .85, pad: .055, rev: .45, oct: 0,  pulse: 0 },
    focus:    { label: 'Focus',    icon: '🎯', bpm: 72, cut: 1500, dens: .5,  pad: .045, rev: .35, oct: 0,  pulse: .5 },
    energize: { label: 'Energize', icon: '⚡', bpm: 94, cut: 3200, dens: 1,   pad: .04,  rev: .25, oct: 0,  pulse: 1 },
    uplift:   { label: 'Uplift',   icon: '☀', bpm: 82, cut: 2800, dens: .9,  pad: .05,  rev: .4,  oct: 12, pulse: 0 },
    sleep:    { label: 'Sleep',    icon: '🌙', bpm: 50, cut: 850,  dens: .35, pad: .07,  rev: .6,  oct: -12, pulse: 0 },
  };
  // motif: [instrument, [[midi|null, beats], ...], chords (midi triads), chord beats, label]
  const R = null;
  const MOTIFS = {
    hedwig: ['celesta', [[59,1],[64,1.5],[67,.5],[66,1],[64,2],[71,1],[69,3],[66,3],[64,1.5],[67,.5],[66,1],[63,2],[65,1],[59,4],[R,2]], [[40,47,52],[45,52,57],[47,51,54],[40,47,52]], 6, 'Music-box owl theme'],
    westeros: ['strings', [[67,1.5],[60,1.5],[63,.5],[65,.5],[67,1],[60,1],[63,.5],[65,.5],[62,4],[R,2],[65,1.5],[58,1.5],[63,.5],[62,.5],[65,1],[58,1],[63,.5],[62,.5],[60,4],[R,2]], [[36,43,48],[32,39,44],[39,46,51],[34,41,46]], 6, 'Iron-throne strings'],
    shire: ['flute', [[62,.5],[64,.5],[66,1],[69,1],[66,1],[64,.5],[62,1.5],[R,1],[66,.5],[69,.5],[71,1],[74,1],[73,1],[69,1],[66,1],[67,.5],[66,.5],[64,2],[R,2]], [[50,54,57],[43,47,50],[45,49,52],[47,50,54]], 4, 'Pastoral flute & harp'],
    desert: ['marimba', [[62,.5],[65,.5],[69,.5],[72,.5],[70,1],[69,.5],[65,.5],[67,1],[R,1],[62,.5],[65,.5],[67,.5],[69,.5],[65,1],[62,1],[R,2]], [[38,45,50],[41,48,53],[43,50,55],[36,43,48]], 4, 'Desert marimba'],
    baker: ['piano', [[62,.5],[65,.5],[69,.5],[74,.5],[72,.5],[69,.5],[65,.5],[69,.5],[58,.5],[62,.5],[65,.5],[70,.5],[69,.5],[65,.5],[62,.5],[65,.5],[55,.5],[58,.5],[62,.5],[67,.5],[65,.5],[62,.5],[57,.5],[61,.5],[64,2],[R,2]], [[38,45,50],[34,41,46],[31,38,43],[33,40,45]], 4, 'Piano & violin deduction'],
    bella: ['musicbox', [[64,.5],[69,.5],[71,.5],[72,.5],[69,2],[R,.5],[64,.5],[69,.5],[71,.5],[72,.5],[69,2],[R,.5],[64,.5],[69,.5],[71,.5],[72,1],[71,.5],[69,.5],[72,1],[71,.5],[69,.5],[76,1],[76,.5],[76,.5],[74,.5],[76,.5],[77,1],[77,2],[R,2]], [[45,52,57],[45,52,57],[40,47,52],[45,52,57]], 4, 'Music-box resistance song'],
    gen_pent: ['bell', 'gen', [[48,55,60],[45,52,57],[41,48,53],[43,50,55]], 4, 'Mystic chimes'],
    gen_minor: ['strings', 'gen-m', [[45,52,57],[41,48,53],[48,55,60],[43,50,55]], 6, 'Dark ambient'],
    gen_lofi: ['piano', 'gen', [[50,53,57,60],[43,47,50,53],[48,52,55,59],[45,48,52,55]], 4, 'Lo-fi keys'],
    gen_koto: ['harp', 'gen', [[50,57,62],[48,55,60],[45,52,57],[43,50,55]], 4, 'Koto dusk'],
    gen_ocean: ['bell', 'gen', [[36,43,48],[34,41,46],[31,38,43],[33,40,45]], 8, 'Abyss sonar'],
  };
  const MAP = { wizard: 'hedwig', westeros: 'westeros', middleearth: 'shire', heisenberg: 'desert', bakerst: 'baker', heist: 'bella', upside: 'gen_minor', gotham: 'gen_minor', ember: 'gen_minor', samurai: 'gen_koto', abyss: 'gen_ocean', lofi: 'gen_lofi', cyber: 'gen_lofi', terminal: 'gen_lofi', arcade: 'gen_lofi', dune: 'desert', zen: 'gen_koto', aurora: 'gen_pent', observatory: 'gen_pent' };
  const STY = Object.fromEntries(Object.entries(MOTIFS).map(([k, v]) => [k, [0, 0, 0, 0, 0, 0, v[4]]]));
  if (!MOODS[st.mood]) st.mood = 'calm';
  if (st.style !== 'auto' && !MOTIFS[st.style]) st.style = 'auto';
  const styleFor = () => st.style !== 'auto' ? st.style : (MAP[NX.mx?.world] || 'gen_pent');
  const mtof = m => 440 * Math.pow(2, (m - 69) / 12);
  let ctx, master, bus, wet, lp, timer, nodes = [], beatT = 0, mi = 0, ci = 0, chordAt = 0;
  const impulse = (sec) => { const len = ctx.sampleRate * sec, b = ctx.createBuffer(2, len, ctx.sampleRate); for (let c = 0; c < 2; c++) { const d = b.getChannelData(c); for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 2.6); } return b; };
  const ac = () => {
    if (!ctx) {
      ctx = new (window.AudioContext || window.webkitAudioContext)();
      master = ctx.createGain(); master.gain.value = st.vol; master.connect(ctx.destination);
      lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 2200; lp.Q.value = .3;
      bus = ctx.createGain(); bus.connect(lp); lp.connect(master);
      const conv = ctx.createConvolver(); conv.buffer = impulse(3.2); wet = ctx.createGain(); wet.gain.value = .45;
      bus.connect(conv); conv.connect(wet); wet.connect(master);
    }
    return ctx;
  };
  NX.audioCtx = () => ac();
  NX.audioBus = () => (ac(), bus);
  const env = (g, t, a, peak, d) => { g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(peak, t + a); g.gain.exponentialRampToValueAtTime(0.0001, t + a + d); };
  const osc = (type, f, t, end, dest, detune = 0) => { const o = ctx.createOscillator(); o.type = type; o.frequency.value = f; o.detune.value = detune; o.connect(dest); o.start(t); o.stop(end + .05); return o; };
  // Instrument voices — all soft, no saw/square.
  const VOICE = {
    celesta(f, t, d, v) { const g = ctx.createGain(); g.connect(bus); env(g, t, .006, v, Math.max(1.2, d * 1.6)); osc('sine', f, t, t + d * 2 + 1, g); const g2 = ctx.createGain(); g2.connect(bus); env(g2, t, .004, v * .25, .5); osc('sine', f * 4, t, t + .6, g2); },
    musicbox(f, t, d, v) { const g = ctx.createGain(); g.connect(bus); env(g, t, .004, v, 1.4); osc('sine', f, t, t + 1.6, g); const g2 = ctx.createGain(); g2.connect(bus); env(g2, t, .003, v * .18, .35); osc('sine', f * 5.4, t, t + .4, g2); },
    bell(f, t, d, v) { const g = ctx.createGain(); g.connect(bus); env(g, t, .01, v * .9, 2.4); osc('sine', f, t, t + 2.6, g); const g2 = ctx.createGain(); g2.connect(bus); env(g2, t, .01, v * .2, 1.1); osc('sine', f * 2.76, t, t + 1.3, g2); },
    marimba(f, t, d, v) { const g = ctx.createGain(); g.connect(bus); env(g, t, .004, v, .7); osc('sine', f, t, t + .8, g); const g2 = ctx.createGain(); g2.connect(bus); env(g2, t, .002, v * .3, .12); osc('sine', f * 4, t, t + .2, g2); },
    harp(f, t, d, v) { const f1 = ctx.createBiquadFilter(); f1.type = 'lowpass'; f1.frequency.setValueAtTime(f * 6, t); f1.frequency.exponentialRampToValueAtTime(f * 1.5, t + 1.2); const g = ctx.createGain(); f1.connect(g); g.connect(bus); env(g, t, .005, v, 1.6); osc('triangle', f, t, t + 1.8, f1); },
    piano(f, t, d, v) { const f1 = ctx.createBiquadFilter(); f1.type = 'lowpass'; f1.frequency.setValueAtTime(f * 5, t); f1.frequency.exponentialRampToValueAtTime(f * 1.2, t + 1.5); const g = ctx.createGain(); f1.connect(g); g.connect(bus); env(g, t, .006, v, 1.8); osc('triangle', f, t, t + 2, f1); osc('sine', f * 2, t, t + 1, f1); },
    flute(f, t, d, v) { const g = ctx.createGain(); g.connect(bus); const len = Math.max(.4, d * .95); g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(v * .8, t + .12); g.gain.setValueAtTime(v * .8, t + len * .7); g.gain.exponentialRampToValueAtTime(0.0001, t + len + .35);
      const o = osc('sine', f, t, t + len + .4, g); const lfo = ctx.createOscillator(), lg = ctx.createGain(); lfo.frequency.value = 5; lg.gain.value = f * .006; lfo.connect(lg); lg.connect(o.frequency); lfo.start(t + .15); lfo.stop(t + len + .4); },
    strings(f, t, d, v) { const f1 = ctx.createBiquadFilter(); f1.type = 'lowpass'; f1.frequency.value = Math.min(1400, f * 4); const g = ctx.createGain(); f1.connect(g); g.connect(bus); const len = Math.max(.6, d); g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(v * .7, t + .35); g.gain.setValueAtTime(v * .7, t + len); g.gain.exponentialRampToValueAtTime(0.0001, t + len + .9);
      osc('triangle', f, t, t + len + 1, f1, -5); osc('triangle', f, t, t + len + 1, f1, 6); },
  };
  const padChord = (notes, t, dur, lvl) => notes.forEach((m, i) => { const f1 = ctx.createBiquadFilter(); f1.type = 'lowpass'; f1.frequency.value = 700; const g = ctx.createGain(); f1.connect(g); g.connect(bus);
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(lvl, t + dur * .35); g.gain.exponentialRampToValueAtTime(0.0001, t + dur + 1.2); osc(i ? 'sine' : 'triangle', mtof(m), t, t + dur + 1.3, f1, (i - 1) * 4); });
  const PENT = [0, 2, 4, 7, 9, 12, 14], MIN = [0, 3, 5, 7, 10, 12, 15];
  let genLast = 2;
  const schedule = () => {
    if (!ctx || document.hidden) return;
    const M = MOODS[st.mood] || MOODS.calm, mot = MOTIFS[styleFor()] || MOTIFS.gen_pent, spb = 60 / M.bpm;
    lp.frequency.setTargetAtTime(M.cut, ctx.currentTime, 1.5); wet.gain.setTargetAtTime(M.rev, ctx.currentTime, 1.5);
    const horizon = ctx.currentTime + .4;
    while (beatT < horizon) {
      const [inst, mel, chords, cb] = mot;
      if (beatT >= chordAt) { const ch = chords[ci++ % chords.length]; padChord(ch.map(n => n + (M.oct < 0 ? 0 : 0)), chordAt, cb * spb, M.pad); chordAt += cb * spb;
        if (M.pulse) { const root = ch[0]; for (let k = 0; k < cb; k++) { const g = ctx.createGain(); g.connect(bus); env(g, chordAt - cb * spb + k * spb, .01, .05 * M.pulse, .35); osc('sine', mtof(root), chordAt - cb * spb + k * spb, chordAt - cb * spb + k * spb + .4, g); } } }
      let midi, beats;
      if (Array.isArray(mel)) { [midi, beats] = mel[mi++ % mel.length]; }
      else { const sc = mel === 'gen-m' ? MIN : PENT; genLast = Math.max(0, Math.min(sc.length - 1, genLast + [-2, -1, -1, 0, 1, 1, 2][Math.floor(Math.random() * 7)])); const base = (MOTIFS[styleFor()][2][(ci + 3) % 4][0]) + 24; midi = Math.random() < .25 ? null : base + sc[genLast]; beats = [1, 1, 2, .5, 1.5][Math.floor(Math.random() * 5)]; }
      if (midi != null && Math.random() < M.dens + (Array.isArray(mel) ? .25 : 0)) { const m = midi + M.oct + (inst === 'celesta' || inst === 'musicbox' ? 12 : 0); (VOICE[inst] || VOICE.bell)(mtof(m), beatT, beats * spb, inst === 'strings' ? .09 : .11);
        if (styleFor() === 'baker' && beats >= 2) VOICE.strings(mtof(m + 12), beatT, beats * spb, .05); if (styleFor() === 'shire' && Math.random() < .3) VOICE.harp(mtof(m - 12), beatT, 1, .05); }
      beatT += beats * spb;
    }
  };
  const stopAll = () => { clearInterval(timer); timer = 0; };
  const start = () => {
    ac(); if (ctx.state === 'suspended') ctx.resume(); stopAll();
    master.gain.cancelScheduledValues(ctx.currentTime); master.gain.setValueAtTime(0.0001, ctx.currentTime); master.gain.exponentialRampToValueAtTime(Math.max(.0002, st.vol), ctx.currentTime + 2.5);
    beatT = chordAt = ctx.currentTime + .1; mi = 0; ci = 0;
    schedule(); timer = setInterval(schedule, 120);
    st.on = true; st.wasOn = true; save(); paintHud();
  };
  const stop = () => { if (ctx) { master.gain.cancelScheduledValues(ctx.currentTime); master.gain.setTargetAtTime(0.0001, ctx.currentTime, .4); } setTimeout(stopAll, 900); st.on = false; st.wasOn = false; save(); paintHud(); };
  const restart = () => { if (st.on) { stopAll(); beatT = chordAt = ctx.currentTime + .15; mi = 0; ci = 0; schedule(); timer = setInterval(schedule, 120); } };
  const chime = () => { ac(); if (ctx.state === 'suspended') ctx.resume(); const t = ctx.currentTime + .05; [72, 76, 79, 84].forEach((m, i) => VOICE.bell(mtof(m), t + i * .14, 1, .09 - i * .012)); };
  const setMood = m => { if (!MOODS[m]) return; st.mood = m; save(); document.body.dataset.mood = m; restart(); paintHud(); NX.onMood && NX.onMood(m); };
  NX.music = { start, stop, toggle: () => (st.on ? stop() : start()), styles: STY, moods: MOODS, motifs: MOTIFS, setMood, chime, voice: (inst, midi, beats = 1, v = .1) => { ac(); VOICE[inst] && VOICE[inst](mtof(midi), ctx.currentTime + .02, beats * .5, v); }, get mood() { return st.mood; }, get on() { return st.on; }, setStyle: k => { st.style = k; save(); restart(); paintHud(); } };
  document.body.dataset.mood = st.mood;

  /* ---------------- 2. MUSIC HUD ---------------- */
  const hud = document.createElement('div'); hud.id = 'mhud'; hud.innerHTML = `<button id="mPlay" aria-label="Play ambient music">♪</button><div class="mh-x"><div class="mh-moods" role="group" aria-label="Mood">${Object.entries(MOODS).map(([k, v]) => `<button type="button" class="mh-mood" data-mood="${k}" title="${v.label}" aria-label="${v.label} mood">${v.icon}</button>`).join('')}</div><select id="mStyle" aria-label="Music track"><option value="auto">World theme</option>${Object.entries(MOTIFS).map(([k, v]) => `<option value="${k}">${v[4]}</option>`).join('')}</select><input id="mVol" type="range" min="0" max="1" step="0.05" aria-label="Volume"></div>`;
  document.body.appendChild(hud);
  function paintHud() { $('#mPlay').textContent = st.on ? '❚❚' : '♪'; hud.classList.toggle('on', st.on); $('#mStyle').value = st.style; $('#mVol').value = st.vol; hud.querySelectorAll('[data-mood]').forEach(b => b.classList.toggle('on', b.dataset.mood === st.mood)); }
  const peek = () => { hud.classList.add('open'); clearTimeout(hud._t); hud._t = setTimeout(() => hud.classList.remove('open'), 5000); };
  $('#mPlay').onclick = () => { NX.music.toggle(); peek(); };
  hud.querySelector('.mh-moods').onclick = e => { const b = e.target.closest('[data-mood]'); if (!b) return; setMood(b.dataset.mood); if (!st.on) start(); peek(); };
  $('#mStyle').onchange = e => { st.style = e.target.value; save(); restart(); peek(); };
  $('#mVol').oninput = e => { st.vol = +e.target.value; save(); if (master) master.gain.setTargetAtTime(Math.max(.0002, st.vol), ctx.currentTime, .1); };
  const resumeOn = st.wasOn; st.on = false; paintHud(); // browsers require a tap before audio starts
  // Intro: soothing harmonic chime on the first tap; resume music if it was playing last time.
  const firstTap = () => { removeEventListener('pointerdown', firstTap, true); try { chime(); if (resumeOn) setTimeout(start, 900); } catch (e) {} };
  addEventListener('pointerdown', firstTap, true);
  // follow world changes
  let lastWorld = NX.mx?.world; setInterval(() => { if (NX.mx?.world !== lastWorld) { lastWorld = NX.mx.world; restart(); } }, 800);

  /* ---------------- 3. BACK SYSTEM ---------------- */
  const back = document.createElement('button'); back.id = 'nxBack'; back.setAttribute('aria-label', 'Go back'); back.innerHTML = '‹<span>Back</span>';
  document.body.appendChild(back);
  NX.back = () => {
    if (document.getElementById('sheet').classList.contains('open')) return NX.closeSheet();
    if (document.getElementById('nxCmd')?.classList.contains('open')) return closeCmd();
    if (history.length > 1 && history.state && history.state.nx) history.back(); else NX.go('home');
  };
  back.onclick = () => { NX.haptic?.(8); NX.back(); };
  const paintBack = () => back.classList.toggle('show', NX.current !== 'home' || document.body.classList.contains('sheet-open'));
  setInterval(paintBack, 300);
  // sheets push a history entry so the phone/browser back gesture closes them instead of leaving the page
  const _open = NX.openSheet, _close = NX.closeSheet; let sheetEntry = false, skipPop = false;
  NX.openSheet = html => { _open(html); if (!sheetEntry) { history.pushState({ nx: 1, sheet: 1 }, '', location.hash); sheetEntry = true; } };
  NX.closeSheet = () => { _close(); if (sheetEntry) { sheetEntry = false; if (history.state && history.state.sheet) { skipPop = true; history.back(); } } };
  // capture-phase popstate: if a sheet is open, just close it and stay on the page
  addEventListener('popstate', e => {
    if (skipPop) { skipPop = false; e.stopImmediatePropagation(); return; }
    if (document.getElementById('sheet').classList.contains('open')) { e.stopImmediatePropagation(); sheetEntry = false; _close(); }
  }, true);
  // edge swipe (left edge → right) = back
  let sx = null, sy = 0;
  addEventListener('touchstart', e => { const t = e.touches[0]; sx = t.clientX < 24 ? t.clientX : null; sy = t.clientY; }, { passive: true });
  addEventListener('touchend', e => { if (sx === null) return; const t = e.changedTouches[0]; if (t.clientX - sx > 70 && Math.abs(t.clientY - sy) < 60) NX.back(); sx = null; }, { passive: true });
  addEventListener('keydown', e => {
    if (e.key === 'Escape') { if (document.body.classList.contains('sheet-open')) NX.closeSheet(); else closeCmd(); }
    if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); openCmd(); }
  });

  /* ---------------- 4. COMMAND PALETTE ---------------- */
  const cmd = document.createElement('div'); cmd.id = 'nxCmd'; cmd.innerHTML = '<div class="cmd-box"><input id="cmdIn" placeholder="Jump to page, world or action…" autocomplete="off"><div id="cmdList"></div><small>↑↓ · Enter · Esc — or Ctrl/⌘ + K anywhere</small></div>';
  document.body.appendChild(cmd);
  const items = () => [...(NX.extraCmds ? NX.extraCmds() : []),
    ...NX.modules.filter(m => m.id !== 'world').map(m => ({ t: m.icon + '  ' + m.name, k: 'page', run: () => NX.go(m.id) })),
    ...NX.worlds.map(w => ({ t: '❖  World · ' + w.name, k: 'world', run: () => { NX.mx.world = w.id; NX.saveMx(); NX.applyWorld?.(); NX.go(NX.current, false); NX.toast(w.name); } })),
    { t: '♪  Toggle ambient music', k: 'action', run: () => NX.music.toggle() },
    { t: '✦  Load demo data', k: 'action', run: () => { NX.loadDemo(); NX.go('home'); NX.toast('Demo data loaded ✓'); } },
    { t: '✓  Testing checklist', k: 'action', run: () => NX.go('qa') },
  ];
  let sel = 0, shown = [];
  const paintCmd = () => { const q = $('#cmdIn').value.toLowerCase(); shown = items().filter(i => i.t.toLowerCase().includes(q)).slice(0, 40); sel = Math.min(sel, Math.max(shown.length - 1, 0)); $('#cmdList').innerHTML = shown.map((i, n) => `<button data-i="${n}" class="${n === sel ? 'on' : ''}"><span>${i.t}</span><em>${i.k}</em></button>`).join('') || '<p class="dim">No match</p>'; };
  function openCmd() { cmd.classList.add('open'); $('#cmdIn').value = ''; sel = 0; paintCmd(); setTimeout(() => $('#cmdIn').focus(), 30); }
  function closeCmd() { cmd.classList.remove('open'); }
  NX.openCmd = openCmd;
  $('#cmdIn').oninput = () => { sel = 0; paintCmd(); };
  $('#cmdIn').onkeydown = e => { if (e.key === 'ArrowDown') { sel = Math.min(sel + 1, shown.length - 1); paintCmd(); e.preventDefault(); } if (e.key === 'ArrowUp') { sel = Math.max(sel - 1, 0); paintCmd(); e.preventDefault(); } if (e.key === 'Enter' && shown[sel]) { closeCmd(); shown[sel].run(); } };
  $('#cmdList').onclick = e => { const b = e.target.closest('[data-i]'); if (b) { closeCmd(); shown[+b.dataset.i].run(); } };
  cmd.onclick = e => { if (e.target === cmd) closeCmd(); };
  document.getElementById('screenTitle').addEventListener('dblclick', openCmd);
  const fab = document.createElement('button'); fab.id = 'cmdFab'; fab.setAttribute('aria-label', 'Command palette'); fab.textContent = '⌘'; fab.onclick = openCmd; document.body.appendChild(fab);

  /* ---------------- 5. QA CHECKLIST PAGE ---------------- */
  const CHECKS = {
    'Every page': ['Opens with no blank screen', 'Back button (top-left) returns to previous page', 'Phone back gesture / swipe from left edge works', 'Nothing hidden behind the bottom bar'],
    Command: ['Life Index ring and stat pods do not overlap', '“Load demo data” fills the dashboard', 'Companion bubble greets you by name'],
    Tasks: ['Add a task, edit it, mark Completed, delete it', 'Filters change the list'],
    Worlds: ['Switch to Westeros, Albuquerque Lab, Middle-earth, Heist, 221B', 'Companion changes with the world (Tyrion, Mr. White, Gandalf…)', 'Ambient music ♪ plays and changes per world'],
    Studio: ['Change accent colour inside a world', 'Reorder navigation and reload — order is kept'],
    Settings: ['Export backup downloads a file', 'Import restores it', 'Clear demo data keeps your real entries'],
    'Command palette': ['Ctrl/⌘ + K or ⌘ button opens it', 'Typing “gym” or “west” jumps correctly'],
  };
  const auto = () => {
    const r = [];
    const ok = (n, c) => r.push([n, !!c]);
    ok('Storage writable', (() => { try { localStorage.setItem('nx.t', '1'); localStorage.removeItem('nx.t'); return 1; } catch (e) { return 0; } })());
    ok(NX.worlds.length + ' worlds registered', NX.worlds.length >= 28);
    ok('Every world has companions', NX.worlds.every(w => NX.companionsFor(w.id).length >= 2));
    ok('Demo generator returns entries', NX.demo().length > 20);
    ok(NX.modules.length + ' pages registered', NX.modules.length > 10);
    ok('No horizontal overflow', document.documentElement.scrollWidth <= innerWidth + 1);
    ok('Bottom banner space removed', getComputedStyle(document.documentElement).getPropertyValue('--hg').trim() === '0px');
    ok('Audio supported', !!(window.AudioContext || window.webkitAudioContext));
    return r;
  };
  NX.renderQA = v => {
    v.innerHTML = `<section class="qa"><h1 class="display">Testing checklist</h1><p class="dim">Tick each item on your phone. Saved in this browser.</p>
      <button class="btn" id="qaRun">Run automatic checks</button><div id="qaAuto"></div>
      ${Object.entries(CHECKS).map(([pg, list]) => `<div class="card qa-card"><h3>${pg} <small class="dim">${list.filter((_, i) => st.checks[pg + i]).length}/${list.length}</small></h3>${list.map((c, i) => `<label class="qa-row"><input type="checkbox" data-k="${pg + i}" ${st.checks[pg + i] ? 'checked' : ''}><span>${c}</span></label>`).join('')}</div>`).join('')}
      <button class="btn small" id="qaReset">Reset ticks</button></section>`;
    v.querySelector('#qaRun').onclick = () => { v.querySelector('#qaAuto').innerHTML = auto().map(([n, p]) => `<div class="qa-row ${p ? 'pass' : 'fail'}">${p ? '✓' : '✗'} ${n}</div>`).join(''); };
    v.querySelectorAll('[data-k]').forEach(b => b.onchange = () => { st.checks[b.dataset.k] = b.checked; save(); NX.renderQA(v); });
    v.querySelector('#qaReset').onclick = () => { st.checks = {}; save(); NX.renderQA(v); };
  };
  if (!NX.modules.find(m => m.id === 'qa')) NX.modules.push({ id: 'qa', name: 'Testing', icon: '✓', render: v => NX.renderQA(v) });
})();
