/* =========================================================
   COMPANIONS + LOCAL INTELLIGENCE
   - Every world has its own original companion characters (3 + classic ONE-811).
   - Selection is saved per world in NX.mx.companions (included in JSON backups).
   - NX.brain: a local, rules-based analysis engine. It reads ONLY records stored
     in this browser. It is NOT a connected LLM. NX.brain.provider is an optional
     future hook for a real generative AI backend (not configured).
   - Reminders: in-app + browser notifications while the app is open.
   ========================================================= */
(function () {
  const pad = n => String(n).padStart(2, '0');
  const iso = d => [d.getFullYear(), pad(d.getMonth() + 1), pad(d.getDate())].join('-');
  const addDays = (s, n) => { const d = new Date(s + 'T00:00:00'); d.setDate(d.getDate() + n); return iso(d); };
  const diff = (a, b) => Math.round((new Date(b + 'T00:00:00') - new Date(a + 'T00:00:00')) / 864e5);
  const ago = s => s ? Math.floor((Date.now() - new Date(s).getTime()) / 864e5) : 0;
  const plural = (n, w, p) => `${n} ${n === 1 ? w : (p || w + 's')}`;
  const real = type => { const all = NX.list(type), r = all.filter(x => !x.demo); return r.length ? r : all; };
  const openTask = t => !['Completed', 'Cancelled'].includes(t.status);
  const fmt = s => (NX.fmtDate ? NX.fmtDate(s) : s);
  const nextAnnual = (s, t) => { if (!s || s.length < 10) return null; const md = s.slice(5, 10); const y = +t.slice(0, 4); let c = y + '-' + md; if (c < t) c = (y + 1) + '-' + md; return c; };
  const tod = () => { const h = new Date().getHours(); return h < 5 ? 'Still up' : h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening'; };
  const toMin = s => { const m = String(s || '').match(/(\d{1,2})(?::(\d{2}))?\s*(am|pm)?/i); if (!m) return null; let h = +m[1]; const mi = +(m[2] || 0); const ap = (m[3] || '').toLowerCase(); if (ap === 'pm' && h < 12) h += 12; if (ap === 'am' && h === 12) h = 0; return h > 23 ? null : h * 60 + mi; };
  const hhmm = m => pad(Math.floor(m / 60) % 24) + ':' + pad(m % 60);

  /* ---------------- avatars (original SVG characters) ---------------- */
  const S = b => `<svg class="cp" viewBox="0 0 120 160" aria-hidden="true"><ellipse class="dr-shadow" cx="60" cy="152" rx="38" ry="5"/><g class="cp-b">${b}</g></svg>`;
  const AV = {
    orb: () => S(`<path d="M50 108 Q60 142 70 108 Z" class="cp-fill2 cp-flame"/><circle cx="60" cy="70" r="40" class="cp-shell"/><circle cx="60" cy="70" r="31" class="cp-ring cp-spin"/><g class="cp-look"><circle cx="60" cy="70" r="14" class="cp-eye cp-glowf"/><circle cx="60" cy="70" r="5" class="cp-pupil"/></g>`),
    visor: () => S(`<path d="M22 150 L30 108 Q60 96 90 108 L98 150 Z" class="cp-dark cp-edge"/><path d="M60 112 l6 12 13 2 -10 9 3 13 -12 -7 -12 7 3 -13 -10 -9 13 -2 z" class="cp-fill1"/><path d="M30 60 Q30 22 60 20 Q90 22 90 60 L86 92 Q60 108 34 92 Z" class="cp-dark cp-edge"/><path d="M60 20 V36" class="cp-line"/><g class="cp-look"><path d="M38 56 L60 70 L82 56 L80 67 L60 81 L40 67 Z" class="cp-eye cp-glowf"/></g>`),
    owl: () => S(`<path d="M28 50 L36 24 L48 42 Q60 38 72 42 L84 24 L92 50 Q100 80 92 112 Q60 140 28 112 Q20 80 28 50 Z" class="cp-dark cp-edge"/><path d="M28 72 Q12 95 30 120 M92 72 Q108 95 90 120" class="cp-line"/><path d="M44 100 Q60 112 76 100 M46 110 Q60 120 74 110" class="cp-line soft"/><circle cx="45" cy="64" r="13" class="cp-fill2"/><circle cx="75" cy="64" r="13" class="cp-fill2"/><g class="cp-look"><circle cx="45" cy="64" r="6" class="cp-void"/><circle cx="75" cy="64" r="6" class="cp-void"/><circle cx="47" cy="62" r="2" class="cp-pupil"/><circle cx="77" cy="62" r="2" class="cp-pupil"/></g><path d="M56 76 L60 86 L64 76 Z" class="cp-fill1"/><path d="M46 140 l3 -12 M74 140 l-3 -12" class="cp-line"/><circle cx="104" cy="28" r="2.5" class="cp-spark"/><circle cx="14" cy="40" r="2" class="cp-spark d2"/>`),
    stone: () => S(`<path d="M60 22 L94 42 L94 102 L60 124 L26 102 L26 42 Z" class="cp-dark cp-edge"/><path d="M46 52 L60 44 L74 52 M60 44 V58 M46 96 L60 86 L74 96" class="cp-rune"/><g class="cp-look"><circle cx="60" cy="72" r="9" class="cp-eye cp-glowf"/><circle cx="60" cy="72" r="3.5" class="cp-pupil"/></g><ellipse cx="60" cy="140" rx="28" ry="5" class="cp-orbitring"/>`),
    phoenix: () => S(`<path d="M60 58 Q30 30 8 40 Q26 52 24 70 Q40 66 52 82 Z" class="cp-fill1 cp-wingL"/><path d="M60 58 Q90 30 112 40 Q94 52 96 70 Q80 66 68 82 Z" class="cp-fill1 cp-wingR"/><path d="M52 110 Q60 150 68 110 Q64 132 60 140 Q56 132 52 110" class="cp-fill2 cp-flame"/><path d="M60 40 Q76 52 72 86 Q66 110 60 116 Q54 110 48 86 Q44 52 60 40 Z" class="cp-dark cp-edge"/><path d="M60 24 Q67 32 60 41 Q53 32 60 24 Z" class="cp-fill2"/><g class="cp-look"><circle cx="54" cy="57" r="3" class="cp-eye cp-glowf"/><circle cx="66" cy="57" r="3" class="cp-eye cp-glowf"/></g><path d="M57 65 L60 71 L63 65 Z" class="cp-fill2"/>`),
    raven: () => S(`<path d="M30 76 L12 112 L36 102 Z M90 76 L106 114 L82 102 Z" class="cp-dark cp-edge"/><path d="M30 60 Q34 30 62 28 Q86 30 90 52 L106 58 L90 64 Q92 100 76 124 L44 124 Q26 100 30 60 Z" class="cp-dark cp-edge"/><g class="cp-look"><rect x="38" y="45" width="46" height="11" rx="5.5" class="cp-eye cp-glowf"/><rect x="66" y="47.5" width="9" height="6" rx="3" class="cp-pupil"/></g><path d="M44 90 H76 M48 100 H72" class="cp-line soft"/><path d="M50 124 l-4 16 M70 124 l4 16" class="cp-line"/>`),
    shade: () => S(`<path d="M60 18 Q96 26 98 74 L104 144 Q60 132 16 144 L22 74 Q24 26 60 18 Z" class="cp-dark cp-edge"/><path d="M60 34 Q84 40 84 70 Q84 92 60 96 Q36 92 36 70 Q36 40 60 34 Z" class="cp-void"/><g class="cp-look"><path d="M42 66 L54 61 L54 69 Z M78 66 L66 61 L66 69 Z" class="cp-eye cp-glowf"/></g><path d="M40 112 Q60 122 80 112 M44 126 Q60 134 76 126" class="cp-line soft"/>`),
    aide: () => S(`<path d="M28 150 L32 98 Q60 88 88 98 L92 150 Z" class="cp-dark cp-edge"/><path d="M50 95 L60 101 L50 107 Z M70 95 L60 101 L70 107 Z" class="cp-fill1"/><path d="M60 110 V146" class="cp-line soft"/><circle cx="60" cy="120" r="2.2" class="cp-fill1"/><circle cx="60" cy="132" r="2.2" class="cp-fill1"/><rect x="32" y="38" width="56" height="46" rx="13" class="cp-shell"/><rect x="40" y="10" width="40" height="24" rx="3" class="cp-dark cp-edge"/><rect x="28" y="31" width="64" height="6" rx="3" class="cp-dark cp-edge"/><g class="cp-look"><circle cx="48" cy="59" r="5" class="cp-eye"/><circle cx="72" cy="59" r="8.5" class="cp-mono"/><circle cx="72" cy="59" r="4.5" class="cp-eye"/><path d="M80.5 62 Q86 78 80 90" class="cp-line soft"/></g><path d="M48 74 Q60 79 72 74" class="cp-line"/>`),
    moth: () => S(`<path d="M58 60 Q30 18 10 40 Q8 70 40 80 Q14 96 26 124 Q46 126 58 96 Z" class="cp-fill1 cp-wingL o"/><path d="M62 60 Q90 18 110 40 Q112 70 80 80 Q106 96 94 124 Q74 126 62 96 Z" class="cp-fill1 cp-wingR o"/><circle cx="30" cy="50" r="6" class="cp-dark"/><circle cx="90" cy="50" r="6" class="cp-dark"/><path d="M60 46 Q70 60 66 110 Q60 124 54 110 Q50 60 60 46 Z" class="cp-dark cp-edge"/><path d="M56 46 Q48 26 40 20 M64 46 Q72 26 80 20" class="cp-line"/><g class="cp-look"><circle cx="56" cy="57" r="3.2" class="cp-eye cp-glowf"/><circle cx="64" cy="57" r="3.2" class="cp-eye cp-glowf"/></g>`),
    radio: () => S(`<path d="M76 40 V12" class="cp-line"/><circle cx="76" cy="10" r="3.5" class="cp-fill1 cp-blink"/><path d="M86 20 Q94 28 86 36 M93 13 Q106 28 93 43" class="cp-wave"/><rect x="34" y="40" width="52" height="96" rx="10" class="cp-dark cp-edge"/><rect x="42" y="50" width="36" height="22" rx="3" class="cp-screen"/><g class="cp-look"><circle cx="54" cy="61" r="3.5" class="cp-eye cp-glowf"/><circle cx="66" cy="61" r="3.5" class="cp-eye cp-glowf"/></g><path d="M42 84 H78 M42 92 H78 M42 100 H78 M42 108 H78" class="cp-line soft"/><circle cx="60" cy="124" r="5" class="cp-fill1"/>`),
    eye: () => S(`<path d="M40 102 Q30 128 38 146 M60 108 V148 M80 102 Q90 128 82 146" class="cp-line soft"/><circle cx="60" cy="68" r="40" class="cp-shell"/><circle cx="60" cy="68" r="26" class="cp-sclera"/><g class="cp-look"><circle cx="60" cy="68" r="13" class="cp-eye cp-glowf"/><circle cx="60" cy="68" r="5" class="cp-void"/><circle cx="56" cy="64" r="2.5" class="cp-pupil"/></g><text x="60" y="103" class="cp-tag">09</text>`),
    cat: () => S(`<path d="M82 128 Q106 126 100 98" class="cp-line thick"/><rect x="38" y="102" width="44" height="36" rx="15" class="cp-shell"/><path d="M28 60 L30 22 L52 44 Q60 42 68 44 L90 22 L92 60 Q98 102 60 104 Q22 102 28 60 Z" class="cp-shell"/><g class="cp-look"><ellipse cx="46" cy="66" rx="6" ry="8" class="cp-eye"/><ellipse cx="74" cy="66" rx="6" ry="8" class="cp-eye"/><circle cx="48" cy="63" r="2" class="cp-pupil"/><circle cx="76" cy="63" r="2" class="cp-pupil"/></g><path d="M56 80 L60 84 L64 80 M60 84 Q56 90 50 88 M60 84 Q64 90 70 88" class="cp-line"/><path d="M14 74 H34 M14 83 L34 80 M86 74 H106 M86 80 L106 83" class="cp-line soft"/>`),
    crt: () => S(`<rect x="22" y="20" width="76" height="62" rx="10" class="cp-dark cp-edge"/><rect x="30" y="28" width="60" height="44" rx="6" class="cp-screen"/><g class="cp-look"><rect x="42" y="40" width="8" height="13" class="cp-eye cp-blink2 cp-glowf"/><rect x="70" y="40" width="8" height="13" class="cp-eye cp-blink2 cp-glowf"/></g><path d="M50 62 H70" class="cp-line"/><rect x="50" y="82" width="20" height="10" class="cp-dark cp-edge"/><rect x="34" y="92" width="52" height="44" rx="8" class="cp-dark cp-edge"/><path d="M42 104 H78 M42 112 H66" class="cp-line soft"/><path d="M42 136 l-4 10 M78 136 l4 10" class="cp-line"/>`),
    lantern: () => S(`<path d="M60 8 V22" class="cp-line"/><path d="M40 28 Q24 70 40 112 H80 Q96 70 80 28 Z" class="cp-fill1 o cp-glowf cp-pulse"/><path d="M50 28 Q42 70 50 112 M70 28 Q78 70 70 112" class="cp-line soft"/><rect x="44" y="20" width="32" height="9" rx="2" class="cp-dark cp-edge"/><g class="cp-look"><circle cx="52" cy="66" r="3.6" class="cp-void"/><circle cx="68" cy="66" r="3.6" class="cp-void"/><path d="M54 78 Q60 82 66 78" class="cp-voidl"/></g><rect x="44" y="111" width="32" height="9" rx="2" class="cp-dark cp-edge"/><path d="M60 120 V138" class="cp-line"/><circle cx="60" cy="141" r="3.5" class="cp-fill2"/>`),
    crystal: () => S(`<ellipse cx="60" cy="74" rx="46" ry="11" class="cp-orbitring"/><path d="M60 12 L88 52 L60 128 L32 52 Z" class="cp-fill1 o cp-edge2 cp-glowf"/><path d="M32 52 H88 M60 12 L50 52 L60 128 L70 52 Z" class="cp-line soft"/><g class="cp-look"><circle cx="60" cy="66" r="7.5" class="cp-pupil"/><circle cx="60" cy="66" r="3.2" class="cp-void"/></g><circle cx="106" cy="72" r="3.2" class="cp-spark"/><circle cx="14" cy="76" r="2.4" class="cp-spark d2"/>`),
    cube: () => S(`<path d="M60 22 L98 42 V96 L60 116 L22 96 V42 Z" class="cp-shell"/><path d="M22 42 L60 62 L98 42 M60 62 V116" class="cp-line soft"/><g class="cp-look"><circle cx="35" cy="74" r="4.5" class="cp-eye cp-glowf"/><circle cx="49" cy="81" r="4.5" class="cp-eye cp-glowf"/></g><path d="M74 78 L88 70 M74 88 L88 80" class="cp-line soft"/><path d="M46 138 H74" class="cp-line"/>`),
    quill: () => S(`<path d="M86 10 Q40 30 36 100 L44 104 Q70 60 98 18 Z" class="cp-fill1 o cp-edge"/><path d="M86 12 L41 101" class="cp-line"/><path d="M36 100 L28 128 L44 104 Z" class="cp-dark cp-edge"/><g class="cp-look"><circle cx="61" cy="54" r="3.6" class="cp-void"/><circle cx="72" cy="47" r="3.6" class="cp-void"/></g><path d="M18 142 Q32 132 46 142 T74 142 T102 142" class="cp-ink"/>`),
    film: () => S(`<g class="cp-spin2"><circle cx="42" cy="32" r="18" class="cp-dark cp-edge"/><circle cx="42" cy="32" r="5" class="cp-fill1"/></g><circle cx="78" cy="32" r="18" class="cp-dark cp-edge"/><circle cx="78" cy="32" r="5" class="cp-fill1"/><path d="M40 98 L32 146 M70 98 L78 146 M55 98 V146" class="cp-line"/><rect x="24" y="54" width="62" height="44" rx="8" class="cp-shell"/><path d="M86 66 L104 56 V96 L86 86 Z" class="cp-dark cp-edge"/><g class="cp-look"><circle cx="46" cy="76" r="10" class="cp-sclera"/><circle cx="46" cy="76" r="4.5" class="cp-eye"/><circle cx="70" cy="68" r="3" class="cp-fill2 cp-blink"/></g>`),
    flame: () => S(`<path d="M60 10 Q76 40 90 56 Q104 80 92 108 Q80 130 60 130 Q40 130 28 108 Q16 80 34 58 Q40 74 50 74 Q42 44 60 10 Z" class="cp-fill1 cp-flick cp-glowf"/><path d="M60 56 Q74 76 76 96 Q74 116 60 118 Q46 116 44 96 Q48 80 60 56 Z" class="cp-fill2"/><g class="cp-look"><circle cx="53" cy="96" r="3.6" class="cp-void"/><circle cx="67" cy="96" r="3.6" class="cp-void"/></g><path d="M54 106 Q60 110 66 106" class="cp-voidl"/>`),
    fox: () => S(`<path d="M84 134 Q112 128 104 96 Q98 118 84 122 Z" class="cp-fill1 cp-flame"/><path d="M60 110 Q30 118 34 146 Q56 150 60 130 Q64 150 86 146 Q90 118 60 110 Z" class="cp-dark cp-edge"/><path d="M26 28 L44 56 H76 L94 28 L90 72 Q86 102 60 112 Q34 102 30 72 Z" class="cp-shell"/><path d="M30 34 L41 54 L37 56 Z M90 34 L79 54 L83 56 Z" class="cp-fill1"/><path d="M44 86 Q60 98 76 86 L60 112 Z" class="cp-sclera"/><circle cx="60" cy="62" r="2.6" class="cp-fill2"/><g class="cp-look"><path d="M39 73 Q46 65 53 73 Q46 76 39 73 Z M67 73 Q74 65 81 73 Q74 76 67 73 Z" class="cp-eye cp-glowf"/></g><circle cx="60" cy="104" r="3" class="cp-void"/><circle cx="106" cy="40" r="3" class="cp-spark"/>`),
    jelly: () => S(`<path d="M34 72 Q28 100 38 130 M48 74 Q44 110 50 146 M62 76 Q66 110 60 140 M76 74 Q82 100 74 132 M88 72 Q94 96 86 120" class="cp-wave"/><path d="M22 70 Q22 26 60 26 Q98 26 98 70 Q86 76 74 70 Q62 78 48 70 Q34 76 22 70 Z" class="cp-fill1 o cp-glowf cp-pulse"/><circle cx="42" cy="40" r="3" class="cp-pupil"/><g class="cp-look"><circle cx="50" cy="52" r="4.2" class="cp-void"/><circle cx="70" cy="52" r="4.2" class="cp-void"/><circle cx="51" cy="51" r="1.5" class="cp-pupil"/><circle cx="71" cy="51" r="1.5" class="cp-pupil"/></g><path d="M54 62 Q60 66 66 62" class="cp-voidl"/>`),
    sprout: () => S(`<path d="M60 96 V60" class="cp-line thick"/><path d="M60 72 Q30 66 24 36 Q54 38 60 68 Z" class="cp-fill1 cp-wingL"/><path d="M60 64 Q88 54 98 24 Q66 26 60 60 Z" class="cp-fill2 cp-wingR"/><path d="M36 100 H84 L78 146 H42 Z" class="cp-dark cp-edge"/><rect x="32" y="93" width="56" height="11" rx="3" class="cp-dark cp-edge"/><g class="cp-look"><circle cx="52" cy="121" r="3.8" class="cp-eye cp-glowf"/><circle cx="68" cy="121" r="3.8" class="cp-eye cp-glowf"/></g><path d="M54 131 Q60 135 66 131" class="cp-line"/><circle cx="100" cy="22" r="3" class="cp-spark"/>`),
    invader: () => S(['00100000100', '00010001000', '00111111100', '01101110110', '11111111111', '10111111101', '10100000101', '00011011000'].map((r, y) => [...r].map((ch, x) => ch === '1' ? `<rect x="${7 + x * 9.6}" y="${40 + y * 9.6}" width="9.8" height="9.8" class="cp-fill1"/>` : '').join('')).join('') + `<g class="cp-look"><rect x="35.8" y="68.8" width="9.6" height="9.6" class="cp-eye2 cp-blink2"/><rect x="74.2" y="68.8" width="9.6" height="9.6" class="cp-eye2 cp-blink2"/></g><path d="M20 132 H100" class="cp-line soft"/>`),
    scarab: () => S(`<circle cx="60" cy="12" r="9" class="cp-fill2 cp-glowf cp-pulse"/><path d="M42 32 Q30 20 34 8 M78 32 Q90 20 86 8" class="cp-line"/><path d="M28 70 L12 62 M28 92 L10 96 M32 116 L16 128 M92 70 L108 62 M92 92 L110 96 M88 116 L104 128" class="cp-line"/><path d="M44 34 Q60 20 76 34 L72 46 H48 Z" class="cp-dark cp-edge"/><path d="M60 44 Q96 50 92 96 Q86 132 60 136 Q34 132 28 96 Q24 50 60 44 Z" class="cp-fill1 cp-edge"/><path d="M60 46 V134 M40 70 Q60 62 80 70" class="cp-line soft"/><g class="cp-look"><circle cx="53" cy="37" r="2.8" class="cp-eye2 cp-glowf"/><circle cx="67" cy="37" r="2.8" class="cp-eye2 cp-glowf"/></g>`),
    helm: () => S(`<path d="M28 58 Q32 8 82 12 Q104 18 102 46 Q88 28 66 28 Q42 30 34 62 Z" class="cp-fill2 o cp-flick"/><path d="M36 130 Q60 120 84 130 L88 150 H32 Z" class="cp-dark cp-edge"/><path d="M32 66 Q32 32 60 32 Q88 32 88 66 V108 L72 118 V86 H48 V118 L32 108 Z" class="cp-fill1 cp-edge2"/><path d="M42 64 H78 V76 H66 V112 H54 V76 H42 Z" class="cp-void"/><g class="cp-look"><circle cx="50" cy="70" r="3.2" class="cp-eye2 cp-glowf"/><circle cx="70" cy="70" r="3.2" class="cp-eye2 cp-glowf"/></g><path d="M40 120 L28 104 M80 120 L92 104" class="cp-line soft"/>`),
  };
  NX.avatarSVG = c => (c.kind === 'astro' ? (NX.R2_SVG || AV.orb()) : (AV[c.kind] || AV.orb)());

  /* ---------------- companion roster ---------------- */
  // [id, name, role, avatar, personality, greeting, tic, sign-off, sound[type, base, range], colour?]
  const C = (id, name, role, kind, persona, hi, tic, sign, snd, c1) => ({ id, name, role, kind, persona, hi, tic, sign, sound: { type: snd[0], base: snd[1], range: snd[2] }, c1 });
  const R2 = C('one811', 'ONE-811', 'Classic astromech co-pilot', 'astro', 'Loyal, cheerful, beeps a lot and keeps you rolling.', 'Bweep! {tod}, {n}! Systems green. Ready to roll.', 'Beep-bwoop!', 'Rolling with you.', ['', 700, 2200]);
  const ROSTER = {
    bakerst: [C('sherlock', 'Sherlock', 'Consulting detective', 'raven', 'Brilliant, blunt, deduces your priorities from the evidence.', '{tod}, {n}. You have been neglecting a task — I can tell from your cursor. The game is on.', 'Deduction:', 'Elementary.', ['sawtooth', 180, 420], '#7fa8c8'), C('watson', 'Watson', 'Doctor & blogger', 'aide', 'Practical, kind, checks your health and writes up your wins.', '{tod}, {n}. Doctor’s orders: water, sleep, and one finished task.', 'Medical note:', 'Good work, old friend.', ['triangle', 400, 300], '#c4a06e'), C('mycroft', 'Mycroft', 'The British Government', 'owl', 'Dry, omniscient, sees your whole calendar at once.', '{tod}, {n}. I occupy a minor position — mostly managing your schedule.', 'Official memo:', 'Do try to keep up.', ['sine', 150, 200], '#b0b8c4')],
    heist: [C('professor', 'The Professor', 'Master planner', 'aide', 'Methodical, polite, has a plan B through Z for your week.', '{tod}, {n}. Everything is calculated. Phase one begins now.', 'Plan update:', 'Stick to the plan.', ['sine', 300, 300], '#f5d76e'), C('tokyo', 'Tokyo', 'Wild card', 'phoenix', 'Impulsive, fearless, narrates your day like an epic.', '{tod}, {n}. This is the story of how you won today.', 'Tokyo narrates:', 'Bella ciao.', ['square', 640, 700], '#ff3b3b'), C('berlin', 'Berlin', 'Elegant tactician', 'shade', 'Dramatic, demanding, wants your routines executed with style.', '{tod}, {n}. Elegance is discipline wearing a good suit.', 'Berlin insists:', 'With style, always.', ['triangle', 200, 260], '#e8e1d0')],
    middleearth: [C('gandalf', 'Gandalf', 'The Grey Wizard', 'lantern', 'Wise, warm, a little mischievous. Never late — arrives precisely when needed.', '{tod}, {n}. All we have to decide is what to do with the time given to us.', 'A wizard notes:', 'Fly, you fool — to your next task.', ['sine', 220, 300], '#d6d2c4'), C('sam', 'Samwise', 'Loyal gardener', 'sprout', 'Endlessly kind. Carries you when the road is long.', '{tod}, {n}! There is good in this world, and it is worth working for.', 'Sam says:', 'I can carry you.', ['triangle', 520, 400], '#8fd39a'), C('aragorn', 'Aragorn', 'Ranger of the North', 'helm', 'Calm leader, steady under pressure, inspires courage.', '{tod}, {n}. A day may come when we give up — but it is not this day.', 'Ranger intel:', 'For Frodo.', ['sawtooth', 160, 220], '#d6be78')],
    heisenberg: [C('walter', 'Mr. White', 'Chemistry teacher · perfectionist', 'aide', 'Precise, proud, obsessed with 99.1% purity in everything you do.', '{tod}, {n}. Chemistry is the study of change — so let us change today.', 'Lab report:', 'Say my name… then do the work.', ['sawtooth', 110, 240], '#5fd4ff'), C('jesse', 'Jesse', 'Lab partner, yo', 'radio', 'Chaotic, loyal, surprisingly good at keeping you going.', 'Yo, {n}! {tod}. Science time, let us cook up a good day.', 'Yeah, science:', 'Stay sharp, yo.', ['square', 330, 500], '#e6c64a'), C('saul', 'Saul', 'Criminal(ly good) lawyer', 'cube', 'Fast talker who always finds a loophole in your excuses.', '{tod}, {n}! Better call… your future self. They want results.', 'Legal advice:', 'It is all good, man.', ['triangle', 600, 600], '#f2c14e')],
    westeros: [C('tyrion', 'Tyrion', 'Hand of the King · strategist', 'owl', 'Sharp-tongued, well-read, always three moves ahead. Wins with wit, not swords.', '{tod}, {n}. A mind needs books like a sword needs a whetstone — let us sharpen yours.', 'A word from the Hand:', 'Drink some water. Then conquer.', ['triangle', 260, 340], '#c9a46a'), C('arya', 'Arya', 'Faceless training partner', 'shade', 'Quiet, relentless, keeps a list — of your tasks.', '{tod}, {n}. Not today… unless it is on the list.', 'The list says:', 'Stick them with the pointy end.', ['sine', 520, 260], '#b8c4d0'), C('jon', 'Jon', 'Lord Commander of the Watch', 'helm', 'Honest and steady. Guards your streaks through the long night.', '{tod}, {n}. Winter is coming — so we prepare today.', 'From the Wall:', 'The Watch holds.', ['sawtooth', 130, 180], '#9fd4ff'), C('daenerys', 'Daenerys', 'Breaker of chains', 'phoenix', 'Fierce, visionary, turns setbacks into fire.', '{tod}, {n}. We do not wait for the wheel — we break it.', 'Dracarys check:', 'Fire and blood.', ['triangle', 420, 700], '#ff8a4c')],
    obsidian: [R2, C('lumen', 'Lumen', 'Clarity guide', 'orb', 'Calm and precise. Cuts the noise down to what matters.', '{tod}, {n}. Let us keep things clear.', 'Clarity check:', 'One thing at a time.', ['sine', 500, 600]), C('prism', 'Prism', 'Focus keeper', 'crystal', 'Thoughtful. Splits big work into clean facets.', '{tod}, {n}. Every big task has smaller facets.', 'Refracting your day:', 'Stay sharp.', ['sine', 900, 900])],
    cupertino: [C('pebble', 'Pebble', 'Calm organiser', 'cube', 'Gentle, tidy and minimal. Never rushes you.', '{tod}, {n}. Everything is in its place.', 'Quick note:', 'Breathe. You have got this.', ['sine', 600, 300]), C('halo', 'Halo', 'Daily planner', 'orb', 'Friendly and upbeat. Loves a well-planned day.', '{tod}, {n}! Shall we shape today together?', 'Heads up:', 'Have a lovely day.', ['triangle', 800, 500]), C('breeze', 'Breeze', 'Wellbeing nudge', 'lantern', 'Soft-spoken. Reminds you to rest as well as work.', '{tod}, {n}. Light and steady wins today.', 'Gentle reminder:', 'Take a breather when you need it.', ['sine', 400, 300])],
    luxury: [C('sterling', 'Sterling', 'Private concierge', 'aide', 'Impeccably polite. Treats your time as precious.', '{tod}, {n}. Your agenda has been prepared.', 'If I may:', 'At your service.', ['triangle', 300, 300]), C('aurum', 'Aurum', 'Wealth steward', 'crystal', 'Measured and refined. Watches spending and value.', '{tod}, {n}. Let us invest the day wisely.', 'A considered note:', 'Spend time like gold.', ['sine', 350, 250]), C('velvet', 'Velvet', 'Quiet confidant', 'shade', 'Discreet, warm and unhurried.', '{tod}, {n}. Shall we begin, quietly?', 'Between us:', 'Elegance is focus.', ['sine', 260, 200])],
    cyber: [C('glitch', 'Glitch', 'Netrunner assistant', 'crt', 'Fast-talking hacker. All slang and speed.', 'Jacked in. {tod}, {n} — let us run the day.', 'Ping:', 'Stay chrome.', ['square', 1200, 2500]), C('neon7', 'Neon-7', 'Street tactician', 'visor', 'Cool, clipped and tactical.', '{tod}, {n}. Grid is live. Targets incoming.', 'Target acquired:', 'Flatline the backlog.', ['sawtooth', 400, 1400]), C('byte', 'Byte', 'Pocket drone', 'cat', 'Playful, mischievous, surprisingly sharp.', 'Nya-beep! {tod}, {n}. Snacks? No? Tasks then.', 'Byte says:', 'Purr-cessing complete.', ['square', 1600, 1800])],
    editorial: [C('quill', 'Quill', 'Editor-in-chief', 'quill', 'Crisp and witty. Writes your day like a front page.', "{tod}, {n}. Today's edition is ready for print.", 'Headline:', 'Fin.', ['triangle', 500, 400]), C('ledger', 'Ledger', 'Fact checker', 'cube', 'Dry humour. Insists on accuracy.', '{tod}, {n}. Facts first, as always.', 'For the record:', 'Verified.', ['square', 450, 300]), C('margo', 'Margo', 'Columnist owl', 'owl', 'Wise and observant. Notices patterns.', '{tod}, {n}. I have been reading between your lines.', 'Observation:', 'Write boldly.', ['sine', 520, 500])],
    minimal: [C('dot', 'Dot', 'Essentialist', 'cube', 'Says as little as possible.', '{tod}, {n}.', '·', '—', ['sine', 880, 100]), C('mono', 'Mono', 'Single-focus guide', 'orb', 'Believes in doing one thing well.', '{tod}, {n}. One priority. Begin.', 'Next:', 'Done is enough.', ['sine', 660, 120]), C('line', 'Line', 'Step-by-step planner', 'quill', 'Linear and orderly.', '{tod}, {n}. Step one is ready.', 'Step:', 'Continue.', ['triangle', 720, 200])],
    midnight: [C('nova', 'Nova', 'Dream navigator', 'crystal', 'Starry-eyed, encouraging, a little poetic.', '{tod}, {n}. The sky is clear for big moves.', 'Starlight note:', 'Shine on.', ['sine', 900, 1200]), C('lyra', 'Lyra', 'Night-shift muse', 'moth', 'Soft, creative and kind.', '{tod}, {n}. Let us make something beautiful.', 'Whisper:', 'Rest well later.', ['sine', 1100, 700]), C('orion', 'Orion', 'Constellation mapper', 'orb', 'Connects scattered tasks into one picture.', "{tod}, {n}. Mapping today's constellation.", 'Coordinates:', 'Steady course.', ['triangle', 600, 800])],
    cinematic: [C('reel', 'Reel', 'Production assistant', 'film', 'Treats your day like a film shoot.', '{tod}, {n}. Places, everyone — today is rolling.', 'Scene note:', 'That is a wrap.', ['square', 500, 900]), C('director', 'Director', 'Story strategist', 'visor', 'Big-picture, dramatic, decisive.', '{tod}, {n}. Every great day needs a strong opening.', 'Direction:', 'Cut — and print.', ['sawtooth', 260, 400]), C('usher', 'Usher', 'Front-of-house guide', 'lantern', 'A warm host who shows you to the right seat.', "{tod}, {n}. Right this way to today's programme.", 'Now showing:', 'Enjoy the show.', ['triangle', 420, 300])],
    brutal: [C('block', 'Block', 'No-nonsense foreman', 'cube', 'Blunt and loud. Hates excuses.', '{TOD}, {N}. WORK IS WAITING.', 'LISTEN:', 'BUILD IT.', ['square', 200, 300]), C('rivet', 'Rivet', 'Workshop bot', 'crt', 'Practical and hands-on. Fixes things.', '{tod}, {n}. Tools out. Let us fix the list.', 'Shop note:', 'Bolted down.', ['square', 300, 600]), C('slab', 'Slab', 'Foundation keeper', 'stone', 'Solid and patient. Builds habits brick by brick.', '{tod}, {n}. One brick today. Then another.', 'Foundation:', 'Solid.', ['sine', 180, 150])],
    studio: [C('doodle', 'Doodle', 'Creative sidekick', 'cat', 'Bubbly, playful and full of ideas.', '{tod}, {n}! Let us colour outside the lines today.', 'Ooh, idea:', 'Make it fun!', ['triangle', 1200, 1600]), C('blob', 'Blob', 'Mood shaper', 'orb', 'Squishy and upbeat. Celebrates small wins.', '{tod}, {n}! Tiny wins count — let us collect some.', 'Blip:', 'Wobble on!', ['sine', 700, 1400]), C('pixel', 'Pixel', 'Design critic', 'cube', 'Detail-obsessed, kind but honest.', '{tod}, {n}. Let us polish one thing to perfection.', 'Pixel-peep:', 'Ship it.', ['square', 1400, 900])],
    terminal: [C('daemon', 'Daemon', 'Background process', 'crt', 'Terse sysadmin. Speaks in commands.', '$ greet --user {n}  # {tod}. uptime OK.', '[info]', 'exit 0', ['square', 900, 600]), C('cron', 'Cron', 'Scheduler', 'radio', 'Obsessed with timing and schedules.', '{tod}, {n}. Jobs queued for today.', '[cron]', 'next run scheduled.', ['square', 1000, 300]), C('root', 'Root', 'Superuser', 'cube', 'Confident. Cuts to the core issue.', '# {tod}, {n}. Elevated access: today.', '[root]', 'permissions granted.', ['sawtooth', 700, 500])],
    daylight: [C('sunny', 'Sunny', 'Morning coach', 'orb', 'Bright, energetic, a morning person.', '{tod}, {n}! Sunshine and a fresh start.', 'Bright idea:', 'Keep glowing!', ['triangle', 900, 900]), C('kite', 'Kite', 'Momentum guide', 'phoenix', 'Breezy and optimistic. Keeps you lifting.', '{tod}, {n}. Catch the wind — today is light.', 'Updraft:', 'Fly high.', ['sine', 1000, 1000]), C('mint', 'Mint', 'Fresh-start helper', 'cat', 'Cheerful and tidy. Loves a clean slate.', '{tod}, {n}! Fresh page, fresh plan.', 'Fresh note:', 'Stay fresh.', ['triangle', 1300, 700])],
    ember: [C('cinder', 'Cinder', 'Fire starter', 'flame', 'Fiery motivator. Pushes intensity.', '{tod}, {n}. Let us turn up the heat.', 'Spark:', 'Burn bright.', ['sawtooth', 300, 800]), C('forge', 'Forge', 'Discipline smith', 'visor', 'Gruff and steady. Hammers out habits.', '{tod}, {n}. Iron is hot. Strike now.', 'From the anvil:', 'Tempered.', ['sawtooth', 160, 300]), C('ash', 'Ash', 'Recovery keeper', 'moth', 'Calm after the fire. Protects your rest.', '{tod}, {n}. Strong days need cool heads.', 'Embers say:', 'Cool down well.', ['sine', 300, 400])],
    nexus: [C('miles', 'Miles', 'Brooklyn web-slinger', 'visor', 'Young, bold, figures it out mid-air. Anyone can wear the mask.', '{tod}, {n}! It’s a leap of faith — and today we jump.', 'Spidey-sense:', 'Do your own thing.', ['square', 520, 900], '#ff3b5c'), C('gwen', 'Gwen', 'Drummer from Earth-65', 'phoenix', 'Cool, rhythmic, keeps your routines on beat.', '{tod}, {n}. Let us keep the tempo — four beats, four tasks.', 'Beat check:', 'Stay in rhythm.', ['triangle', 660, 700], '#ff8bd1'), C('vanguard', 'Vanguard', 'Mission strategist', 'visor', 'Decisive commander. Turns your day into missions.', 'Mission clock is running, {n}. {tod} — briefing ready.', 'Mission update:', 'Assemble and execute.', ['sawtooth', 220, 600], '#ff3b5c'), C('pulse', 'Pulse', 'Energy analyst', 'orb', 'Measures your momentum, streaks and energy.', '{tod}, {n}. Energy readings are coming in.', 'Energy reading:', 'Keep the charge.', ['sine', 600, 1500], '#ffd23f'), C('nexus', 'Nexus', 'World connector', 'crystal', 'Sees the links across goals, projects and people.', '{tod}, {n}. All your realms are connected.', 'Connection found:', 'Every thread links.', ['triangle', 800, 1200], '#54a8ff')],
    gotham: [C('bruce', 'Bruce', 'The Dark Knight', 'visor', 'Driven, disciplined, trains every night. Turns fear into fuel.', '{tod}, {n}. It is not who you are underneath — it is what you do today.', 'From the cave:', 'I am vengeance. Also, hydrate.', ['sawtooth', 90, 160], '#d8b55a'), C('alfred', 'Alfred', 'Butler & conscience', 'aide', 'Dry British wit. Makes sure the hero also eats and sleeps.', '{tod}, Master {n}. Why do we fall? So we can learn to pick ourselves up.', 'If I may, sir:', 'Do get some rest.', ['triangle', 330, 240], '#c9c2b0'), C('nightwatch', 'Nightwatch', 'Case analyst', 'raven', 'Detective-minded. Treats loose tasks as open cases.', '{tod}, {n}. The city is quiet. Your case files are not.', 'Case note:', 'The night is watching.', ['sawtooth', 140, 300]), C('shade', 'Shade', 'Quiet strategist', 'shade', 'Few words, long plans.', '{tod}, {n}. Move quietly. Move first.', 'Intel:', 'Stay in the shadows.', ['sine', 160, 200], '#8fb0d8'), C('marlowe', 'Marlowe', 'Operations aide', 'aide', 'Unflappable, dry wit, keeps the whole house running.', '{tod}, {n}. Tea is hypothetical; your schedule is not.', 'If you will permit me:', 'Very good.', ['triangle', 330, 260])],
    wizard: [C('hermione', 'Hermione', 'Brightest witch of her age', 'owl', 'Organised, studious, has already read ahead for you.', '{tod}, {n}. Honestly — if you just made a timetable…', 'Library note:', 'It’s levi-O-sa, not levio-SA.', ['triangle', 880, 700], '#e0a94a'), C('dumbledore', 'Dumbledore', 'Headmaster', 'lantern', 'Gentle, wise, believes in your choices more than your abilities.', '{tod}, {n}. It is our choices that show what we truly are.', 'A thought from the Headmaster:', 'Happiness can be found in the darkest of times.', ['sine', 300, 500], '#8fd3c1'), C('hagrid', 'Hagrid', 'Keeper of keys', 'stone', 'Big-hearted, loud, celebrates every little win.', '{tod}, {n}! Yer a wizard at this — another streak!', 'Hagrid reckons:', 'Shouldn’ta said that.', ['triangle', 200, 300], '#b98a5a'), C('wisp', 'Wisp', 'Lore keeper', 'owl', 'Scholarly and curious. Quotes old wisdom.', "{tod}, {n}. The archive has unrolled today's scroll.", 'From the archive:', 'May your quill stay sharp.', ['sine', 1200, 900]), C('runestone', 'Runestone', 'Study familiar', 'stone', 'A patient tutor who loves revision and learning streaks.', '{tod}, {n}. The runes favour steady study.', 'Rune reading:', 'Knowledge endures.', ['triangle', 260, 300], '#8fd3c1'), C('emberwing', 'Emberwing', 'Quest guide', 'phoenix', 'Brave and warm. Turns goals into quests.', '{tod}, {n}! A new quest awaits.', 'Quest log:', 'Rise again tomorrow.', ['sine', 700, 1300], '#ff7a3d')],
    samurai: [C('kitsu', 'Kitsu', 'Spirit fox guide', 'fox', 'Playful trickster spirit with a sharp eye for shortcuts.', '{tod}, {n}. The lanterns are lit — shall we begin?', 'The fox notices:', 'Walk the path lightly.', ['triangle', 880, 500], '#ff8a3d'), C('ronin', 'Ronin', 'Wandering strategist', 'shade', 'Calm, disciplined, speaks in short proverbs.', '{tod}, {n}. One cut. Clean and certain.', 'The way:', 'Discipline is freedom.', ['triangle', 300, 200]), C('sensei', 'Sensei', 'Ink master', 'quill', 'Patient teacher. Values practice over perfection.', '{tod}, {n}. Prepare the ink; today we practise.', 'Lesson:', 'Again tomorrow, a little better.', ['triangle', 520, 300], '#f2b8c6')],
    abyss: [C('lumi', 'Lumi', 'Bioluminescent guide', 'jelly', 'Gentle glow in the dark. Lights the next step only.', '{tod}, {n}. I will light the way, one step at a time.', 'Glow note:', 'Drift easy.', ['sine', 900, 700]), C('nautilus', 'Nautilus', 'Deep navigator', 'orb', 'Slow, deep thinker. Plans long voyages.', '{tod}, {n}. Charting a course through today.', 'Sonar ping:', 'Steady depth.', ['sine', 240, 300], '#7dffb2'), C('coral', 'Coral', 'Reef keeper', 'sprout', 'Nurturing. Grows habits that protect you.', '{tod}, {n}! The reef grows a little every day.', 'Reef report:', 'Keep growing.', ['triangle', 700, 600], '#ff7aa8')],
    solar: [C('fern', 'Fern', 'Garden mentor', 'sprout', 'Grounded and kind. Grows big goals from small seeds.', '{tod}, {n}. Let us water one important thing today.', 'Garden note:', 'Grow gently.', ['triangle', 650, 500]), C('sol', 'Sol', 'Energy keeper', 'orb', 'Sunny optimist who tracks your energy and rest.', '{tod}, {n}! Fully charged and ready to shine.', 'Sun check:', 'Recharge when you need.', ['sine', 800, 800], '#f2a900'), C('wren', 'Wren', 'Busy messenger', 'phoenix', 'Quick and chirpy. Loves ticking things off.', '{tod}, {n}! Tweet — today is ready.', 'Chirp:', 'Fly on!', ['sine', 1300, 900])],
    arcade: [C('player1', 'Player One', 'Pixel hero', 'invader', 'Competitive gamer who turns tasks into levels.', 'PRESS START, {N}! {tod} — level 1 loaded.', 'Power-up:', 'GAME ON.', ['square', 700, 900]), C('combo', 'Combo', 'Streak coach', 'crt', 'Hyped commentator who loves streaks and combos.', '{tod}, {n}! Combo meter is ready — chain those wins.', 'Combo x2:', 'High score incoming.', ['square', 900, 1200], '#ff3df2'), C('bit', 'Bit', 'Tiny sidekick', 'cube', 'Small, fast, endlessly cheerful.', 'Bip-bip! {tod}, {n}!', 'Bit says:', 'Bip!', ['square', 1500, 600])],
    dune: [C('paul', 'Paul', 'Kwisatz Haderach', 'visor', 'Prescient and calm. Sees the paths of your week before you walk them.', '{tod}, {n}. Fear is the mind-killer — so we move anyway.', 'Prescience:', 'The spice must flow.', ['sine', 140, 300], '#5ac8fa'), C('chani', 'Chani', 'Fremen warrior', 'moth', 'Direct, grounded, keeps you honest and hydrated in the desert.', '{tod}, {n}. Desert power begins with water discipline.', 'Fremen way:', 'Walk without rhythm.', ['triangle', 420, 400], '#f0a046'), C('stilgar', 'Stilgar', 'Naib of Sietch Tabr', 'shade', 'Devoted believer. Every finished task is a prophecy fulfilled.', '{tod}, {n}! As it is written — today you will win.', 'As written:', 'Lisan al-Gaib!', ['sawtooth', 110, 200], '#d9b27a'), C('khepri', 'Khepri', 'Sun tracker', 'scarab', 'Ancient and patient. Rolls each day forward.', '{tod}, {n}. The sun rises; so does the work.', 'The sands say:', 'Endure and arrive.', ['sawtooth', 200, 300]), C('nomad', 'Nomad', 'Desert scout', 'shade', 'Resourceful survivor. Travels light, wastes nothing.', '{tod}, {n}. Pack light — only what matters today.', 'Scout report:', 'Water first, then walk.', ['triangle', 280, 300], '#5ac8fa'), C('mirage', 'Mirage', 'Truth seer', 'crystal', 'Separates real priorities from shimmering distractions.', '{tod}, {n}. Let us see what is real today.', 'Clear sight:', 'Trust what is real.', ['sine', 1000, 900])],
    olympus: [C('pallas', 'Pallas', 'Wisdom advisor', 'owl', 'Wise strategist who weighs every choice.', '{tod}, {n}. Wisdom first, then action.', 'Counsel:', 'Choose wisely.', ['sine', 560, 400], '#3f6fb5'), C('helios', 'Helios', 'Champion coach', 'helm', 'Heroic and bold. Pushes you toward glory.', '{tod}, {n}! Today we earn our laurels.', 'Champion call:', 'Glory awaits.', ['sawtooth', 260, 500]), C('iris', 'Iris', 'Messenger', 'phoenix', 'Swift and bright. Delivers what matters, fast.', '{tod}, {n}. I bring the news of the day.', 'Message:', 'Swift winds.', ['sine', 1100, 900], '#c77dff')],
    upside: [C('eleven', 'Eleven', 'Telekinetic friend', 'moth', 'Few words, huge power. Friends do not lie — and neither does your data.', '{tod}, {n}. Friends don’t lie. Your tasks are waiting.', 'Eleven senses:', 'Bitchin’.', ['sine', 180, 900], '#ff2a3d'), C('dustin', 'Dustin', 'Curiosity voyager', 'radio', 'Nerdy, hilarious, radios in with ideas nonstop.', '{tod}, {n}! Do you copy? Over. Today is gonna be awesome.', 'Cerebro report:', 'Over and out.', ['square', 700, 600], '#7fb8ff'), C('hopper', 'Hopper', 'Chief of Hawkins', 'stone', 'Gruff, protective, big on routine and breakfast.', '{tod}, kid. Mornings are for coffee and contemplation. Then work.', 'Chief says:', 'Keep the door open three inches.', ['sawtooth', 120, 200], '#d9a35b'), C('static', 'Static', 'Signal tracker', 'radio', 'Crackly radio voice. Picks up faint signals in your data.', '*krrsh* {tod}, {n}. Signal is strong tonight.', '*krrsh* Signal:', 'Over and out.', ['sawtooth', 90, 1800]), C('moth', 'Moth', 'Mystery scout', 'moth', 'Curious and brave. Explores the strange corners.', '{tod}, {n}. Something flickered in your records.', 'Clue:', 'Lights on. Stay close.', ['sine', 1400, 600], '#c9a6ff'), C('echo9', 'Echo-9', 'Resilience guide', 'eye', 'An escaped lab drone. Gentle, steady and protective.', '{tod}, {n}. Echo-9 online. You are safe here.', 'Echo-9 reports:', 'We get through this together.', ['triangle', 500, 700], '#7fb8ff')],
  };
  NX.companionsFor = wid => { const list = ROSTER[wid] || ROSTER.obsidian; return (ROSTER[wid] || wid === 'obsidian' || list.includes(R2)) ? list : [...list, R2]; };
  NX.activeCompanion = (wid) => {
    const w = wid || NX.world().id, list = NX.companionsFor(w), pick = (NX.mx.companions || {})[w];
    return list.find(c => c.id === pick) || list[0];
  };
  NX.cpVars = (c, w) => { w = w || NX.world(); return `--c1:${c.c1 || w.v.a1};--c2:${w.v.a2};--c3:${w.light ? '#ffffff' : w.v.bg2};--c4:${w.v.text}`; };
  NX.cpGreet = c => { const n = NX.prefs.name || 'Manas', t = tod(); return c.hi.replace('{tod}', t).replace('{TOD}', t.toUpperCase()).replace('{n}', n).replace('{N}', n.toUpperCase()); };

  /* ---------------- task postponement tracking (non-destructive) ---------------- */
  const up0 = NX.upsert;
  NX.upsert = rec => {
    try {
      const old = rec && rec.id && NX.get(rec.id);
      if (old && old.type === 'task' && old.dueDate && rec.dueDate && rec.dueDate > old.dueDate) rec = { ...rec, postponed: (+old.postponed || 0) + 1 };
    } catch (e) {}
    return up0(rec);
  };

  /* ---------------- NX.brain: local rules engine ---------------- */
  const scan = () => {
    const t = NX.today(), I = [], st = { overdue: 0, today: 0, events: 0, any: false };
    const add = (pri, icon, text, go, tone, key) => I.push({ pri, icon, text, go, tone: tone || '', key: key || '' });
    const tasks = real('task'), open = tasks.filter(openTask);
    const over = open.filter(x => x.dueDate && x.dueDate < t).sort((a, b) => (a.dueDate < b.dueDate ? -1 : 1));
    const today = open.filter(x => x.dueDate === t), soon = open.filter(x => x.dueDate > t && diff(t, x.dueDate) <= 3);
    st.overdue = over.length; st.today = today.length;
    if (over.length) add(100, '⚠', `${plural(over.length, 'overdue task')} — oldest is “${over[0].title}” (due ${fmt(over[0].dueDate)}).`, 'tasks', 'warn', 'overdue');
    if (today.length) add(92, '◇', `${plural(today.length, 'task')} due today: ${today.slice(0, 3).map(x => `“${x.title}”`).join(', ')}${today.length > 3 ? '…' : ''}.`, 'tasks', '', 'today');
    if (soon.length) add(70, '⏳', `${plural(soon.length, 'task')} due in the next 3 days.`, 'tasks');
    const highToday = open.filter(x => x.priority === 'High' && (x.dueDate === t || (x.dueDate && x.dueDate < t)));
    if (highToday.length > 3) add(80, '⚖', `Conflicting priorities: ${highToday.length} high-priority tasks are due today or overdue. Pick the top one and reschedule the rest.`, 'tasks', 'warn');
    const postponed = open.filter(x => (+x.postponed || 0) >= 2);
    if (postponed.length) add(66, '↻', `“${postponed[0].title}” has been postponed ${postponed[0].postponed} times${postponed.length > 1 ? ` (and ${postponed.length - 1} more)` : ''}. Break it into a smaller first step?`, 'tasks', 'warn');
    const stale = open.filter(x => !x.dueDate && ago(x.updated || x.created) >= 14);
    if (stale.length) add(45, '◌', `${plural(stale.length, 'open task')} without a due date ${stale.length === 1 ? 'has' : 'have'} not been touched for 2+ weeks.`, 'tasks');
    const doneToday = tasks.filter(x => x.status === 'Completed' && (x.updated || '').slice(0, 10) === t).length;
    if (doneToday) add(20, '✓', `${plural(doneToday, 'task')} completed today. Nice momentum.`, 'tasks', 'good');

    const goals = real('goal').filter(g => !['Completed', 'Achieved', 'Done', 'Abandoned'].includes(g.status) && (+g.progress || 0) < 100);
    goals.forEach(g => {
      if (g.targetDate && g.targetDate >= t && diff(t, g.targetDate) <= 14 && (+g.progress || 0) < 80) add(82, '◎', `Goal “${g.title}” is due ${fmt(g.targetDate)} but only ${+g.progress || 0}% complete.`, 'goals', 'warn');
      else if (g.targetDate && g.targetDate < t) add(76, '◎', `Goal “${g.title}” passed its target date (${fmt(g.targetDate)}). Reset the date or close it?`, 'goals', 'warn');
    });
    const staleG = goals.filter(g => ago(g.updated || g.created) >= 14);
    if (staleG.length) add(60, '◎', `“${staleG[0].title}” has not progressed in ${ago(staleG[0].updated || staleG[0].created)} days. Schedule 30 minutes for it?`, 'goals', '', 'staleGoal');

    real('project').filter(p => !['Completed', 'Archived'].includes(p.status)).forEach(p => {
      const pr = +p.progress || 0;
      if (p.dueDate && p.dueDate < t && pr < 100) add(95, '▲', `Project “${p.title}” is past its deadline (${fmt(p.dueDate)}) at ${pr}%.`, 'projects', 'warn');
      else if (p.dueDate && diff(t, p.dueDate) <= 7 && pr < 100) add(85, '▲', `Project “${p.title}” is due ${fmt(p.dueDate)} at ${pr}%. Split the remaining work into two milestones.`, 'projects', 'warn');
      else if (p.status === 'Active' && ago(p.updated || p.created) >= 10) add(55, '▲', `Active project “${p.title}” has had no updates for ${ago(p.updated || p.created)} days.`, 'projects');
    });

    const ev = real('event'), evToday = ev.filter(e => e.date === t || (e.date < t && e.endDate && e.endDate >= t)), evTom = ev.filter(e => e.date === addDays(t, 1));
    st.events = evToday.length; st.eventsToday = evToday;
    if (evToday.length) add(88, '▦', `Today: ${evToday.slice(0, 3).map(e => `${e.time ? e.time + ' ' : ''}${e.title}`).join(' · ')}.`, 'calendar', '', 'events');
    if (evTom.length) add(62, '▦', `Tomorrow: ${evTom.slice(0, 2).map(e => `${e.time ? e.time + ' ' : ''}${e.title}`).join(' · ')}${evTom.length > 2 ? '…' : ''}.`, 'calendar');
    const timed = evToday.filter(e => toMin(e.time) != null), clash = timed.find((e, i) => timed.some((f, j) => j !== i && toMin(f.time) === toMin(e.time)));
    if (clash) add(78, '⚖', `Calendar clash: two events today at ${clash.time}.`, 'calendar', 'warn');

    const ym = t.slice(0, 7), lm = (() => { const d = new Date(t + 'T00:00:00'); d.setDate(1); d.setMonth(d.getMonth() - 1); return iso(d).slice(0, 7); })();
    const tx = real('transaction'), exp = tx.filter(x => x.kind === 'Expense');
    const spend = exp.filter(x => (x.date || '').startsWith(ym)).reduce((a, x) => a + (+x.amount || 0), 0);
    const day = +t.slice(8, 10), lastSame = exp.filter(x => (x.date || '').startsWith(lm) && +(x.date || '').slice(8, 10) <= day).reduce((a, x) => a + (+x.amount || 0), 0);
    if (lastSame > 0 && spend > lastSame * 1.25) add(52, '₹', `Spending this month (${NX.money(spend)}) is ${Math.round((spend / lastSame - 1) * 100)}% higher than the same point last month.`, 'finance', 'warn');
    else if (lastSame > 0 && spend < lastSame * .8 && spend > 0) add(18, '₹', `Spending is ${Math.round((1 - spend / lastSame) * 100)}% lower than this point last month.`, 'finance', 'good');
    real('budget').forEach(b => {
      const lim = +b.amount || 0; if (!lim) return; const cat = String(b.category || '').toLowerCase();
      const used = exp.filter(x => (x.date || '').startsWith(ym) && (!cat || String(x.category || '').toLowerCase() === cat)).reduce((a, x) => a + (+x.amount || 0), 0);
      if (used > lim) add(80, '₹', `Budget “${b.title}” is over its limit: ${NX.money(used)} of ${NX.money(lim)}.`, 'budgets', 'warn');
      else if (used >= lim * .8) add(58, '₹', `Budget “${b.title}” is at ${Math.round(used / lim * 100)}% with ${new Date(+t.slice(0, 4), +t.slice(5, 7), 0).getDate() - day} days left in the month.`, 'budgets');
    });

    const wo = real('workout'), w7 = wo.filter(w => w.date && diff(w.date, t) >= 0 && diff(w.date, t) < 7).length, w14 = wo.filter(w => w.date && diff(w.date, t) >= 7 && diff(w.date, t) < 14).length;
    if (wo.length && !w7) add(48, '⚡', `No workouts logged in the last 7 days. A 30-minute session today would restart the streak.`, 'fitness');
    else if (w7 >= 4) add(22, '⚡', `${w7} workouts this week — consistent. Consider a recovery day.`, 'fitness', 'good');
    else if (w14 && w7 < w14) add(38, '⚡', `Workouts dropped from ${w14} last week to ${w7} this week.`, 'fitness');

    const learn = real('learning').filter(l => l.status === 'Learning');
    learn.filter(l => (+l.progress || 0) >= 80 && (+l.progress || 0) < 100).slice(0, 1).forEach(l => add(34, '⌘', `“${l.title}” is ${+l.progress}% done — one more session could finish it.`, 'learning', 'good'));
    const staleL = learn.filter(l => ago(l.updated || l.created) >= 14);
    if (staleL.length) add(40, '⌘', `${plural(staleL.length, 'course')} in progress ${staleL.length === 1 ? 'has' : 'have'} not moved for 2+ weeks (“${staleL[0].title}”).`, 'learning');

    const fu = real('note').filter(n => ago(n.updated || n.created) <= 21 && /follow[\s-]?up|to-?do|remind|call back|reply to|email back/i.test((n.title || '') + ' ' + (n.description || '')));
    if (fu.length) add(46, '≡', `${plural(fu.length, 'recent note')} mention a follow-up: “${fu[0].title}”.`, 'notes');

    real('person').forEach(p => {
      [['birthday', 'birthday'], ['specialDate', 'special date']].forEach(([k, label]) => {
        const nx = nextAnnual(p[k], t); if (!nx) return; const d = diff(t, nx);
        if (d === 0) add(99, '♡', `Today is ${p.title}'s ${label}.`, 'people', 'warn');
        else if (d <= 7) add(84, '♡', `${p.title}'s ${label} is in ${plural(d, 'day')} (${fmt(nx)}).`, 'people');
      });
    });
    real('application').forEach(a => {
      if (a.interviewDate && a.interviewDate >= t && diff(t, a.interviewDate) <= 7) add(86, '⌁', `Interview for “${a.title}” on ${fmt(a.interviewDate)}. Block prep time.`, 'career', 'warn');
      else if (a.status === 'Applied' && a.appliedDate && diff(a.appliedDate, t) >= 14) add(42, '⌁', `“${a.title}” was applied ${diff(a.appliedDate, t)} days ago with no update. Send a follow-up?`, 'career');
    });
    real('client').filter(c => ['Talking', 'Proposal'].includes(c.status) && ago(c.updated || c.created) >= 7).slice(0, 1).forEach(c => add(44, '◈', `${c.title} (${c.status}) — no update in ${ago(c.updated || c.created)} days.${c.nextStep ? ` Next step: ${c.nextStep}.` : ''}`, 'clients'));
    real('supplement').filter(s => s.remaining !== '' && s.remaining != null && +s.remaining <= 5).slice(0, 1).forEach(s => add(36, '✚', `${s.title}: only ${+s.remaining} servings left. Time to reorder.`, 'supplements'));

    st.any = NX.data.records.length > 0;
    I.sort((a, b) => b.pri - a.pri);
    return { I, st, open, over, today, goals, staleG, wo };
  };

  const planFor = () => {
    const now = new Date(), t = NX.today(), s = scan();
    let date = t, start = Math.max(9 * 60, Math.ceil((now.getHours() * 60 + now.getMinutes() + 5) / 15) * 15);
    if (start > 21 * 60) { date = addDays(t, 1); start = 9 * 60; }
    const score = x => (x.dueDate && x.dueDate < date ? 60 : 0) + (x.dueDate === date ? 45 : 0) + (x.priority === 'High' ? 30 : x.priority === 'Medium' ? 14 : 4) + (x.dueDate && x.dueDate > date && diff(date, x.dueDate) <= 3 ? 18 : 0) + (x.status === 'In progress' ? 8 : 0) + Math.min(10, (+x.postponed || 0) * 4);
    const cand = s.open.filter(x => x.status !== 'Waiting').map(x => ({ x, sc: score(x) })).sort((a, b) => b.sc - a.sc).slice(0, 6);
    const items = [];
    cand.forEach(({ x }) => {
      const subs = String(x.subtasks || '').split(/\n|;/).map(v => v.replace(/^[-*•\s\[\]x]+/i, '').trim()).filter(Boolean);
      const why = x.dueDate && x.dueDate < date ? 'overdue' : x.dueDate === date ? 'due today' : x.priority === 'High' ? 'high priority' : x.dueDate ? 'due ' + fmt(x.dueDate) : 'open task';
      if (subs.length > 1) subs.slice(0, 4).forEach((v, i) => items.push({ title: `${x.title} — ${v}`, min: 30, why: `${why} · step ${i + 1}/${Math.min(4, subs.length)}`, taskId: x.id }));
      else items.push({ title: x.title, min: x.priority === 'High' ? 60 : x.priority === 'Low' ? 30 : 45, why, taskId: x.id });
    });
    if (s.staleG[0]) items.push({ title: `Move goal forward: ${s.staleG[0].title}`, min: 30, why: 'goal has stalled' });
    if (s.wo.length && !s.wo.some(w => w.date && diff(w.date, date) < 2 && diff(w.date, date) >= 0)) items.push({ title: 'Workout session', min: 45, why: 'no workout in 2 days' });
    const fixed = real('event').filter(e => e.date === date && toMin(e.time) != null).map(e => ({ at: toMin(e.time), min: 60, title: e.title, why: 'calendar', fixed: true })).sort((a, b) => a.at - b.at);
    const out = []; let cur = start, n = 0;
    const blocked = (a, m) => fixed.find(f => a < f.at + f.min && a + m > f.at);
    items.forEach(it => {
      let b; let guard = 0; while ((b = blocked(cur, it.min)) && guard++ < 10) cur = b.at + b.min;
      if (cur + it.min > 22 * 60) { out.push({ ...it, time: '', unscheduled: true }); return; }
      out.push({ ...it, time: hhmm(cur) }); cur += it.min; if (++n % 2 === 0) cur += 10;
    });
    fixed.forEach(f => out.push({ title: f.title, min: f.min, why: 'calendar event', time: hhmm(f.at), fixed: true }));
    out.sort((a, b) => (a.time || '99') < (b.time || '99') ? -1 : 1);
    return { date, items: out };
  };

  const briefing = (c) => {
    c = c || NX.activeCompanion(); const s = scan(), greet = NX.cpGreet(c);
    if (!s.st.any) return `${greet} I don't have any of your records to analyse yet. Add tasks, goals, events or projects and I'll brief you from them.`;
    const pri = s.st.overdue + s.st.today + s.st.events;
    const bits = [s.st.today && `${s.st.today} due today`, s.st.overdue && `${s.st.overdue} overdue`, s.st.events && plural(s.st.events, 'event')].filter(Boolean);
    let txt = `${greet} ${pri ? `You have ${plural(pri, 'priority', 'priorities')} today (${bits.join(', ')}).` : 'Nothing is due today.'}`;
    const extra = s.I.filter(i => !['overdue', 'today', 'events'].includes(i.key) && i.pri >= 40).slice(0, 2);
    if (extra.length) txt += ' ' + c.tic + ' ' + extra.map(i => i.text).join(' ');
    const p = planFor().items.find(i => !i.fixed && !i.unscheduled);
    txt += p ? ` I suggest starting with “${p.title}”${p.time ? ` at ${p.time}` : ''}.` : ' A good moment to move a goal forward.';
    return txt + ' ' + c.sign;
  };
  NX.brain = { scan, plan: planFor, briefing, provider: null, mode: 'local-rules' };

  /* ---------------- home card under the reactor ---------------- */
  const planToday = () => (NX.mx.plan && NX.mx.plan.date >= NX.today() ? NX.mx.plan : null);
  NX.brainCard = () => {
    const c = NX.activeCompanion(), s = scan(), top = s.I.slice(0, 3), pl = planToday();
    return `<section class="bc" aria-label="${NX.esc(c.name)} insights">
      <div class="bc-head"><div class="cp-av sm" style="${NX.cpVars(c)}">${NX.avatarSVG(c)}</div><div class="bc-id"><b>${NX.esc(c.name)}</b><span class="mono dim">${NX.esc(c.role)} · ${NX.esc(NX.world().name)}</span></div></div>
      <ul class="bc-list">${top.length ? top.map(i => `<li class="${i.tone}"><span class="bc-ico">${i.icon}</span><span class="bc-t">${NX.esc(i.text)}</span>${i.go && NX.mod(i.go) ? `<button class="btn small" data-go="${i.go}">Open</button>` : ''}</li>`).join('') : `<li><span class="bc-ico">✓</span><span class="bc-t">${s.st.any ? 'Nothing needs attention right now.' : 'Add a task, goal or event and I will start spotting patterns.'}</span></li>`}</ul>
      ${pl ? `<div class="bc-plan"><div class="mono dim">Accepted plan · ${pl.date === NX.today() ? 'today' : fmt(pl.date)}</div>${pl.items.map((it, i) => `<label class="bc-pi ${it.done ? 'done' : ''}"><input type="checkbox" data-pl-done="${i}" ${it.done ? 'checked' : ''}><span class="mono">${it.time || '—'}</span><span>${NX.esc(it.title)}</span></label>`).join('')}</div>` : ''}
      <div class="bc-act"><button class="btn solid" data-brain="brief">☀ Daily briefing</button><button class="btn" data-brain="plan">▤ Plan my day</button><button class="btn" data-brain="listen" aria-label="Listen to the briefing">🔊 Listen</button><button class="btn" data-brain="panel">◉ ${NX.esc(c.name)}</button></div>
      <p class="bc-note mono dim">Local intelligence · rules engine on this device · reads only your saved records · no cloud AI connected</p>
    </section>`;
  };
  document.addEventListener('click', e => {
    const b = e.target.closest('[data-brain]'); if (!b) return;
    const k = b.dataset.brain;
    if (k === 'brief') NX.speakBriefing(); if (k === 'plan') NX.openPlan(); if (k === 'panel') NX.openCompanion(); if (k === 'listen') { NX.sfx && NX.sfx(NX.activeCompanion(), true); NX.speak ? NX.speak(briefing(), null, true) : NX.speakBriefing(); }
  });
  document.addEventListener('change', e => {
    const b = e.target.closest('[data-pl-done]'); if (!b || !NX.mx.plan) return;
    const it = NX.mx.plan.items[+b.dataset.plDone]; if (it) { it.done = b.checked; NX.saveMx(); b.closest('.bc-pi')?.classList.toggle('done', b.checked); }
  });
  NX.speakBriefing = () => { const txt = briefing(); NX.speak && NX.speak(txt); if (NX.droid && NX.mx.droid) NX.droid.say(txt, true, [['plan', '▤ Plan my day'], ['cmp', '◉ All insights']]); else NX.openCompanion(); };

  /* ---------------- plan sheet ---------------- */
  NX.openPlan = () => {
    const c = NX.activeCompanion(), p = planFor();
    const row = (it, i) => `<div class="pl-row ${it.fixed ? 'fixed' : ''}" data-i="${i}"><input type="checkbox" data-k="on" ${it.unscheduled ? '' : 'checked'} aria-label="Include"><input type="time" data-k="time" value="${it.time || ''}" aria-label="Start time"><input data-k="title" value="${NX.esc(it.title)}" aria-label="Block title"><input type="number" data-k="min" min="5" step="5" value="${it.min}" aria-label="Minutes"><small class="dim">${NX.esc(it.why || '')}${it.unscheduled ? ' · no time left today' : ''}</small><input type="hidden" data-k="task" value="${it.taskId || ''}"></div>`;
    NX.openSheet(`<h3>Plan my day · ${p.date === NX.today() ? 'Today' : fmt(p.date)}</h3>
      <div class="pl-intro"><div class="cp-av sm" style="${NX.cpVars(c)}">${NX.avatarSVG(c)}</div><p class="dim tiny">${NX.esc(c.tic)} Built from your due dates, priorities, subtasks and calendar. Edit times or titles, untick anything you don't want, then accept. Nothing is changed until you accept.</p></div>
      <div class="pl-list" id="plList">${p.items.length ? p.items.map(row).join('') : '<div class="empty">No open tasks or events to plan from. Add a task first.</div>'}</div>
      <div class="actions"><button class="btn small" id="plAdd">＋ Add block</button></div>
      <label class="row"><div class="grow"><div class="t">Also add accepted blocks to Calendar</div><div class="s">Creates new events only — never edits or deletes existing records</div></div><input type="checkbox" id="plCal"></label>
      <div class="actions"><button class="btn" id="plReject">Reject</button><button class="btn" id="plRegen">Regenerate</button><button class="btn solid" id="plAccept">Accept plan</button></div>`);
    const sb = document.getElementById('sheetBody'); sb.scrollTop = 0;
    sb.querySelector('#plAdd').onclick = () => { const l = sb.querySelector('#plList'); l.querySelector('.empty')?.remove(); l.insertAdjacentHTML('beforeend', row({ title: '', min: 30, time: '', why: 'your block' }, l.children.length)); l.lastElementChild.querySelector('[data-k=title]').focus(); };
    sb.querySelector('#plReject').onclick = () => { NX.closeSheet(); NX.toast('Plan discarded — nothing was changed'); };
    sb.querySelector('#plRegen').onclick = () => NX.openPlan();
    sb.querySelector('#plAccept').onclick = () => {
      const items = [...sb.querySelectorAll('.pl-row')].map(r => { const g = k => r.querySelector(`[data-k=${k}]`); return { on: g('on').checked, time: g('time').value, title: g('title').value.trim(), min: Math.max(5, +g('min').value || 30), taskId: g('task').value || undefined, done: false }; }).filter(x => x.on && x.title).map(({ on, ...x }) => x).sort((a, b) => (a.time || '99') < (b.time || '99') ? -1 : 1);
      if (!items.length) return NX.toast('Tick at least one block');
      NX.mx.plan = { date: p.date, items, accepted: new Date().toISOString() }; NX.saveMx();
      let made = 0;
      if (sb.querySelector('#plCal').checked) items.forEach(it => { if (NX.list('event').some(e => e.date === p.date && e.title === it.title && (e.time || '') === it.time)) return; NX.upsert({ type: 'event', title: it.title, date: p.date, time: it.time, category: 'Personal', recurrence: 'None', notes: `From daily plan · ${it.min} min`, fromPlan: true }); made++; });
      NX.closeSheet(); NX.toast(`Plan accepted${made ? ` · ${made} calendar events added` : ''} ✦`);
      if (NX.current === 'home') NX.go('home', false);
    };
  };

  /* ---------------- companion panel ---------------- */
  NX.openCompanion = () => {
    const c = NX.activeCompanion(), s = scan(), r = NX.mx.rem || {};
    const perm = 'Notification' in window ? Notification.permission : 'unsupported';
    NX.openSheet(`<div class="cpp-hero" style="${NX.cpVars(c)}"><div class="cp-av lg">${NX.avatarSVG(c)}</div><div><h3>${NX.esc(c.name)}</h3><div class="mono dim">${NX.esc(c.role)} · ${NX.esc(NX.world().name)}</div><p class="tiny">${NX.esc(c.persona)}</p></div></div>
      <div class="cpp-say">${NX.esc(briefing(c))}</div>
      <div class="actions"><button class="btn solid" id="cpPlan">▤ Plan my day</button><button class="btn" id="cpListen">🔊 Listen</button><button class="btn" id="cpSwap">⇄ Change companion</button></div>
      <div class="section-h"><h2>Insights</h2></div>
      <ul class="bc-list">${s.I.length ? s.I.map(i => `<li class="${i.tone}"><span class="bc-ico">${i.icon}</span><span class="bc-t">${NX.esc(i.text)}</span>${i.go && NX.mod(i.go) ? `<button class="btn small" data-cp-go="${i.go}">Open</button>` : ''}</li>`).join('') : `<li><span class="bc-ico">·</span><span class="bc-t">${s.st.any ? 'No patterns need attention right now.' : 'No records yet — nothing to analyse.'}</span></li>`}</ul>
      <div class="section-h"><h2>Reminders</h2></div>
      <div class="rows">
        <label class="row"><div class="grow"><div class="t">Reminders</div><div class="s">Due tasks, events, plan blocks, goal check-ins</div></div><input type="checkbox" id="rmOn" ${r.on !== false ? 'checked' : ''}></label>
        <label class="row"><div class="grow"><div class="t">Morning briefing at</div><div class="s">Shown once a day when the app is open</div></div><input type="time" id="rmBrief" value="${r.brief || '08:00'}"></label>
        <label class="row"><div class="grow"><div class="t">Event warning</div><div class="s">Minutes before a timed event or plan block</div></div><select id="rmLead">${[5, 10, 15, 30, 60].map(m => `<option value="${m}" ${(r.lead || 15) == m ? 'selected' : ''}>${m} min</option>`).join('')}</select></label>
        <div class="row"><div class="grow"><div class="t">Browser notifications</div><div class="s">${perm === 'granted' ? 'Allowed' : perm === 'denied' ? 'Blocked in browser settings' : perm === 'unsupported' ? 'Not supported here (on iPhone, add to Home Screen first)' : 'Not enabled yet'}</div></div>${perm === 'default' ? '<button class="btn small" id="rmPerm">Enable</button>' : ''}<button class="btn small" id="rmTest">Test</button></div>
      </div>
      <p class="dim tiny">${NX.esc(c.name)} is a local, rules-based assistant: it reads only records saved in this browser and never sends them anywhere. Reminders fire while MANAS.ONE811 is open (or installed and running); closed-app push notifications are not available without a push server.</p>`);
    const sb = document.getElementById('sheetBody'); sb.scrollTop = 0; const save = () => { NX.mx.rem = Object.assign({ on: true, brief: '08:00', lead: 15 }, NX.mx.rem, { on: sb.querySelector('#rmOn').checked, brief: sb.querySelector('#rmBrief').value || '08:00', lead: +sb.querySelector('#rmLead').value }); NX.saveMx(); };
    ['rmOn', 'rmBrief', 'rmLead'].forEach(id => sb.querySelector('#' + id).onchange = save);
    sb.querySelector('#cpPlan').onclick = () => NX.openPlan();
    sb.querySelector('#cpListen').onclick = () => NX.speak ? NX.speak(briefing(c), c, true) : null;
    sb.querySelector('#cpSwap').onclick = () => NX.openStudio('companions');
    sb.querySelectorAll('[data-cp-go]').forEach(b => b.onclick = () => { NX.closeSheet(); NX.go(b.dataset.cpGo); });
    const pb = sb.querySelector('#rmPerm'); if (pb) pb.onclick = async () => { try { await Notification.requestPermission(); } catch (e) {} NX.openCompanion(); };
    sb.querySelector('#rmTest').onclick = () => notify('test-' + Date.now(), `${c.name}`, `${c.tic} This is how a reminder will look.`);
  };

  /* ---------------- Studio › Companions ---------------- */
  NX.studioCpWorld = null;
  NX.studioCompanions = () => {
    const wid = NX.studioCpWorld || NX.world().id, w = NX.worlds.find(x => x.id === wid) || NX.world(), act = NX.activeCompanion(wid);
    return `<p class="dim tiny">Every world has its own companion characters. Your choice is saved separately for each world and never touches your records.</p>
      <label class="field"><span class="mono dim">World</span><select id="cpWorld">${NX.worlds.map(x => `<option value="${x.id}" ${x.id === wid ? 'selected' : ''}>${NX.esc(x.name)}${x.id === NX.world().id ? ' (current)' : ''}</option>`).join('')}</select></label>
      <div class="cp-grid">${NX.companionsFor(wid).map(c => `<article class="cp-card ${c.id === act.id ? 'on' : ''}" style="${NX.cpVars(c, w)}"><div class="cp-av">${NX.avatarSVG(c)}</div><div class="cp-info"><b>${NX.esc(c.name)}</b><span class="mono dim">${NX.esc(c.role)}</span><p class="tiny">${NX.esc(c.persona)}</p><q class="tiny">${NX.esc(NX.cpGreet(c))}</q></div><button class="btn ${c.id === act.id ? 'solid' : ''}" data-cp-pick="${c.id}" ${c.id === act.id ? 'aria-pressed="true"' : ''}>${c.id === act.id ? '✓ Active' : 'Select'}</button></article>`).join('')}</div>`;
  };
  NX.wireStudioCompanions = sb => {
    const sel = sb.querySelector('#cpWorld'); if (!sel) return;
    sel.onchange = () => { NX.studioCpWorld = sel.value; NX.openStudio('companions'); };
    sb.querySelectorAll('[data-cp-pick]').forEach(b => b.onclick = () => {
      const wid = sel.value; NX.mx.companions = Object.assign({}, NX.mx.companions, { [wid]: b.dataset.cpPick }); NX.saveMx();
      const c = NX.activeCompanion(wid);
      if (wid === NX.world().id && NX.droid) { NX.droid.setSkin(); }
      NX.toast(`${c.name} is now your companion in ${NX.worlds.find(x => x.id === wid)?.name}`);
      NX.openStudio('companions');
    });
  };

  /* ---------------- per-world wallpaper presets (SVG, no downloads) ---------------- */
  const enc = s => 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(s);
  const WPN = { nexus: ['Portal glow', 'Hero grid', 'Cosmic rays'], gotham: ['Searchlight', 'Rain grid', 'Noir rays'], wizard: ['Candlelight', 'Rune grid', 'Moon rays'], upside: ['Red storm', 'Signal grid', 'Rift rays'], samurai: ['Lantern dusk', 'Shoji grid', 'Sun rays'], abyss: ['Glow deep', 'Sonar grid', 'Light shafts'], solar: ['Sunrise', 'Garden grid', 'Sun rays'], arcade: ['Neon glow', 'Pixel grid', 'Laser rays'], dune: ['Twin suns', 'Dune grid', 'Heat rays'], olympus: ['Divine glow', 'Marble grid', 'Heaven rays'] };
  NX.wallPresets = w => {
    const { bg, a1, a2 } = w.v, n = WPN[w.id] || ['Glow', 'Grid', 'Rays'], V = `xmlns='http://www.w3.org/2000/svg' viewBox='0 0 400 800' preserveAspectRatio='xMidYMid slice'`;
    return [
      [n[0], enc(`<svg ${V}><defs><radialGradient id='a' cx='25%' cy='18%' r='70%'><stop offset='0' stop-color='${a1}' stop-opacity='.55'/><stop offset='1' stop-color='${bg}' stop-opacity='0'/></radialGradient><radialGradient id='b' cx='85%' cy='88%' r='60%'><stop offset='0' stop-color='${a2}' stop-opacity='.4'/><stop offset='1' stop-color='${bg}' stop-opacity='0'/></radialGradient></defs><rect width='400' height='800' fill='${bg}'/><rect width='400' height='800' fill='url(#a)'/><rect width='400' height='800' fill='url(#b)'/></svg>`)],
      [n[1], enc(`<svg ${V}><defs><pattern id='g' width='40' height='40' patternUnits='userSpaceOnUse'><path d='M40 0H0V40' fill='none' stroke='${a1}' stroke-opacity='.16'/></pattern><linearGradient id='h' x1='0' y1='0' x2='0' y2='1'><stop offset='0' stop-color='${bg}'/><stop offset='.7' stop-color='${a1}' stop-opacity='.18'/><stop offset='1' stop-color='${a2}' stop-opacity='.35'/></linearGradient></defs><rect width='400' height='800' fill='${bg}'/><rect width='400' height='800' fill='url(#h)'/><rect width='400' height='800' fill='url(#g)'/></svg>`)],
      [n[2], enc(`<svg ${V}><rect width='400' height='800' fill='${bg}'/><g fill='${a1}' fill-opacity='.07'>${Array.from({ length: 9 }, (_, i) => `<polygon points='200,-40 ${-200 + i * 100},900 ${-150 + i * 100},900'/>`).join('')}</g><circle cx='200' cy='-40' r='160' fill='${a2}' fill-opacity='.18'/>${Array.from({ length: 40 }, (_, i) => `<circle cx='${(i * 97) % 400}' cy='${(i * 211) % 800}' r='${(i % 3) * .6 + .6}' fill='#fff' fill-opacity='.5'/>`).join('')}</svg>`)],
    ];
  };
  NX.wallPresetHTML = () => `<div class="field"><span class="mono dim">${NX.esc(NX.world().name)} wallpapers</span><div class="wp-row">${NX.wallPresets(NX.world()).map(([n, u], i) => `<button class="wp-chip" data-wp="${i}" style="background-image:url(&quot;${u}&quot;)"><span>${NX.esc(n)}</span></button>`).join('')}</div></div>`;
  NX.wireWallPresets = (sb, re) => sb.querySelectorAll('[data-wp]').forEach(b => b.onclick = () => {
    const u = NX.wallPresets(NX.world())[+b.dataset.wp][1], tgt = sb.querySelector('#wallTarget')?.value || 'all';
    NX.walls[tgt] = u; NX.mx.wallOn = true; NX.saveMx(); if (NX.saveWalls()) { NX.applyWall(); NX.toast('Wallpaper set ✦'); re(); }
  });

  /* ---------------- reminders ---------------- */
  const FIRED = 'manas.fired';
  const fired = () => { try { const f = JSON.parse(localStorage.getItem(FIRED) || '{}'); return f.date === NX.today() ? f : { date: NX.today(), ids: [] }; } catch (e) { return { date: NX.today(), ids: [] }; } };
  const notify = (id, title, body) => {
    const f = fired(); if (f.ids.includes(id)) return; f.ids.push(id); try { localStorage.setItem(FIRED, JSON.stringify(f)); } catch (e) {}
    if (NX.droid && NX.mx.droid) NX.droid.say(body, true); else NX.toast(body);
    if (id === 'brief' && NX.speak && (NX.mx.tts || 'briefings') === 'briefings') NX.speak(body);
    if (!('Notification' in window) || Notification.permission !== 'granted') return;
    const opt = { body, icon: 'assets/apple-touch-icon.png', badge: 'assets/apple-touch-icon.png', tag: id };
    try { if (navigator.serviceWorker && navigator.serviceWorker.controller) navigator.serviceWorker.ready.then(r => r.showNotification(title, opt)).catch(() => {}); else new Notification(title, opt); } catch (e) {}
  };
  NX.notify = notify;
  const tick = () => {
    const r = Object.assign({ on: true, brief: '08:00', lead: 15 }, NX.mx.rem || {}); if (!r.on || !NX.data) return;
    const now = new Date(), m = now.getHours() * 60 + now.getMinutes(), t = NX.today(), c = NX.activeCompanion();
    if (m >= (toMin(r.brief) ?? 480) && m < 22 * 60) notify('brief', `${c.name} · Daily briefing`, briefing(c));
    real('event').filter(e => e.date === t && toMin(e.time) != null).forEach(e => { const d = toMin(e.time) - m; if (d >= 0 && d <= r.lead) notify('ev:' + e.id, `${c.name} · ${e.title}`, `${c.tic} “${e.title}” starts at ${e.time}${e.location ? ' · ' + e.location : ''}.`); });
    const pl = NX.mx.plan; if (pl && pl.date === t) pl.items.forEach((it, i) => { const d = toMin(it.time) - m; if (!it.done && it.time && d >= 0 && d <= Math.min(r.lead, 10)) notify('pl:' + i + it.time, `${c.name} · Next block`, `${c.tic} Next up at ${it.time}: ${it.title} (${it.min} min).`); });
    if (m >= 18 * 60) { const left = real('task').filter(x => openTask(x) && x.dueDate === t).length; if (left) notify('eod', `${c.name} · Evening check`, `${c.tic} ${plural(left, 'task')} due today ${left === 1 ? 'is' : 'are'} still open.`); }
    if (now.getDay() === 0 && m >= 10 * 60) { const g = real('goal').filter(x => (+x.progress || 0) < 100).length; if (g) notify('goals', `${c.name} · Weekly goal check-in`, `${c.tic} Weekly check-in: update progress on your ${plural(g, 'active goal')}.`); }
  };
  NX.reminderTick = tick;
  setTimeout(() => { tick(); setInterval(tick, 60000); }, 9000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) setTimeout(tick, 1500); });
})();
