const CACHE = 'manas-one811-shell-v11-fix3';
const CORE = [
  './os.html', './manifest.webmanifest',
  './css/themes.css', './css/base.css', './css/worlds.css', './css/realms.css', './css/mobile.css', './css/legends.css', './css/v11.css',
  './js/store.js', './js/policy.js', './js/vault.js', './js/api.js',
  './js/fx.js', './js/ui.js', './js/modules.js', './js/dashboard.js',
  './js/ourworld.js', './js/experiences.js', './js/worlds.js', './js/companions.js', './js/personalise.js',
  './js/legends.js', './js/app.js', './js/droid.js', './js/v11.js', './assets/manas-icon.svg',
  './assets/apple-touch-icon.png'
];
self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(CORE)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key !== CACHE).map(key => caches.delete(key)))).then(() => self.clients.claim()));
});
// Network-first so new releases reach phones immediately; cache is the offline fallback.
self.addEventListener('fetch', event => {
  const request = event.request;
  if (request.method !== 'GET' || new URL(request.url).origin !== self.location.origin) return;
  event.respondWith(fetch(request).then(response => {
    if (response.ok) { const copy = response.clone(); caches.open(CACHE).then(cache => cache.put(request, copy)); }
    return response;
  }).catch(() => caches.match(request).then(cached => cached || (request.mode === 'navigate' ? caches.match('./os.html') : Response.error()))));
});
self.addEventListener('notificationclick', event => {
  event.notification.close();
  event.waitUntil(self.clients.matchAll({ type: 'window' }).then(list => list.length ? list[0].focus() : self.clients.openWindow('./os.html')));
});
